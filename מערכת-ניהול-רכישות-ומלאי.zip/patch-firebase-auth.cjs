const fs = require('fs');
let content = fs.readFileSync('src/firebase.ts', 'utf8');

const targetAuth = `export const auth = getAuth(app);`;
const replacementAuth = `export const auth = getAuth(app);

let cachedAccessToken: string | null = null;
let isSigningIn = false;

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const googleSignIn = async () => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, googleProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (credential?.accessToken) {
      cachedAccessToken = credential.accessToken;
    }
    return result;
  } catch (error) {
    console.error('Sign in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const logout = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};
`;

content = content.replace(targetAuth, replacementAuth);
fs.writeFileSync('src/firebase.ts', content);
