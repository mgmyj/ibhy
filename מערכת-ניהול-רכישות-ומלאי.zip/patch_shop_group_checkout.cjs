const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const oldTransaction = `        // Get all products in cart to check stock
        const productSnapshots = [];
        for (const item of cart) {
          const productRef = doc(db, 'products', item.id);
          const productDoc = await transaction.get(productRef);
          if (!productDoc.exists()) throw new Error(\`Product \${item.id} not found\`);
          productSnapshots.push({ item, doc: productDoc });
        }

        // --- CALCULATIONS & VALIDATIONS ---
        
        let nextOrderNumber = 1000;
        if (configDoc.exists()) {
          const currentCounter = configDoc.data().orderCounter || 1000;
          nextOrderNumber = currentCounter + 1;
        }

        // Validate stock for all items
        for (const { item, doc } of productSnapshots) {
          const productData = doc.data();
          if (item.variantId) {
             const variant = productData.variants?.find((v: any) => v.id === item.variantId);
             if (!variant || variant.stockQuantity < item.quantity) {
               throw new Error(\`Not enough stock for \${item.name} - \${item.variantName}\`);
             }
          } else {
             const currentStock = productData.stockQuantity;
             if (currentStock < item.quantity) throw new Error(\`Not enough stock for \${item.name}\`);
          }
        }

        // --- ALL WRITES LAST ---
        
        // Increment counter
        transaction.set(configDocRef, { orderCounter: nextOrderNumber }, { merge: true });

        // Create Order
        const orderRef = doc(collection(db, 'orders'));
        const orderData = {
          orderNumber: nextOrderNumber,
          customer: customerData,
          customerId: customerId,
          createdBy: {
            uid: auth.currentUser?.uid || 'guest',
            name: auth.currentUser?.displayName || 'אורח',
            email: auth.currentUser?.email || ''
          },
          items: cart.map(item => ({
            productId: item.id,
            sku: item.sku,
            name: item.name,
            quantity: item.quantity,
            price: item.variantPrice !== undefined ? item.variantPrice : item.price,
            variantId: item.variantId || null,
            variantName: item.variantName || null
          })),
          totalAmount,
          status: 'pending',
          createdAt: serverTimestamp()
        };
        transaction.set(orderRef, orderData);
        finalOrderData = { ...orderData, id: orderRef.id };

        // Update Stock
        for (const { item, doc } of productSnapshots) {
          const productData = doc.data();
          if (item.variantId && productData.variants) {
            const updatedVariants = productData.variants.map((v: any) => {
              if (v.id === item.variantId) {
                return { ...v, stockQuantity: v.stockQuantity - item.quantity };
              }
              return v;
            });
            transaction.update(doc.ref, {
              variants: updatedVariants
            });
          } else {
            const currentStock = productData.stockQuantity;
            transaction.update(doc.ref, {
              stockQuantity: currentStock - item.quantity
            });
          }
        }`;

const newTransaction = `        // Group cart items by productId to avoid concurrent overwrites for variants of the same product
        const itemsByProduct = cart.reduce((acc, item) => {
          if (!acc[item.id]) acc[item.id] = [];
          acc[item.id].push(item);
          return acc;
        }, {} as Record<string, typeof cart>);

        // Get all products in cart to check stock
        const productSnapshots: { id: string; doc: any; items: typeof cart }[] = [];
        for (const [productId, items] of Object.entries(itemsByProduct)) {
          const productRef = doc(db, 'products', productId);
          const productDoc = await transaction.get(productRef);
          if (!productDoc.exists()) throw new Error(\`Product \${productId} not found\`);
          productSnapshots.push({ id: productId, doc: productDoc, items });
        }

        // --- CALCULATIONS & VALIDATIONS ---
        
        let nextOrderNumber = 1000;
        if (configDoc.exists()) {
          const currentCounter = configDoc.data().orderCounter || 1000;
          nextOrderNumber = currentCounter + 1;
        }

        // Validate stock for all grouped items
        const productUpdates: Record<string, any> = {};
        for (const { id, doc, items } of productSnapshots) {
          const productData = doc.data();
          let newStockQuantity = productData.stockQuantity;
          let newVariants = productData.variants ? [...productData.variants] : [];
          
          for (const item of items) {
            if (item.variantId) {
               const vIndex = newVariants.findIndex((v: any) => v.id === item.variantId);
               if (vIndex === -1 || newVariants[vIndex].stockQuantity < item.quantity) {
                 throw new Error(\`Not enough stock for \${item.name} - \${item.variantName}\`);
               }
               newVariants[vIndex] = { ...newVariants[vIndex], stockQuantity: newVariants[vIndex].stockQuantity - item.quantity };
            } else {
               if (newStockQuantity < item.quantity) throw new Error(\`Not enough stock for \${item.name}\`);
               newStockQuantity -= item.quantity;
            }
          }
          
          productUpdates[id] = {
             hasVariantsUpdate: items.some(i => i.variantId),
             hasStockUpdate: items.some(i => !i.variantId),
             variants: newVariants,
             stockQuantity: newStockQuantity
          };
        }

        // --- ALL WRITES LAST ---
        
        // Increment counter
        transaction.set(configDocRef, { orderCounter: nextOrderNumber }, { merge: true });

        // Create Order
        const orderRef = doc(collection(db, 'orders'));
        const orderData = {
          orderNumber: nextOrderNumber,
          customer: customerData,
          customerId: customerId,
          createdBy: {
            uid: auth.currentUser?.uid || 'guest',
            name: auth.currentUser?.displayName || 'אורח',
            email: auth.currentUser?.email || ''
          },
          items: cart.map(item => ({
            productId: item.id,
            sku: item.sku,
            name: item.name,
            quantity: item.quantity,
            price: item.variantPrice !== undefined ? item.variantPrice : item.price,
            variantId: item.variantId || null,
            variantName: item.variantName || null
          })),
          totalAmount,
          status: 'pending',
          createdAt: serverTimestamp()
        };
        transaction.set(orderRef, orderData);
        finalOrderData = { ...orderData, id: orderRef.id };

        // Update Stock
        for (const { id, doc } of productSnapshots) {
          const updateData: any = {};
          if (productUpdates[id].hasStockUpdate) updateData.stockQuantity = productUpdates[id].stockQuantity;
          if (productUpdates[id].hasVariantsUpdate) updateData.variants = productUpdates[id].variants;
          if (Object.keys(updateData).length > 0) {
             transaction.update(doc.ref, updateData);
          }
        }`;

content = content.replace(oldTransaction, newTransaction);
fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched handleCheckout grouped by product');
