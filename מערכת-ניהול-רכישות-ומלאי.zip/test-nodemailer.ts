import nodemailer from 'nodemailer';

async function test() {
  const transporter = nodemailer.createTransport({ streamTransport: true, buffer: true });
  const info = await transporter.sendMail({
    from: '"איחוד בני הישיבות" <test@example.com>',
    to: 'test2@example.com',
    subject: 'Test Subject',
    html: '<p>Hello</p>',
  });
  console.log(info.message.toString('utf-8'));
}

test();
