const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const targetConfig = `      } catch (err) {
        console.error('Config fetch error:', err);
      }`;

const replacementConfig = `      } catch (err: any) {
        if (err.message && err.message.includes('offline')) {
          console.warn('Firestore is currently offline (likely due to iframe sandboxing or network). Caching config internally.');
        } else {
          console.error('Config fetch error:', err);
        }
      }`;

content = content.replace(targetConfig, replacementConfig);
fs.writeFileSync('src/App.tsx', content);
