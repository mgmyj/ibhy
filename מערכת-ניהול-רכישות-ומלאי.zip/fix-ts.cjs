const fs = require('fs');

function fixFile(file) {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/interface Product \{[\s\S]*?\n\}/, (match) => {
    if (!match.includes('variants?:')) {
      return match.replace(/\n\}/, '\n  variants?: any[];\n}');
    }
    return match;
  });
  fs.writeFileSync(file, content);
}

fixFile('src/components/Inventory.tsx');
fixFile('src/components/Shop.tsx');
