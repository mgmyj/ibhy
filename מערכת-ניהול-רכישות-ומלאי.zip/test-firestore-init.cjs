const { initializeApp } = require('firebase/app');
const { initializeFirestore } = require('firebase/firestore');

const app = initializeApp({ projectId: 'test' });
try {
  initializeFirestore(app, { experimentalForceLongPolling: true }, 'test-db');
  console.log('Success with 3 args');
} catch (e) {
  console.error(e);
}
