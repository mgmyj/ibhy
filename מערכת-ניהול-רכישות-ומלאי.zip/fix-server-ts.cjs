const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');
content = content.replace(/firebaseConfig\.firestoreDatabaseId/g, '(firebaseConfig as any).firestoreDatabaseId');
fs.writeFileSync('server.ts', content);
