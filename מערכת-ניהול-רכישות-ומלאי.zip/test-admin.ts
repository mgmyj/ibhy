import { initializeApp } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
initializeApp();
const db = getFirestore();
async function test() {
  try {
    const snap = await db.collection('config').doc('system').get();
    console.log('Success:', snap.exists);
  } catch (e) {
    console.error('Error:', e);
  }
}
test();
