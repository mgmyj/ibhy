const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

// 1. addToCart
const addToCartTarget = `    const cartItemId = selectedVariant ? \`\${product.id}-\${selectedVariant.id}\` : product.id;
    const stockQuantity = selectedVariant ? selectedVariant.stockQuantity : product.stockQuantity;
    
    const qtyToAdd = productQuantities[product.id] || 1;
    const existingInCart = cart.find(item => item.cartItemId === cartItemId)?.quantity || 0;
    
    if (stockQuantity <= 0 || (existingInCart + qtyToAdd) > stockQuantity) {
      toast.error('שים לב למלאי הנותר במוצר');
      return;
    }`;

const addToCartNew = `    const cartItemId = selectedVariant ? \`\${product.id}-\${selectedVariant.id}\` : product.id;
    const originalStock = selectedVariant ? selectedVariant.stockQuantity : product.stockQuantity;
    const lookupId = selectedVariant ? \`\${product.id}-\${selectedVariant.id}\` : product.id;
    const qtyInOtherCarts = activeCarts[lookupId] || 0;
    const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
    
    const qtyToAdd = productQuantities[product.id] || 1;
    const existingInCart = cart.find(item => item.cartItemId === cartItemId)?.quantity || 0;
    
    if (actualStock <= 0 || (existingInCart + qtyToAdd) > actualStock) {
      toast.error('הכמות המבוקשת חסרה במלאי הפנוי (יתכן ומוצרים תפוסים בסלים אחרים)');
      return;
    }`;

content = content.replace(addToCartTarget, addToCartNew);

// 2. Variants dropdown
const selectTarget = `                            {product.variants.map(v => (
                               <option key={v.id} value={v.id} disabled={v.stockQuantity <= 0}>
                                  {v.name} - {v.price} ₪ {v.stockQuantity <= 0 ? '(אזל)' : \`(מלאי: \${v.stockQuantity})\`}
                               </option>
                            ))}`;

const selectNew = `                            {product.variants.map(v => {
                               const lookupId = \`\${product.id}-\${v.id}\`;
                               const qtyInOtherCarts = activeCarts[lookupId] || 0;
                               const actualStock = Math.max(0, v.stockQuantity - qtyInOtherCarts);
                               const isOutOfStock = actualStock <= 0;
                               return (
                                 <option key={v.id} value={v.id} disabled={isOutOfStock}>
                                    {v.name} - ₪{v.price} {isOutOfStock ? '(אזל מהמלאי הפנוי)' : \`(מלאי זמין: \${actualStock})\`} {qtyInOtherCarts > 0 ? \`(\${qtyInOtherCarts} תפוסים בסלים אחרים)\` : ''}
                                 </option>
                               );
                            })}`;

content = content.replace(selectTarget, selectNew);

// 3. Add button disabled state logic
const buttonTarget = `                        {(() => {
                          const variantId = selectedVariants[product.id];
                          const selectedVariant = product.variants?.find(v => v.id === variantId);
                          const displayStock = selectedVariant?.stockQuantity ?? product.stockQuantity;
                          const isOutOfStock = displayStock <= 0;
                          return (`;

const buttonNew = `                        {(() => {
                          const variantId = selectedVariants[product.id];
                          const selectedVariant = product.variants?.find(v => v.id === variantId);
                          const lookupId = selectedVariant ? \`\${product.id}-\${selectedVariant.id}\` : product.id;
                          const qtyInOtherCarts = activeCarts[lookupId] || 0;
                          const originalStock = selectedVariant?.stockQuantity ?? product.stockQuantity;
                          const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
                          const isOutOfStock = actualStock <= 0;
                          return (`;

content = content.replace(buttonTarget, buttonNew);

fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched stock check');
