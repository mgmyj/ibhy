const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

content = content.replace(
  'totalAmount: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0)',
  'totalAmount: cart.reduce((sum, item) => sum + ((item.variantPrice !== undefined ? item.variantPrice : item.price) * item.quantity), 0)'
);

content = content.replace(
  '<span className="font-bold text-indigo-600">₪{item.price * item.quantity}</span>',
  '<span className="font-bold text-indigo-600">₪{(item.variantPrice !== undefined ? item.variantPrice : item.price) * item.quantity}</span>'
);

fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched Shop cart item price display');
