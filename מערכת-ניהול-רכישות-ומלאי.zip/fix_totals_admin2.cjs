const { initializeApp, applicationDefault } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const fs = require('fs');

initializeApp({
  credential: applicationDefault()
});

const db = getFirestore();
db.settings({ databaseId: "ai-studio-2fc34a17-3097-4a41-8bac-1dbe75f27594" });

async function run() {
  const csvStr = fs.readFileSync('data.csv', 'utf8');
  const lines = csvStr.split('\n').filter(l => l.trim().length > 0 && !l.startsWith(',,,,'));
  
  const expectedTotals = {};
  
  for (let i = 1; i < lines.length; i++) { // skip header
    const cols = lines[i].split(',').map(s => s.trim().replace(/^"|"$/g, ''));
    if (cols.length < 5 || !cols[0]) continue;
    
    const sku = cols[0];
    const totalStock = parseInt(cols[5]) || 0; 
    
    const variants = {};
    for (let v = 11; v < cols.length; v += 3) {
       const vName = cols[v];
       if (!vName) continue;
       const vTotal = parseInt(cols[v+2]) || 0;
       variants[vName] = vTotal;
    }
    expectedTotals[sku] = { main: totalStock, variants };
  }
  
  const snap = await db.collection('products').get();
  const batch = db.batch();
  let count = 0;
  
  snap.forEach(document => {
    const p = document.data();
    const sku = p.sku;
    if (!sku) return;
    
    const expected = expectedTotals[sku];
    if (!expected) return;
    
    let needsUpdate = false;
    let newVariants = [...(p.variants || [])];
    
    if (p.totalStock !== expected.main) {
        needsUpdate = true;
    }
    
    if (p.variants) {
        p.variants.forEach((v, index) => {
           const ev = expected.variants[v.name];
           if (ev !== undefined && v.totalStock !== ev) {
               needsUpdate = true;               
               newVariants[index] = { ...v, totalStock: ev };
           }
        });
    }
    
    if (needsUpdate) {
        batch.update(document.ref, {
            totalStock: expected.main,
            variants: newVariants
        });
        count++;
    }
  });
  
  if (count > 0) {
      await batch.commit();
      console.log(`Successfully fixed totalStock for ${count} products to match the CSV exactly.`);
  } else {
      console.log("No updates needed.");
  }
  process.exit(0);
}

run();
