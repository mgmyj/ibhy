const fs = require('fs');
let content = fs.readFileSync('src/components/Auth.tsx', 'utf8');

content = content.replace(
  "import { auth, googleProvider, signInWithPopup, signOut } from '../firebase';",
  "import { auth, googleProvider, googleSignIn, logout } from '../firebase';"
);

content = content.replace(
  "await signInWithPopup(auth, googleProvider);",
  "await googleSignIn();"
);

content = content.replace(
  "onClick={() => signOut(auth)}",
  "onClick={() => logout()}"
);

fs.writeFileSync('src/components/Auth.tsx', content);
