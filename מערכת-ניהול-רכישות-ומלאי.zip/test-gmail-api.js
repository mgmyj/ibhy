// No, I can't test Gmail API without credentials, but I can check docs.
