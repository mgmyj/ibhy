const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

// Cart items mapping total amount calculation
const totalAmountTarget = `const totalAmount = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);`;
const totalAmountReplacement = `const totalAmount = cart.reduce((sum, item) => sum + ((item.variantPrice ?? item.price) * item.quantity), 0);`;
content = content.replace(totalAmountTarget, totalAmountReplacement);

// Cart UI rendering
const cartUiTarget = `<div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
                  {cart.map((item) => (
                    <div key={item.id} className="flex gap-4 bg-white p-4 rounded-2xl border border-zinc-100 shadow-sm relative group">`;
const cartUiReplacement = `<div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
                  {cart.map((item) => (
                    <div key={item.cartItemId || item.id} className="flex gap-4 bg-white p-4 rounded-2xl border border-zinc-100 shadow-sm relative group">`;
content = content.replace(cartUiTarget, cartUiReplacement);

// Price display in cart UI
const cartPriceTarget = `<p className="font-bold text-zinc-900 mt-1">₪{item.price}</p>`;
const cartPriceReplacement = `<p className="font-bold text-zinc-900 mt-1">₪{item.variantPrice ?? item.price}</p>`;
content = content.replace(cartPriceTarget, cartPriceReplacement);

// Name display in cart UI
const cartNameTarget = `<h4 className="font-bold text-zinc-900 leading-tight">{item.name}</h4>`;
const cartNameReplacement = `<h4 className="font-bold text-zinc-900 leading-tight">{item.name}{item.variantName ? \` - \${item.variantName}\` : ''}</h4>`;
content = content.replace(cartNameTarget, cartNameReplacement);

// Remove button in cart UI
const cartRemoveTarget = `<button 
                          onClick={() => setCart(cart.filter(i => i.id !== item.id))}
                          className="absolute left-4 top-4 p-2 text-zinc-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                        >`;
const cartRemoveReplacement = `<button 
                          onClick={() => setCart(cart.filter(i => (i.cartItemId || i.id) !== (item.cartItemId || item.id)))}
                          className="absolute left-4 top-4 p-2 text-zinc-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                        >`;
content = content.replace(cartRemoveTarget, cartRemoveReplacement);

// Product Card UI to add select dropdown
const cardBottomTarget = `                        </div>
                      )}
                      <div className="space-y-3">
                        {cart.some(item => item.id === product.id) && (
                          <div className="flex items-center gap-1 text-emerald-600 text-[10px] font-bold mb-1">
                            <Check size={12} />
                            כבר בסל שלך
                          </div>
                        )}`;
const cardBottomReplacement = `                        </div>
                      )}
                      <div className="space-y-3">
                        {product.variants && product.variants.length > 0 && (
                          <div className="mb-2">
                            <select 
                              className="w-full text-sm p-2 border border-zinc-200 rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                              value={selectedVariants[product.id] || ''}
                              onChange={e => setSelectedVariants(prev => ({ ...prev, [product.id]: e.target.value }))}
                            >
                              <option value="">בחר תת-פריט</option>
                              {product.variants.map(v => (
                                <option key={v.id} value={v.id} disabled={v.stockQuantity <= 0}>
                                  {v.name} {v.price !== undefined ? \`(₪\${v.price})\` : ''} {v.stockQuantity <= 0 ? '(אזל)' : ''}
                                </option>
                              ))}
                            </select>
                          </div>
                        )}
                        {cart.some(item => (!item.variantId && item.id === product.id) || (item.variantId && selectedVariants[product.id] === item.variantId)) && (
                          <div className="flex items-center gap-1 text-emerald-600 text-[10px] font-bold mb-1">
                            <Check size={12} />
                            כבר בסל שלך
                          </div>
                        )}`;
content = content.replace(cardBottomTarget, cardBottomReplacement);

// Update stock quantity and price on card
const cardPriceTarget = `<div className="flex justify-between items-end mb-4">
                        <div className="flex items-end gap-1">
                          <span className="text-2xl font-black text-indigo-600">₪{product.price}</span>
                        </div>`;
const cardPriceReplacement = `
                        {(() => {
                          const variantId = selectedVariants[product.id];
                          const selectedVariant = product.variants?.find(v => v.id === variantId);
                          const displayPrice = selectedVariant?.price ?? product.price;
                          const displayStock = selectedVariant?.stockQuantity ?? product.stockQuantity;
                          return (
                          <div className="flex justify-between items-end mb-4">
                            <div className="flex items-end gap-1">
                              <span className="text-2xl font-black text-indigo-600">₪{displayPrice}</span>
                            </div>
                            <div className="text-left">
                              <span className={\`text-[10px] font-bold px-2 py-1 rounded-full \${displayStock > 10 ? 'bg-emerald-50 text-emerald-600' : displayStock > 0 ? 'bg-amber-50 text-amber-600' : 'bg-red-50 text-red-600'}\`}>
                                {displayStock > 0 ? \`\${displayStock} במלאי\` : 'אזל'}
                              </span>
                            </div>
                          </div>
                          );
                        })()}
`;
content = content.replace(
  `<div className="flex justify-between items-end mb-4">
                        <div className="flex items-end gap-1">
                          <span className="text-2xl font-black text-indigo-600">₪{product.price}</span>
                        </div>
                        <div className="text-left">
                          <span className={\`text-[10px] font-bold px-2 py-1 rounded-full \${product.stockQuantity > 10 ? 'bg-emerald-50 text-emerald-600' : product.stockQuantity > 0 ? 'bg-amber-50 text-amber-600' : 'bg-red-50 text-red-600'}\`}>
                            {product.stockQuantity > 0 ? \`\${product.stockQuantity} במלאי\` : 'אזל מהמלאי'}
                          </span>
                        </div>
                      </div>`,
  cardPriceReplacement
);

// Stock quantity limits in input +/ -
const inputPlusMinusTarget = `                        <button
                          disabled={product.stockQuantity <= 0}
                          onClick={() => addToCart(product)}
                          className={\`w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 \${product.stockQuantity > 0 ? 'bg-zinc-900 text-white hover:bg-black shadow-lg shadow-black/10' : 'bg-zinc-100 text-zinc-400 cursor-not-allowed'}\`}
                        >
                          <ShoppingBag size={20} />
                          {product.stockQuantity > 0 ? 'הוסף לסל' : 'אזל מהמלאי'}
                        </button>`;
const inputPlusMinusReplacement = `                        {(() => {
                          const variantId = selectedVariants[product.id];
                          const selectedVariant = product.variants?.find(v => v.id === variantId);
                          const displayStock = selectedVariant?.stockQuantity ?? product.stockQuantity;
                          const isOutOfStock = displayStock <= 0;
                          return (
                            <button
                              disabled={isOutOfStock || (product.variants?.length > 0 && !variantId)}
                              onClick={() => addToCart(product)}
                              className={\`w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 \${!isOutOfStock && (!product.variants?.length || variantId) ? 'bg-zinc-900 text-white hover:bg-black shadow-lg shadow-black/10' : 'bg-zinc-100 text-zinc-400 cursor-not-allowed'}\`}
                            >
                              <ShoppingBag size={20} />
                              {isOutOfStock ? 'אזל מהמלאי' : 'הוסף לסל'}
                            </button>
                          );
                        })()}`;
content = content.replace(inputPlusMinusTarget, inputPlusMinusReplacement);

// Fix setProductQuantities limits too
content = content.replace(
  `setProductQuantities(prev => ({ ...prev, [product.id]: Math.max(1, Math.min(val, product.stockQuantity)) }));`,
  `setProductQuantities(prev => ({ ...prev, [product.id]: Math.max(1, Math.min(val, (product.variants?.find(v=>v.id===selectedVariants[product.id])?.stockQuantity ?? product.stockQuantity))) }));`
);
content = content.replace(
  `if ((productQuantities[product.id] || 1) >= product.stockQuantity) {
                                toast.error('שים לב למלאי הנותר במוצר');
                              }
                              setProductQuantities(prev => ({ ...prev, [product.id]: Math.min(product.stockQuantity, (prev[product.id] || 1) + 1) }));`,
  `const maxStock = product.variants?.find(v=>v.id===selectedVariants[product.id])?.stockQuantity ?? product.stockQuantity;
                              if ((productQuantities[product.id] || 1) >= maxStock) {
                                toast.error('שים לב למלאי הנותר במוצר');
                              }
                              setProductQuantities(prev => ({ ...prev, [product.id]: Math.min(maxStock, (prev[product.id] || 1) + 1) }));`
);

fs.writeFileSync('src/components/Shop.tsx', content);
