const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

const targetEndpoint = `  app.post("/api/send-email", async (req, res) => {
    const { to, subject, text, html, userEmail, userName, replyTo, attachments } = req.body;

    if (!to || !subject || (!text && !html)) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    try {
      const { transporter, user, fromName } = await getTransporter();
      const info = await transporter.sendMail({
        from: \`"\${fromName}" <\${user}>\`,
        to,
        subject,
        text,
        html,
        replyTo: replyTo || (userEmail ? \`"\${userName || userEmail}" <\${userEmail}>\` : undefined),
        attachments: attachments?.map((att: any) => ({
          filename: att.filename,
          content: att.content,
          encoding: att.encoding || 'base64',
          contentType: att.contentType
        }))
      });

      console.log("Email sent: %s", info.messageId);
      res.json({ success: true, messageId: info.messageId });
    } catch (error) {
      console.error("Error sending email:", error);
      res.status(500).json({ error: "Failed to send email" });
    }
  });`;

const replacementEndpoint = `  app.post("/api/send-email", async (req, res) => {
    const { to, subject, text, html, userEmail, userName, replyTo, attachments } = req.body;
    const authHeader = req.headers.authorization;
    const accessToken = authHeader ? authHeader.replace('Bearer ', '') : null;

    if (!to || !subject || (!text && !html)) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    try {
      // Get system config
      const configDoc = await getDoc(doc(db, "config", "system"));
      const config = configDoc.exists() ? configDoc.data() : {};
      const emailSettings = config.emailSettings || {};
      const systemName = config.orgName || config.siteName || "מערכת";
      
      const useSystemEmail = emailSettings.senderChoice === 'system' || !accessToken;

      if (useSystemEmail) {
        const { transporter, user, fromName } = await getTransporter();
        const info = await transporter.sendMail({
          from: \`"\${systemName}" <\${user}>\`,
          to,
          subject,
          text,
          html,
          replyTo: replyTo || (userEmail ? \`"\${userName || userEmail}" <\${userEmail}>\` : undefined),
          attachments: attachments?.map((att: any) => ({
            filename: att.filename,
            content: att.content,
            encoding: att.encoding || 'base64',
            contentType: att.contentType
          }))
        });
        console.log("System email sent: %s", info.messageId);
        return res.json({ success: true, messageId: info.messageId });
      } else {
        // Send via user's Gmail API
        const fromHeaderName = userName ? \`\${systemName} - \${userName}\` : systemName;
        
        // Construct MIME email
        const boundary = "boundary_" + Date.now().toString(16);
        let mimeEmail = 
          \`From: "\${fromHeaderName}" <\${userEmail}>\\r\\n\` +
          \`To: \${to}\\r\\n\` +
          \`Subject: =?utf-8?B?\${Buffer.from(subject).toString('base64')}?=\\r\\n\` +
          "MIME-Version: 1.0\\r\\n" +
          \`Content-Type: multipart/mixed; boundary="\${boundary}"\\r\\n\\r\\n\` +
          \`--\${boundary}\\r\\n\` +
          "Content-Type: text/html; charset=utf-8\\r\\n\\r\\n" +
          (html || text) + "\\r\\n\\r\\n";

        if (attachments && attachments.length > 0) {
          attachments.forEach((att: any) => {
            mimeEmail += 
              \`--\${boundary}\\r\\n\` +
              \`Content-Type: \${att.contentType || 'application/octet-stream'}; name="\${att.filename}"\\r\\n\` +
              "Content-Transfer-Encoding: base64\\r\\n" +
              \`Content-Disposition: attachment; filename="\${att.filename}"\\r\\n\\r\\n\` +
              att.content + "\\r\\n\\r\\n";
          });
        }
        
        mimeEmail += \`--\${boundary}--\\r\\n\`;

        const encodedEmail = Buffer.from(mimeEmail)
          .toString('base64')
          .replace(/\\+/g, '-')
          .replace(/\\//g, '_')
          .replace(/=+$/, '');

        const response = await fetch('https://gmail.googleapis.com/upload/gmail/v1/users/me/messages/send', {
          method: 'POST',
          headers: {
            'Authorization': \`Bearer \${accessToken}\`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ raw: encodedEmail })
        });

        if (!response.ok) {
          const errorData = await response.text();
          console.error("Gmail API Error:", errorData);
          
          // Fallback to system email if Gmail fails (e.g. token expired)
          console.log("Falling back to system email...");
          const { transporter, user } = await getTransporter();
          const info = await transporter.sendMail({
            from: \`"\${fromHeaderName}" <\${user}>\`,
            to,
            subject,
            text,
            html,
            replyTo: \`"\${fromHeaderName}" <\${userEmail}>\`,
            attachments: attachments?.map((att: any) => ({
              filename: att.filename,
              content: att.content,
              encoding: att.encoding || 'base64',
              contentType: att.contentType
            }))
          });
          return res.json({ success: true, messageId: info.messageId, note: 'fallback_used' });
        }
        
        const data = await response.json();
        console.log("User Gmail sent: %s", data.id);
        res.json({ success: true, messageId: data.id });
      }

    } catch (error) {
      console.error("Error sending email:", error);
      res.status(500).json({ error: "Failed to send email" });
    }
  });`;

content = content.replace(targetEndpoint, replacementEndpoint);
fs.writeFileSync('server.ts', content);
