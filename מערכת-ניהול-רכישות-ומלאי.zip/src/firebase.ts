import { initializeApp } from 'firebase/app';
import { getAuth, onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut } from 'firebase/auth';
import { getFirestore, initializeFirestore, doc, getDocFromServer, collection, onSnapshot, query, where, orderBy, limit, addDoc, updateDoc, deleteDoc, setDoc, getDoc, serverTimestamp, Timestamp, writeBatch, getDocs, increment, runTransaction } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import firebaseConfig from '../firebase-applet-config.json';

export { firebaseConfig };

// Initialize Firebase SDK
if (!firebaseConfig.projectId || firebaseConfig.projectId.includes('TODO')) {
  console.error('Firebase configuration is missing or invalid. Please run set_up_firebase tool.');
}

const app = initializeApp(firebaseConfig);

// Allow manual override of database ID for recovery
// Prioritize config file over localStorage, but allow localStorage as fallback if config is missing
const savedDbId = typeof window !== 'undefined' ? localStorage.getItem('firestore_db_id') : null;
export const currentDbId = firebaseConfig.firestoreDatabaseId || savedDbId || '(default)';

// Enable long polling for NetFree and other filtered networks
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
}, currentDbId);

export const auth = getAuth(app);

let cachedAccessToken: string | null = typeof window !== 'undefined' ? sessionStorage.getItem('gmail_token') : null;
let isSigningIn = false;

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const googleSignIn = async () => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, googleProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (credential?.accessToken) {
      cachedAccessToken = credential.accessToken;
      sessionStorage.setItem('gmail_token', credential.accessToken);
    }
    return result;
  } catch (error: any) {
    if (error?.code !== 'auth/cancelled-popup-request' && error?.code !== 'auth/popup-closed-by-user') {
      console.error('Sign in error:', error);
    }
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const logout = async () => {
  await auth.signOut();
  cachedAccessToken = null;
  sessionStorage.removeItem('gmail_token');
};


// Storage initialization with fallback
let storageInstance;
try {
  storageInstance = getStorage(app);
  console.log('Firebase Storage initialized with bucket:', firebaseConfig.storageBucket);
} catch (e) {
  console.warn('Failed to initialize storage with primary bucket, trying fallback...', e);
  const fallbackBucket = firebaseConfig.projectId + '.appspot.com';
  storageInstance = getStorage(app, fallbackBucket);
  console.log('Firebase Storage initialized with fallback bucket:', fallbackBucket);
}

export const storage = storageInstance;
export const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('https://www.googleapis.com/auth/gmail.send');

export const connectGmailAccount = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (credential?.accessToken) {
      cachedAccessToken = credential.accessToken;
      sessionStorage.setItem('gmail_token', credential.accessToken);
    }
    return result;
  } catch (error) {
    console.error('Gmail connect error:', error);
    throw error;
  }
};

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test connection check removed to prevent offline warnings in restricted iframe environments.

export { 
  onAuthStateChanged, 
  signInWithPopup, 
  signOut, 
  collection, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  limit, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  setDoc, 
  getDoc, 
  serverTimestamp, 
  Timestamp, 
  doc,
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject,
  writeBatch,
  getDocs,
  increment,
  runTransaction
};
