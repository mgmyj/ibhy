export interface FormField {
  id: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'select' | 'email';
  options?: string[];
  required?: boolean;
  hideInReports?: boolean;
}

export interface EmailSettings {
  mainEmail: string;
  reportEmail: string;
  replyToType: 'sender' | 'fixed';
  fixedReplyToEmail?: string;
  senderChoice: 'user' | 'system';
  notifyNewOrder: boolean;
  notifyEditOrder: boolean;
  notifyDeleteOrder: boolean;
  notifyReservation: boolean;
  notifyReservationDelete: boolean;
  notifyReservationToOrder: boolean;
  notifyLowStock: boolean;
  autoDailyReport: boolean;
  autoWeeklyReport: boolean;
  autoMonthlyReport: boolean;
  disableAllEmails: boolean;
}

export interface SystemConfig {
  customerFormTitle: string;
  customerFormFields: FormField[];
  siteName: string;
  orgName: string;
  logoUrl: string;
  faviconUrl: string;
  emailSettings?: EmailSettings;
}


export interface ProductVariant {
  id: string;
  name: string;
  price?: number;
  stockQuantity: number;
  totalStock?: number;
  reservedQuantity?: number;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  description?: string;
  stockQuantity: number;
  totalStock: number;
  reservedQuantity?: number;
  price: number;
  categoryId?: string;
  variants?: ProductVariant[];
}

export interface Customer {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  associationName?: string;
  contactPerson?: string;
  [key: string]: any;
}

export interface Order {
  id: string;
  orderNumber: number;
  customer: Customer;
  customerId: string;
  items: {
    productId: string;
    sku: string;
    name: string;
    quantity: number;
    price: number;
  }[];
  totalAmount: number;
  status: 'pending' | 'completed' | 'cancelled';
  createdAt: any;
  updatedAt?: any;
  emailSent?: boolean;
  emailSentTo?: string;
  emailFailed?: boolean;
  emailError?: string;
  emailMessageId?: string;
}
