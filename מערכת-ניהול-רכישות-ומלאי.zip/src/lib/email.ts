import { auth, getAccessToken } from '../firebase';

interface EmailAttachment {
  filename: string;
  content: string; // base64 string
  contentType?: string;
  encoding?: string;
}

interface SendEmailParams {
  to: string;
  subject: string;
  text?: string;
  html?: string;
  attachments?: EmailAttachment[];
}

export async function sendEmail({ to, subject, text, html, attachments }: SendEmailParams) {
  const user = auth.currentUser;
  const token = await getAccessToken();
  
  try {
    const response = await fetch('/api/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      body: JSON.stringify({
        to,
        subject,
        text,
        html,
        attachments,
        userEmail: user?.email,
        userName: user?.displayName,
      }),
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Failed to send email');
    }
    
    if (data.note === 'fallback_used') {
      console.warn('Gmail API failed, used system fallback. You may need to reconnect your Gmail account.');
    }
    
    return data;
  } catch (error) {
    console.error('Error in sendEmail utility:', error);
    throw error;
  }
}
