// Simple in-memory cache to reduce Firestore reads
export const dataCache: {
  categories: any[] | null;
  subCategories: any[] | null;
  config: any | null;
  products: { [key: string]: { data: any[], timestamp: number } };
  lastFetch: number;
} = {
  categories: null,
  subCategories: null,
  config: null,
  products: {},
  lastFetch: 0
};

export const CACHE_DURATION = 1000 * 60 * 2; // 2 minutes
