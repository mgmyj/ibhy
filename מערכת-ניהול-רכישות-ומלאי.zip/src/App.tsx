import React, { useState, useEffect, useRef } from 'react';
import { auth, onAuthStateChanged, db, doc, getDoc, setDoc, updateDoc, handleFirestoreError, OperationType, collection, query, where, getDocs, deleteDoc, limit, orderBy, onSnapshot } from './firebase';
import { Auth } from './components/Auth';
import { Shop } from './components/Shop';
import { Inventory } from './components/Inventory';
import { Orders } from './components/Orders';
import { Reports } from './components/Reports';
import { Settings } from './components/Settings';
import { Users } from './components/Users';
import { Customers } from './components/Customers';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LowStockAlert } from './components/LowStockAlert';
import { Archive } from './components/Archive';
import { EmailHealthBanner } from './components/EmailHealthBanner';
import { ShoppingBag, Package, ClipboardList, Settings as SettingsIcon, LayoutDashboard, User as UserIcon, Users as UsersIcon, Archive as ArchiveIcon, PanelRightClose, PanelRightOpen, Menu, X, ChevronRight, ChevronLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type Tab = 'shop' | 'inventory' | 'orders' | 'reports' | 'settings' | 'users' | 'customers' | 'archive';

import { dataCache, CACHE_DURATION } from './lib/cache';
import { Toaster, toast } from 'react-hot-toast';
import { notifyAdminEmailFailure } from './services/adminAlertService';

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [loadingTimeout, setLoadingTimeout] = useState(false);
  const [isGuest, setIsGuest] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>('shop');
  const [userRole, setUserRole] = useState<'owner' | 'admin' | 'main_user' | 'partial_user' | 'user'>('user');
  const [allowedCategories, setAllowedCategories] = useState<string[]>([]);
  const [config, setConfig] = useState<any>(null);
  const [pendingEditProductId, setPendingEditProductId] = useState<string | null>(null);
  const [isMainSidebarOpen, setIsMainSidebarOpen] = useState(() => {
    const saved = localStorage.getItem('main_sidebar_open');
    return saved ? JSON.parse(saved) : true;
  });

  const toggleMainSidebar = () => {
    const newState = !isMainSidebarOpen;
    setIsMainSidebarOpen(newState);
    localStorage.setItem('main_sidebar_open', JSON.stringify(newState));
  };

  const isAdmin = userRole === 'owner' || userRole === 'admin';
  const isMainUser = userRole === 'owner' || userRole === 'admin' || userRole === 'main_user';
  const isOwner = userRole === 'owner';

  useEffect(() => {
    const handleTabChange = (e: any) => {
      if (e.detail) {
        setActiveTab(e.detail as Tab);
      }
    };
    const handleEditProduct = (e: any) => {
      setPendingEditProductId(e.detail);
    };
    window.addEventListener('change-tab', handleTabChange);
    window.addEventListener('edit-product', handleEditProduct);
    return () => {
      window.removeEventListener('change-tab', handleTabChange);
      window.removeEventListener('edit-product', handleEditProduct);
    };
  }, []);

  useEffect(() => {
    const fetchConfig = async () => {
      // Use cache if valid
      if (dataCache.config && (Date.now() - dataCache.lastFetch < CACHE_DURATION)) {
        setConfig(dataCache.config);
        if (dataCache.config.siteName) document.title = dataCache.config.siteName;
        return;
      }

      try {
        const snapshot = await getDoc(doc(db, 'config', 'system'));
        if (snapshot.exists()) {
          const data = snapshot.data();
          setConfig(data);
          dataCache.config = data;
          dataCache.lastFetch = Date.now();
          
          // Update document title and favicon
          if (data.siteName) {
            document.title = data.siteName;
          }
          if (data.faviconUrl) {
            let link: HTMLLinkElement | null = document.querySelector("link[rel~='icon']");
            if (!link) {
              link = document.createElement('link');
              link.rel = 'icon';
              document.getElementsByTagName('head')[0].appendChild(link);
            }
            link.href = data.faviconUrl;
          }
        }
      } catch (err: any) {
        if (err.message && err.message.includes('offline')) {
          console.warn('Firestore is currently offline (likely due to iframe sandboxing or network). Caching config internally.');
        } else {
          console.error('Config fetch error:', err);
        }
      }
    };
    fetchConfig();
  }, []);

  useEffect(() => {
    let unsubUser: (() => void) | null = null;

    const timeout = setTimeout(() => {
      if (loading) {
        setLoadingTimeout(true);
        console.warn('Auth state check timed out');
      }
    }, 10000);

    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      // Clear previous snapshot listener if any
      if (unsubUser) {
        unsubUser();
        unsubUser = null;
      }

      try {
        clearTimeout(timeout);
        setUser(currentUser);
        
        if (currentUser) {
          setIsGuest(false);
          const userDocRef = doc(db, 'users', currentUser.uid);
          const ownerEmails = ['b0556720640@gmail.com', 'm@mdafhayomi.org', 'tt7961816@gmail.com'];
          const isHardcodedOwner = currentUser.email && ownerEmails.includes(currentUser.email.toLowerCase().trim());

          // Set initial role state
          if (isHardcodedOwner) setUserRole('owner');

          // 1. Check for profile AND pending updates
          try {
            const userDoc = await getDoc(userDocRef);
            let currentRole = userDoc.exists() ? (userDoc.data() as any).role : (isHardcodedOwner ? 'owner' : 'user');
            let currentAllowedCategories = userDoc.exists() ? (userDoc.data() as any).allowedCategories || [] : [];
            let pendingFound = false;
            const userEmail = currentUser.email?.toLowerCase().trim();
            
            // Only check for pending role update if user profile doesn't exist
            if (!userDoc.exists()) {
              if (userEmail) {
                try {
                  const pendingRef = doc(db, 'users', userEmail);
                  const pendingDoc = await getDoc(pendingRef);
                  
                  if (pendingDoc.exists()) {
                    const pendingData = pendingDoc.data();
                    console.log('Found pending role update:', pendingData.role);
                    currentRole = pendingData.role;
                    currentAllowedCategories = pendingData.allowedCategories || [];
                    pendingFound = true;
                  } else {
                    // Fallback to query if ID lookup fails
                    const q = query(collection(db, 'users'), where('email', '==', userEmail), where('isPending', '==', true), limit(1));
                    const querySnapshot = await getDocs(q);
                    if (!querySnapshot.empty) {
                      const foundDoc = querySnapshot.docs[0];
                      console.log('Found pending role update via query:', foundDoc.data().role);
                      currentRole = foundDoc.data().role;
                      currentAllowedCategories = foundDoc.data().allowedCategories || [];
                      pendingFound = true;
                    }
                  }
                } catch (e) {
                  console.error('Error checking for pre-authorized role:', e);
                }
              }
            }

            // Create or update profile if needed
            const needsUpdate = !userDoc.exists() || pendingFound || (isHardcodedOwner && currentRole !== 'owner');
            
            if (needsUpdate) {
              const finalRole = isHardcodedOwner ? 'owner' : currentRole;
              console.log('Creating/Updating user profile with role:', finalRole);
              
              // 1. Update/Create the profile first
              await setDoc(userDocRef, {
                uid: currentUser.uid,
                name: currentUser.displayName || '',
                email: currentUser.email || '',
                role: finalRole,
                allowedCategories: currentAllowedCategories,
                isPending: false,
                updatedAt: new Date().toISOString(),
                ...(userDoc.exists() ? {} : { createdAt: new Date().toISOString() })
              }, { merge: true });

              // 2. Then delete the pending doc if it was found
              if (pendingFound && userEmail) {
                try {
                  const pendingRef = doc(db, 'users', userEmail);
                  await deleteDoc(pendingRef);
                  console.log('Deleted pending role update document');
                } catch (e) {
                  console.warn('Failed to delete pending role document (might have been deleted by another process):', e);
                }
              }

              setUserRole(finalRole);
              setAllowedCategories(currentAllowedCategories);
            } else {
              setUserRole(currentRole);
              setAllowedCategories(currentAllowedCategories);
            }
          } catch (err) {
            console.error('Error in initial profile check:', err);
            setUserRole(isHardcodedOwner ? 'owner' : 'user');
          }

          setLoading(false);
        } else {
          setUserRole('user');
          setLoading(false);
        }
      } catch (err) {
        console.error('Error in onAuthStateChanged:', err);
        setLoading(false);
      }
    });

    return () => {
      unsub();
      if (unsubUser) unsubUser();
    };
  }, []);

  // Listen for real-time order email failures and immediately alert the admin via Toast
  const alertedOrderFailuresRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    if (!isAdmin || !user) return;

    // Listen to recent orders
    const q = query(
      collection(db, 'orders'),
      orderBy('createdAt', 'desc'),
      limit(25)
    );

    let isInitialLoad = true;
    let unsubscribe: (() => void) | undefined;
    try {
      unsubscribe = onSnapshot(q, (snapshot) => {
        snapshot.docChanges().forEach((change) => {
          const orderData = change.doc.data() as any;
          const orderId = change.doc.id;

          // On initial load, record any existing failed orders so we don't spam toasts on page reload
          if (isInitialLoad) {
            if (orderData.emailFailed) {
              alertedOrderFailuresRef.current.add(orderId);
            }
            return;
          }

          // Trigger urgent toast on new or updated order where email failed
          if ((change.type === 'added' || change.type === 'modified') && orderData.emailFailed && !orderData.emailSent) {
            if (!alertedOrderFailuresRef.current.has(orderId)) {
              alertedOrderFailuresRef.current.add(orderId);
              notifyAdminEmailFailure({
                orderId,
                orderNumber: orderData.orderNumber,
                customerName: orderData.customerName || (orderData.customer ? Object.values(orderData.customer)[0] : undefined),
                error: orderData.emailError || 'שליחת מייל להזמנה נכשלה בשרת הדואר',
                recipient: orderData.emailSentTo || config?.emailSettings?.reportEmail,
                totalAmount: orderData.totalAmount
              });
            }
          }
        });
        isInitialLoad = false;
      }, (error) => {
        console.warn('Orders admin failure watcher error:', error);
      });
    } catch (err) {
      console.warn('Failed to attach orders failure watcher:', err);
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [isAdmin, user, config]);

  const handleGuestLogin = () => {
    setIsGuest(true);
    setActiveTab('shop');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0a0a0a] p-4 text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mb-6"></div>
        <h2 className="text-xl font-bold text-white mb-2">מתחבר למערכת...</h2>
        <p className="text-gray-400 text-sm max-w-xs">
          החיבור עשוי לקחת מספר שניות, במיוחד תחת סינון אינטרנט.
        </p>
        
        {loadingTimeout && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 flex flex-col gap-3 w-full max-w-xs"
          >
            <button 
              onClick={() => window.location.reload()}
              className="w-full bg-white/5 hover:bg-white/10 text-white py-3 rounded-xl font-bold transition-all border border-white/10"
            >
              נסה שוב
            </button>
            <button 
              onClick={handleGuestLogin}
              className="w-full text-indigo-400 hover:text-indigo-300 py-2 text-sm font-bold"
            >
              המשך כאורח
            </button>
          </motion.div>
        )}
      </div>
    );
  }

  if (!user && !isGuest) {
    return <Auth user={user} loading={loading} onGuestLogin={handleGuestLogin} />;
  }

  const tabs = [
    { id: 'shop', label: 'חנות', icon: ShoppingBag },
    { id: 'inventory', label: 'ניהול מוצרים', icon: Package, adminOnly: true },
    { id: 'orders', label: (userRole === 'user' && !isAdmin && !isMainUser) ? 'הזמנות שלי' : 'הזמנות', icon: ClipboardList },
    { id: 'reports', label: 'דוחות ומיילים', icon: LayoutDashboard, adminOnly: true },
    { id: 'customers', label: 'ספר לקוחות', icon: UsersIcon, adminOnly: true },
    ...(config?.enableSalesArchive ? [{ id: 'archive', label: 'ארכיון ומכירות', icon: ArchiveIcon, adminOnly: true }] : []),
    { id: 'users', label: 'משתמשים', icon: UserIcon, adminOnly: true },
    { id: 'settings', label: 'הגדרות', icon: SettingsIcon, adminOnly: true },
  ];

  const filteredTabs = tabs.filter(tab => {
    if (isAdmin) return true;
    if (isGuest) return tab.id === 'shop';
    if (user) {
      if (isMainUser || userRole === 'partial_user' || userRole === 'user') return ['shop', 'orders'].includes(tab.id);
      return tab.id === 'shop';
    }
    return !tab.adminOnly;
  });

  return (
    <ErrorBoundary>
      <Toaster position="top-center" reverseOrder={false} containerStyle={{ zIndex: 99999 }} />
      <div className="no-print">
        <LowStockAlert isAdmin={isAdmin} />
      </div>
      <div className="min-h-screen bg-zinc-50 flex flex-col md:flex-row font-sans" dir="rtl">
        {/* Sidebar Navigation */}
        <nav className={`no-print w-full ${isMainSidebarOpen ? 'md:w-72' : 'md:w-20'} transition-all duration-300 bg-zinc-900 text-white flex flex-col h-auto md:h-screen sticky top-0 z-40`}>
          <div className={`p-4 ${isMainSidebarOpen ? 'md:p-8' : 'md:p-4'} border-b border-zinc-800 transition-all flex flex-col items-center relative`}>
            {/* Toggle Button */}
            <button
              onClick={toggleMainSidebar}
              className="absolute -left-3 top-6 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white p-1.5 rounded-full border border-zinc-700 shadow-lg hidden md:block transition-colors z-50"
              title={isMainSidebarOpen ? "צמצם תפריט" : "הרחב תפריט"}
            >
              {isMainSidebarOpen ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
            </button>
            <div className={`flex flex-col items-center text-center gap-4 mb-2 ${isMainSidebarOpen ? '' : 'md:gap-2'}`}>
              {config?.logoUrl ? (
                <div className={`${isMainSidebarOpen ? 'w-20 h-20' : 'w-10 h-10'} bg-white rounded-2xl p-2 shadow-xl mb-2 relative overflow-hidden transition-all duration-300`}>
                  <img 
                    src={config.logoUrl} 
                    alt="Logo" 
                    className="w-full h-full object-contain" 
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      const fallback = target.nextElementSibling;
                      if (fallback) fallback.classList.remove('hidden');
                    }}
                  />
                  <div className="hidden fallback w-full h-full flex items-center justify-center text-zinc-300">
                    <ShoppingBag size={isMainSidebarOpen ? 32 : 16} />
                  </div>
                </div>
              ) : (
                <div className={`${isMainSidebarOpen ? 'w-12 h-12' : 'w-10 h-10'} bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 mb-2 transition-all duration-300`}>
                  <LayoutDashboard size={isMainSidebarOpen ? 28 : 20} />
                </div>
              )}
              {isMainSidebarOpen && (
                <div className="hidden md:block">
                  <h1 className="text-xl font-bold tracking-tight text-white whitespace-nowrap overflow-hidden text-ellipsis">{config?.siteName || 'מערכת ניהול'}</h1>
                  <p className="text-xs text-indigo-400 font-bold mt-1 whitespace-nowrap overflow-hidden text-ellipsis">{config?.orgName || 'Purchasing System'}</p>
                </div>
              )}
            </div>
          </div>

          <div className="flex-1 p-4 space-y-2 overflow-y-auto overflow-x-hidden">
            {filteredTabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as Tab)}
                title={!isMainSidebarOpen ? tab.label : ''}
                className={`w-full flex items-center ${isMainSidebarOpen ? 'gap-4 px-6' : 'justify-center px-0'} py-4 rounded-2xl font-bold transition-all ${
                  activeTab === tab.id 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                    : 'text-zinc-400 hover:bg-zinc-800 hover:text-white'
                }`}
              >
                <tab.icon size={20} className="shrink-0" />
                {isMainSidebarOpen && <span className="whitespace-nowrap">{tab.label}</span>}
              </button>
            ))}
          </div>

          <div className="p-6 border-t border-zinc-800">
            {user && <Auth user={user} loading={loading} onGuestLogin={handleGuestLogin} />}
            {isGuest && !user && (
              <div className="mt-4 flex items-center justify-between px-4 py-3 bg-zinc-800 rounded-xl border border-zinc-700">
                <div className="flex items-center gap-3">
                  <UserIcon size={16} className="text-zinc-400" />
                  <span className="text-sm font-bold text-zinc-300">אורח</span>
                </div>
                <button 
                  onClick={() => setIsGuest(false)}
                  className="text-xs font-bold text-indigo-400 hover:text-indigo-300"
                >
                  התחבר
                </button>
              </div>
            )}
          </div>
        </nav>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-zinc-50 flex flex-col">
          {isAdmin && <EmailHealthBanner onNavigate={setActiveTab} />}
          <div className="flex-1">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="min-h-full"
              >
                {activeTab === 'shop' && <Shop isAdmin={isAdmin} userRole={userRole} allowedCategories={allowedCategories} onNavigate={setActiveTab} />}
                {activeTab === 'inventory' && (
                  <Inventory 
                    pendingEditId={pendingEditProductId} 
                    onEditHandled={() => setPendingEditProductId(null)} 
                  />
                )}
                {activeTab === 'orders' && <Orders user={user} isAdmin={isAdmin} userRole={userRole} />}
                {activeTab === 'reports' && <Reports />}
                {activeTab === 'users' && <Users userRole={userRole} />}
                {activeTab === 'customers' && <Customers />}
                {activeTab === 'archive' && config?.enableSalesArchive && <Archive />}
                {activeTab === 'settings' && <Settings isAdmin={isAdmin} userRole={userRole} />}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>
    </ErrorBoundary>
  );
}
