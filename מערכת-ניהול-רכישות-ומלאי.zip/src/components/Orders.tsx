import React, { useState, useEffect } from 'react';
import { db, collection, getDocs, getDoc, query, where, orderBy, handleFirestoreError, OperationType, doc, deleteDoc, updateDoc, increment, writeBatch, serverTimestamp, limit, onSnapshot } from '../firebase';
import { Printer, Search, Filter, ChevronDown, Calendar, User, Package, CreditCard, ExternalLink, FileDown, Trash2, AlertTriangle, Edit2, Minus, Plus, Loader2, Save, X, Mail, Send, Check, AlertCircle, CheckCircle2, RotateCw, FileText, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';
import * as XLSX from 'xlsx';
import { dataCache } from '../lib/cache';
import { sendEmail, formatOrderEmail } from '../services/emailService';
import { notifyAdminEmailFailure } from '../services/adminAlertService';

interface OrderItem { productId: string; sku: string; name: string; quantity: number; price: number; variantId?: string; variantName?: string; }
interface Order { 
  id: string; 
  customerId: string; 
  customer?: Record<string, any>; 
  customerName?: string; // For legacy orders
  createdBy?: { uid: string; name: string; email: string; };
  items: OrderItem[]; 
  totalAmount: number; 
  status: string; 
  createdAt: any; 
  updatedAt?: any;
  orderNumber?: number;
  emailSent?: boolean;
  emailSentAt?: any;
  emailSentTo?: string;
  emailFailed?: boolean;
  emailError?: string;
  emailFailedAt?: any;
  emailMessageId?: string;
}

export function Orders({ user, isAdmin, userRole }: { user: any; isAdmin: boolean; userRole?: string }) {
  const isMainUser = userRole === 'main_user';
  const canManageOrders = isAdmin || isMainUser || userRole === 'partial_user';
  const [orders, setOrders] = useState<Order[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [config, setConfig] = useState<any>(null);
  const [orderToDelete, setOrderToDelete] = useState<Order | null>(null);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [editingCustomer, setEditingCustomer] = useState<Record<string, any>>({});
  const [editingTab, setEditingTab] = useState<'items' | 'customer'>('items');
  const [selectedProductForVariant, setSelectedProductForVariant] = useState<any>(null);
  const [newCustomKey, setNewCustomKey] = useState('');
  const [newCustomVal, setNewCustomVal] = useState('');
  const [showAddCustomField, setShowAddCustomField] = useState(false);
  const [products, setProducts] = useState<any[]>([]);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showPrintable, setShowPrintable] = useState<Order | null>(null);
  const [productSearchTerm, setProductSearchTerm] = useState('');
  const [sendingEmailId, setSendingEmailId] = useState<string | null>(null);
  const [sendingAllToday, setSendingAllToday] = useState(false);
  const [customRecipient, setCustomRecipient] = useState('');
  const getFieldLabel = (fieldId: string) => {
    const field = config?.customerFormFields?.find((f: any) => f.id === fieldId);
    return field?.label || fieldId;
  };

  const handleStartEditOrder = (order: Order) => {
    setEditingOrder(order);
    setEditingTab('items');
    setProductSearchTerm('');
    setShowAddCustomField(false);
    setNewCustomKey('');
    setNewCustomVal('');

    const custData: Record<string, any> = {};
    if (order.customer && typeof order.customer === 'object') {
      Object.assign(custData, order.customer);
    }
    if (!custData.name && order.customerName) {
      custData.name = order.customerName;
    }
    if (config?.customerFormFields?.length) {
      config.customerFormFields.forEach((f: any) => {
        if (custData[f.id] === undefined && custData[f.label] !== undefined) {
          custData[f.id] = custData[f.label];
        }
      });
    }
    setEditingCustomer(custData);
  };

  useEffect(() => {
    if (showPrintable) {
      const timer = setTimeout(() => {
        window.print();
      }, 1000);

      const handleAfterPrint = () => {
        setShowPrintable(null);
      };

      window.addEventListener('afterprint', handleAfterPrint);
      return () => {
        clearTimeout(timer);
        window.removeEventListener('afterprint', handleAfterPrint);
      };
    }
  }, [showPrintable]);

  const handlePrint = (order: Order) => {
    setShowPrintable(order);
  };

  useEffect(() => {
    if (!editingOrder) return;
    const fetchProducts = async () => {
      try {
        const snapshot = await getDocs(query(collection(db, 'products'), limit(1000)));
        setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (err) {
        console.error('Error fetching products:', err);
      }
    };
    fetchProducts();
  }, [editingOrder]);

  const handleUpdateOrder = async (
    updatedItems: OrderItem[], 
    updatedStatus: string, 
    updatedCustomer: Record<string, any>
  ) => {
    if (!editingOrder) return;
    const originalOrder = orders.find(o => o.id === editingOrder.id);
    if (!originalOrder) return;

    setIsSaving(true);
    try {
      const batch = writeBatch(db);
      
      const productChanges: Record<string, { totalChange: number, variantChanges: Record<string, number> }> = {};
      
      const addChange = (productId: string, variantId: string | undefined, amount: number) => {
        if (!productChanges[productId]) {
          productChanges[productId] = { totalChange: 0, variantChanges: {} };
        }
        productChanges[productId].totalChange += amount;
        if (variantId) {
          productChanges[productId].variantChanges[variantId] = (productChanges[productId].variantChanges[variantId] || 0) + amount;
        }
      };

      // Logic for stock return/deduction based on status change
      const wasCancelled = originalOrder.status === 'cancelled';
      const isCancelled = updatedStatus === 'cancelled';

      if (isCancelled && !wasCancelled) {
        // Returning all items to stock because order is now cancelled
        for (const item of originalOrder.items) addChange(item.productId, item.variantId, item.quantity);
      } else if (!isCancelled && wasCancelled) {
        // Deducting all items from stock because order is re-activated
        for (const item of updatedItems) addChange(item.productId, item.variantId, -item.quantity);
      } else if (!isCancelled && !wasCancelled) {
        // Normal diff logic for active orders
        for (const item of originalOrder.items) addChange(item.productId, item.variantId, item.quantity);
        for (const item of updatedItems) addChange(item.productId, item.variantId, -item.quantity);
      }
      // If both were cancelled, we don't change stock

      // Apply changes to products and validate stock
      for (const [productId, changes] of Object.entries(productChanges)) {
        if (changes.totalChange === 0 && Object.values(changes.variantChanges).every(v => v === 0)) continue;
        
        const productRef = doc(db, 'products', productId);
        const product = products.find(p => p.id === productId);
        
        let newStockQuantity = (product?.stockQuantity || 0) + changes.totalChange;

        if (changes.totalChange < 0 && newStockQuantity < 0) {
          toast.error(`אין מספיק מלאי עבור ${product?.name || productId}`);
          setIsSaving(false);
          return;
        }
        
        let updatePayload: any = { stockQuantity: newStockQuantity };

        if (product?.variants && Object.keys(changes.variantChanges).length > 0) {
          const newVariants = [...product.variants];
          for (const [vId, vChange] of Object.entries(changes.variantChanges)) {
            if (vChange === 0) continue;
            const vIndex = newVariants.findIndex((v: any) => v.id === vId);
            if (vIndex !== -1) {
              const newVStock = (newVariants[vIndex].stockQuantity || 0) + vChange;
              if (vChange < 0 && newVStock < 0) {
                toast.error(`אין מספיק מלאי עבור תת-המוצר ${newVariants[vIndex].name}`);
                setIsSaving(false);
                return;
              }
              newVariants[vIndex] = { ...newVariants[vIndex], stockQuantity: newVStock };
            }
          }
          updatePayload.variants = newVariants;
        }

        batch.update(productRef, updatePayload);
      }
      
      const newTotal = updatedItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);
      
      // Derive primary customerName from updatedCustomer
      let primaryName = updatedCustomer.name || updatedCustomer.fullName;
      if (!primaryName && config?.customerFormFields?.length) {
        for (const f of config.customerFormFields) {
          if (f.label?.includes('שם') || f.id?.includes('name')) {
            if (updatedCustomer[f.id]) {
              primaryName = updatedCustomer[f.id];
              break;
            }
          }
        }
        if (!primaryName && updatedCustomer[config.customerFormFields[0].id]) {
          primaryName = updatedCustomer[config.customerFormFields[0].id];
        }
      }
      if (!primaryName) {
        primaryName = Object.values(updatedCustomer)[0] || editingOrder.customerName || 'לקוח';
      }

      batch.update(doc(db, 'orders', editingOrder.id), {
        items: updatedItems,
        totalAmount: newTotal,
        status: updatedStatus,
        customer: updatedCustomer,
        customerName: primaryName,
        updatedAt: serverTimestamp()
      });
      
      await batch.commit();
      
      // Update local state immediately
      setOrders(prev => prev.map(o => 
        o.id === editingOrder.id 
          ? { 
              ...o, 
              items: updatedItems, 
              totalAmount: newTotal, 
              status: updatedStatus as any, 
              customer: updatedCustomer, 
              customerName: primaryName 
            } 
          : o
      ));

      if (selectedOrder && selectedOrder.id === editingOrder.id) {
        setSelectedOrder(prev => prev ? {
          ...prev,
          items: updatedItems,
          totalAmount: newTotal,
          status: updatedStatus as any,
          customer: updatedCustomer,
          customerName: primaryName
        } : null);
      }

      // Clear products cache to ensure other components get fresh stock
      dataCache.products = {};

      toast.success('ההזמנה עודכנה בהצלחה');
      
      // Auto-resend email if one was already sent or if auto-notify is enabled
      const updatedOrderObj = { 
        ...originalOrder, 
        items: updatedItems, 
        totalAmount: newTotal, 
        status: updatedStatus as any, 
        customer: updatedCustomer, 
        customerName: primaryName 
      };
      
      if (originalOrder.emailSent || originalOrder.emailMessageId || config?.emailSettings?.notifyNewOrder !== false) {
        // Find recipient: use the previously sent email or default to reportEmail
        const recipient = originalOrder.emailSentTo || config?.emailSettings?.reportEmail;
        if (recipient) {
          handleSendOrderEmail(updatedOrderObj, recipient);
        }
      }

      setEditingOrder(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'orders');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteOrder = async (returnToStock: boolean) => {
    if (!orderToDelete) return;
    setIsDeleting(true);
    try {
      const batch = writeBatch(db);
      
      // Only return to stock if requested AND the order wasn't already cancelled
      if (returnToStock && orderToDelete.status !== 'cancelled') {
        const productChanges: Record<string, { totalChange: number, variantChanges: Record<string, number> }> = {};
        for (const item of orderToDelete.items) {
          if (!productChanges[item.productId]) {
            productChanges[item.productId] = { totalChange: 0, variantChanges: {} };
          }
          productChanges[item.productId].totalChange += item.quantity;
          if (item.variantId) {
            productChanges[item.productId].variantChanges[item.variantId] = (productChanges[item.productId].variantChanges[item.variantId] || 0) + item.quantity;
          }
        }
        
        for (const [productId, changes] of Object.entries(productChanges)) {
          const productRef = doc(db, 'products', productId);
          const product = products.find(p => p.id === productId);
          let updatePayload: any = { stockQuantity: increment(changes.totalChange) };
          
          if (product?.variants && Object.keys(changes.variantChanges).length > 0) {
            const newVariants = [...product.variants];
            for (const [vId, vChange] of Object.entries(changes.variantChanges)) {
              const vIndex = newVariants.findIndex((v: any) => v.id === vId);
              if (vIndex !== -1) {
                newVariants[vIndex] = { ...newVariants[vIndex], stockQuantity: (newVariants[vIndex].stockQuantity || 0) + vChange };
              }
            }
            updatePayload.variants = newVariants;
          }
          batch.update(productRef, updatePayload);
        }
      }
      
      batch.delete(doc(db, 'orders', orderToDelete.id));
      await batch.commit();
      
      // Update local state immediately
      setOrders(prev => prev.filter(o => o.id !== orderToDelete.id));

      // Clear products cache to ensure other components get fresh stock
      dataCache.products = {};

      toast.success(returnToStock && orderToDelete.status !== 'cancelled' ? 'ההזמנה נמחקה והמלאי עודכן' : 'ההזמנה נמחקה');
      setOrderToDelete(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'orders');
    } finally {
      setIsDeleting(false);
    }
  };

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const snapshot = await getDoc(doc(db, 'config', 'system'));
        if (snapshot.exists()) {
          setConfig(snapshot.data());
        }
      } catch (err) {
        console.error('Error fetching config:', err);
      }
    };
    fetchConfig();
  }, []);

  useEffect(() => {
    let q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    
    // Server-side filtering for regular users
    if (userRole === 'user' && !isAdmin && !isMainUser && user?.uid) {
      q = query(collection(db, 'orders'), where('createdBy.uid', '==', user.uid), orderBy('createdAt', 'desc'));
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setOrders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order)));
    }, (err) => {
      // Handle index errors gracefully
      if (err instanceof Error && err.message.includes('index')) {
        console.warn('Firestore index missing for filtered orders query. Falling back to basic query.');
        // Fallback to basic query if index is missing
        const fallbackQ = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
        onSnapshot(fallbackQ, (s) => {
          const allProds = s.docs.map(d => ({ id: d.id, ...d.data() } as Order));
          if (userRole === 'user' && !isAdmin && !isMainUser && user?.uid) {
            setOrders(allProds.filter(o => o.createdBy?.uid === user.uid));
          } else {
            setOrders(allProds);
          }
        });
      } else {
        handleFirestoreError(err, OperationType.LIST, 'orders');
      }
    });

    return () => unsubscribe();
  }, [userRole, user?.uid, isAdmin, isMainUser]);

  const exportToExcel = async () => {
    const ordersToExport = searchTerm.trim() ? filteredOrders : orders;
    if (ordersToExport.length === 0) {
      toast.error('אין הזמנות לייצוא');
      return;
    }

    const data = ordersToExport.map(o => {
      const dateStr = o.createdAt?.toDate ? o.createdAt.toDate().toLocaleDateString('he-IL') : (o.createdAt ? new Date(o.createdAt).toLocaleDateString('he-IL') : '-');
      const timeStr = o.createdAt?.toDate ? o.createdAt.toDate().toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }) : (o.createdAt ? new Date(o.createdAt).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }) : '');
      const row: any = {
        'מספר הזמנה': o.orderNumber || o.id,
        'בוצע ע"י': o.createdBy?.name || 'אורח',
        'תאריך': dateStr,
        'שעה': timeStr,
        'סה"כ': o.totalAmount,
        'סטטוס': o.status === 'pending' ? 'ממתין' : o.status === 'completed' ? 'הושלם' : 'בוטל',
        'פריטים': o.items.map(i => `${i.name}${i.variantName ? ` (${i.variantName})` : ''} (${i.quantity})`).join(', ')
      };

      // Add customer fields dynamically based on form config
      config?.customerFormFields?.forEach((field: any) => {
        row[field.label] = o.customer?.[field.id] || o.customer?.[field.label] || '-';
      });

      // Add any other customer fields not in config
      Object.entries(o.customer || {}).forEach(([key, val]) => {
        const label = getFieldLabel(key);
        if (!row[label]) row[label] = val;
      });

      return row;
    });
    
    const ws = XLSX.utils.json_to_sheet(data);
    
    // Add branding info at the top if available
    if (config?.siteName || config?.orgName) {
      XLSX.utils.sheet_add_aoa(ws, [
        [config.orgName || ''],
        [config.siteName || ''],
        []
      ], { origin: "A1" });
      
      // Shift existing data down
      const range = XLSX.utils.decode_range(ws['!ref']!);
      range.e.r += 3;
      ws['!ref'] = XLSX.utils.encode_range(range);
    }

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Orders');
    XLSX.writeFile(wb, 'orders_export.xlsx');
    toast.success(`יוצאו בהצלחה ${ordersToExport.length} הזמנות לקובץ אקסל`);

    // Send copy by email if configured
    try {
      if (!config?.emailSettings?.disableAllEmails && config?.emailReports?.copyOnExport && config?.emailReports?.recipientEmail) {
        const base64 = XLSX.write(wb, { bookType: 'xlsx', type: 'base64' });
        await sendEmail({
          to: config.emailReports.recipientEmail,
          subject: `דוח הזמנות - ${config.siteName || 'מערכת רכש'}`,
          html: `
            <div dir="rtl" style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
              <h2 style="color: #2563eb;">דוח הזמנות</h2>
              <p>שלום רב,</p>
              <p>מצורף בזאת דוח הזמנות עדכני שהופק ממערכת <strong>${config.siteName || 'מערכת רכש'}</strong>.</p>
              <p><strong>תאריך הפקה:</strong> ${new Date().toLocaleDateString('he-IL')} בשעה ${new Date().toLocaleTimeString('he-IL')}</p>
              <p>הדוח מצורף כקובץ אקסל (Excel) וכולל את כל פרטי ההזמנות שיוצאו.</p>
              <br/>
              <p>בברכה,<br/>צוות המערכת</p>
            </div>
          `,
          attachments: [{
            filename: 'orders_export.xlsx',
            content: base64,
            contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
          }]
        });
        toast.success('עותק מהדוח נשלח לאימייל');
      }
    } catch (err) {
      console.error('Failed to send report email:', err);
    }
  };

  const isOrderFromToday = (createdAt: any) => {
    if (!createdAt) return false;
    try {
      const date = createdAt.toDate ? createdAt.toDate() : new Date(createdAt);
      const today = new Date();
      return date.getDate() === today.getDate() &&
             date.getMonth() === today.getMonth() &&
             date.getFullYear() === today.getFullYear();
    } catch (e) {
      return false;
    }
  };

  const todayOrders = orders.filter(o => isOrderFromToday(o.createdAt));
  const unsentTodayOrders = todayOrders.filter(o => !o.emailSent);

  const isEmailOutdated = (order: Order) => {
    if (!order.emailSentAt || !order.updatedAt) return false;
    try {
      const emailTime = order.emailSentAt.toMillis ? order.emailSentAt.toMillis() : new Date(order.emailSentAt).getTime();
      const updateTime = order.updatedAt.toMillis ? order.updatedAt.toMillis() : new Date(order.updatedAt).getTime();
      // Add a 5 second buffer to ignore the update that happens when we just sent the email
      return updateTime > (emailTime + 5000);
    } catch (e) {
      return false;
    }
  };

  const handleSendOrderEmail = async (order: Order, targetRecipient?: string) => {
    if (!config) return;
    setSendingEmailId(order.id);
    const orderNum = order.orderNumber ? `#${order.orderNumber}` : `#${order.id.slice(0, 8)}`;
    const toastId = toast.loading(`שולח מייל עבור הזמנה ${orderNum}...`);

    let recipient: string | undefined = targetRecipient || config.emailSettings?.reportEmail;
    try {
      const emailContent = formatOrderEmail(order, config, order.customer || {});
      
      let replyTo: string | undefined;
      if (config.emailSettings?.replyToType === 'fixed') {
        replyTo = config.emailSettings.fixedReplyToEmail;
      }
      const userEmail = config.emailSettings?.senderChoice === 'user' ? (order.createdBy?.email || config.emailSettings?.mainEmail) : config.emailSettings?.mainEmail;
      const userName = config.emailSettings?.senderChoice === 'user' ? (order.createdBy?.name || config.siteName) : config.siteName;

      const emailField = config.customerFormFields?.find((f: any) => f.type === 'email');
      const customerEmail = emailField ? order.customer?.[emailField.id] : order.customer?.email;
      recipient = targetRecipient || config.emailSettings?.reportEmail || customerEmail;

      if (!recipient) {
        toast.error('לא הוגדרה כתובת אימייל לנמען בהגדרות המערכת או בפרטי הלקוח', { id: toastId });
        return;
      }

      const res = await sendEmail({
        to: recipient,
        subject: order.emailMessageId ? `Re: ${emailContent.subject}` : emailContent.subject,
        html: emailContent.html,
        userEmail: userEmail || undefined,
        userName: userName || undefined,
        replyTo: replyTo || undefined,
        replyToMessageId: order.emailMessageId || undefined
      });

      if (res.success) {
        try {
          const updateData: any = {
            emailSent: true,
            emailSentAt: serverTimestamp(),
            emailSentTo: recipient,
            emailFailed: false,
            emailError: null
          };
          if (res.messageId && !order.emailMessageId) {
            updateData.emailMessageId = res.messageId;
            order.emailMessageId = res.messageId; // Update local order object so subsequent sends thread correctly
          }
          await updateDoc(doc(db, 'orders', order.id), updateData);
        } catch (e) {
          console.warn('Could not update order status in firestore:', e);
        }
        toast.success(`אישור הזמנה ${orderNum} נשלח בהצלחה ל-${recipient}!`, { id: toastId });
        if (selectedOrder && selectedOrder.id === order.id) {
          setSelectedOrder({ ...selectedOrder, emailSent: true, emailSentTo: recipient, emailFailed: false, emailError: undefined, emailMessageId: selectedOrder.emailMessageId || res.messageId });
        }
      } else {
        const errorReason = res.error || (res.reason === 'bad_credentials' ? 'שגיאת אימות שרת דואר (535 Bad Credentials)' : 'שליחת מייל נכשלה בשרת');
        try {
          await updateDoc(doc(db, 'orders', order.id), {
            emailSent: false,
            emailFailed: true,
            emailError: errorReason,
            emailFailedAt: serverTimestamp(),
            emailSentTo: recipient
          });
        } catch (e) {}

        toast.error(`שליחה נכשלה: ${errorReason}`, { id: toastId });
        notifyAdminEmailFailure({
          orderId: order.id,
          orderNumber: order.orderNumber,
          customerName: order.customerName || (order.customer ? Object.values(order.customer).join(' ') : undefined),
          error: errorReason,
          recipient,
          totalAmount: order.totalAmount,
          onRetry: () => handleSendOrderEmail(order, targetRecipient)
        });
      }
    } catch (err: any) {
      const errMsg = err?.message || 'שגיאה בשליחת המייל';
      try {
        await updateDoc(doc(db, 'orders', order.id), {
          emailSent: false,
          emailFailed: true,
          emailError: errMsg,
          emailFailedAt: serverTimestamp(),
          emailSentTo: recipient
        });
      } catch (e) {}

      toast.error(`שגיאה בשליחת המייל: ${errMsg}`, { id: toastId });
      notifyAdminEmailFailure({
        orderId: order.id,
        orderNumber: order.orderNumber,
        customerName: order.customerName || (order.customer ? Object.values(order.customer).join(' ') : undefined),
        error: errMsg,
        recipient,
        totalAmount: order.totalAmount,
        onRetry: () => handleSendOrderEmail(order, targetRecipient)
      });
    } finally {
      setSendingEmailId(null);
    }
  };

  const handleSendAllTodayOrders = async () => {
    const targets = unsentTodayOrders.length > 0 ? unsentTodayOrders : todayOrders;
    if (targets.length === 0) {
      toast('לא נמצאו הזמנות מהיום לשליחה', { icon: 'ℹ️' });
      return;
    }

    setSendingAllToday(true);
    const toastId = toast.loading(`שולח מיילים ל-${targets.length} הזמנות מהיום...`);
    let sentCount = 0;
    let failCount = 0;

    for (let i = 0; i < targets.length; i++) {
      const order = targets[i];
      try {
        const emailContent = formatOrderEmail(order, config, order.customer || {});
        let replyTo: string | undefined;
        if (config.emailSettings?.replyToType === 'fixed') {
          replyTo = config.emailSettings.fixedReplyToEmail;
        }
        const userEmail = config.emailSettings?.senderChoice === 'user' ? (order.createdBy?.email || config.emailSettings?.mainEmail) : config.emailSettings?.mainEmail;
        const userName = config.emailSettings?.senderChoice === 'user' ? (order.createdBy?.name || config.siteName) : config.siteName;

        const emailField = config.customerFormFields?.find((f: any) => f.type === 'email');
        const customerEmail = emailField ? order.customer?.[emailField.id] : order.customer?.email;
        const recipient = config.emailSettings?.reportEmail || customerEmail;

        if (recipient) {
          const res = await sendEmail({
            to: recipient,
            subject: emailContent.subject,
            html: emailContent.html,
            userEmail: userEmail || undefined,
            userName: userName || undefined,
            replyTo: replyTo || undefined
          });

          if (res.success) {
            sentCount++;
            await updateDoc(doc(db, 'orders', order.id), {
              emailSent: true,
              emailSentAt: serverTimestamp(),
              emailSentTo: recipient,
              emailFailed: false,
              emailError: null
            }).catch(() => {});
          } else {
            failCount++;
            const reason = res.error || (res.reason === 'bad_credentials' ? 'שגיאת אימות שרת דואר (535)' : 'שליחת מייל נכשלה');
            await updateDoc(doc(db, 'orders', order.id), {
              emailSent: false,
              emailFailed: true,
              emailError: reason,
              emailFailedAt: serverTimestamp(),
              emailSentTo: recipient
            }).catch(() => {});

            notifyAdminEmailFailure({
              orderId: order.id,
              orderNumber: order.orderNumber,
              customerName: order.customerName || (order.customer ? Object.values(order.customer).join(' ') : undefined),
              error: reason,
              recipient,
              totalAmount: order.totalAmount
            });
          }
        } else {
          failCount++;
          notifyAdminEmailFailure({
            orderId: order.id,
            orderNumber: order.orderNumber,
            customerName: order.customerName || (order.customer ? Object.values(order.customer).join(' ') : undefined),
            error: 'לא הוגדרה כתובת אימייל לנמען',
            totalAmount: order.totalAmount
          });
        }
      } catch (err: any) {
        failCount++;
        const errTxt = err?.message || 'שגיאת תקשורת עם שרת הדואר';
        notifyAdminEmailFailure({
          orderId: order.id,
          orderNumber: order.orderNumber,
          customerName: order.customerName || (order.customer ? Object.values(order.customer).join(' ') : undefined),
          error: errTxt,
          totalAmount: order.totalAmount
        });
      }
    }

    setSendingAllToday(false);
    if (failCount === 0) {
      toast.success(`כל ${sentCount} המיילים להזמנות היום נשלחו בהצלחה!`, { id: toastId, duration: 5000 });
    } else {
      toast.success(`הושלם: ${sentCount} מיילים נשלחו בהצלחה (${failCount} נכשלו).`, { id: toastId, duration: 5000 });
    }
  };

  const filteredOrders = orders.filter(o => {
    const customerStr = (o.customerName || Object.values(o.customer || {}).join(' ')).toLowerCase();
    const creatorStr = (o.createdBy?.name || '').toLowerCase();
    return customerStr.includes(searchTerm.toLowerCase()) ||
           creatorStr.includes(searchTerm.toLowerCase()) ||
           o.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
           (o.orderNumber && o.orderNumber.toString().includes(searchTerm));
  });

  return (
    <>
      <div className="no-print p-6 max-w-7xl mx-auto font-sans text-right" dir="rtl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-3xl font-bold text-zinc-900 tracking-tight">ניהול הזמנות</h2>
            <span className="px-3 py-1 bg-indigo-50 border border-indigo-100 text-indigo-700 text-xs font-bold rounded-full">
              {searchTerm ? `${filteredOrders.length} מתוך ${orders.length} הזמנות` : `${orders.length} הזמנות`}
            </span>
          </div>
          <p className="text-zinc-500 mt-1">צפה בכל ההזמנות שבוצעו במערכת, שלח אישורי הזמנה וייצא דוחות</p>
        </div>
        {canManageOrders && (
          <div className="flex flex-wrap items-center gap-3">
            {todayOrders.length > 0 && (
              <button
                onClick={handleSendAllTodayOrders}
                disabled={sendingAllToday}
                className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-indigo-700 transition-all flex items-center gap-2 shadow-lg shadow-indigo-500/20 disabled:opacity-50"
                title="שליחת מייל אישור להזמנות היום"
              >
                {sendingAllToday ? <Loader2 size={18} className="animate-spin" /> : <Mail size={18} />}
                <span>
                  שלח מיילים להזמנות היום
                  {unsentTodayOrders.length > 0 ? ` (${unsentTodayOrders.length} ממתינות)` : ` (${todayOrders.length})`}
                </span>
              </button>
            )}
            <button
              onClick={exportToExcel}
              className="bg-green-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-green-700 transition-all flex items-center gap-2 shadow-lg shadow-green-500/20"
              title="ייצוא כל ההזמנות לקובץ אקסל"
            >
              <FileDown size={18} />
              <span>ייצוא לאקסל ({searchTerm.trim() ? filteredOrders.length : orders.length})</span>
            </button>
          </div>
        )}
      </div>

      {/* Banner for unsent today's orders */}
      {canManageOrders && unsentTodayOrders.length > 0 && (
        <div className="mb-6 p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-950 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-200/80 rounded-xl text-amber-900 shrink-0">
              <Mail size={22} />
            </div>
            <div>
              <p className="font-extrabold text-sm text-amber-950">
                נמצאו {unsentTodayOrders.length} הזמנות מהיום שטרם נשלח להן מייל אישור!
              </p>
              <p className="text-xs text-amber-800">
                שרת הדואר מחובר ומאומת כעת. ניתן לשלוח כעת את כל המיילים בלחיצה אחת.
              </p>
            </div>
          </div>
          <button
            onClick={handleSendAllTodayOrders}
            disabled={sendingAllToday}
            className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 disabled:opacity-50 shrink-0"
          >
            {sendingAllToday ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
            <span>{sendingAllToday ? 'שולח כעת...' : `שלח מייל כעת לכל ${unsentTodayOrders.length} ההזמנות מהיום`}</span>
          </button>
        </div>
      )}

      <div className="mb-6 relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
        <input
          type="text"
          placeholder="חיפוש לפי שם לקוח או מספר הזמנה..."
          className="w-full pr-10 pl-4 py-3 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
          value={searchTerm || ''}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="bg-white rounded-3xl border border-zinc-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead className="bg-zinc-50 border-b border-zinc-100">
              <tr>
                <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase tracking-wider">מספר הזמנה</th>
                <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase tracking-wider">לקוח</th>
                <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase tracking-wider">תאריך</th>
                <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase tracking-wider">סה"כ</th>
                <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase tracking-wider">סטטוס</th>
                <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase tracking-wider">פעולות</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {filteredOrders.map(order => (
                <tr key={order.id} className="hover:bg-zinc-50 transition-colors group">
                  <td className="px-6 py-4 font-mono text-xs text-zinc-500">
                    {order.orderNumber ? (
                      <span className="font-bold text-indigo-600 text-sm">#{order.orderNumber}</span>
                    ) : (
                      <span>#{order.id.slice(0, 8)}</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-bold text-zinc-900">
                        {order.customerName || order.customer?.name || Object.values(order.customer || {})[0] || 'לקוח'}
                      </span>
                      <span className="text-[10px] text-zinc-400">בוצע ע"י: {order.createdBy?.name || 'אורח'}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-zinc-500 text-sm">
                    {order.createdAt?.toDate().toLocaleDateString('he-IL')}
                  </td>
                  <td className="px-6 py-4 font-bold text-zinc-900">₪{order.totalAmount}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      order.status === 'pending' ? 'bg-amber-100 text-amber-600' :
                      order.status === 'completed' ? 'bg-green-100 text-green-600' :
                      'bg-red-100 text-red-600'
                    }`}>
                      {order.status === 'pending' ? 'ממתין' : order.status === 'completed' ? 'הושלם' : 'בוטל'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleSendOrderEmail(order)}
                        disabled={sendingEmailId === order.id}
                        className={`p-2 transition-colors rounded-lg ${
                          !order.emailSent 
                            ? 'text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 border border-red-200'
                            : isEmailOutdated(order)
                              ? 'text-orange-500 hover:text-orange-600 bg-orange-50 hover:bg-orange-100 border border-orange-200'
                              : 'text-zinc-400 hover:text-indigo-600 hover:bg-indigo-50' 
                        }`}
                        title={
                          !order.emailSent 
                            ? (order.emailFailed ? `שליחת מייל נכשלה: ${order.emailError || 'שגיאת שרת'} (לחץ לשליחה כעת)` : 'לא נשלח מייל (לחץ לשליחה כעת)')
                            : isEmailOutdated(order)
                              ? 'ההזמנה עודכנה לאחר שליחת המייל (לחץ לשליחה חוזרת)'
                              : (order.emailSentAt ? `מייל נשלח ב-${order.emailSentAt?.toDate ? order.emailSentAt.toDate().toLocaleString('he-IL') : new Date(order.emailSentAt).toLocaleString('he-IL')} (לחץ לשליחה חוזרת)` : 'מייל נשלח (לחץ לשליחה חוזרת)')
                        }
                      >
                        {sendingEmailId === order.id ? (
                          <Loader2 size={18} className="animate-spin text-indigo-600" />
                        ) : (
                          <Mail size={18} className={
                            !order.emailSent ? 'text-red-600' : isEmailOutdated(order) ? 'text-orange-500' : 'text-zinc-400'
                          } />
                        )}
                      </button>
                      {canManageOrders && (
                        <button
                          onClick={() => handleStartEditOrder(order)}
                          className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors rounded-lg"
                          title="ערוך הזמנה"
                        >
                          <Edit2 size={18} />
                        </button>
                      )}
                      <button
                        onClick={() => setSelectedOrder(order)}
                        className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors rounded-lg"
                        title="פרטי הזמנה"
                      >
                        <ExternalLink size={18} />
                      </button>
                      <button
                        onClick={() => handlePrint(order)}
                        className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors rounded-lg"
                        title="הדפס הזמנה"
                      >
                        <Printer size={18} />
                      </button>
                      {canManageOrders && (
                        <button
                          onClick={() => setOrderToDelete(order)}
                          className="p-2 text-zinc-400 hover:text-red-600 hover:bg-red-50 transition-colors rounded-lg"
                          title="מחק הזמנה"
                        >
                          <Trash2 size={18} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Order Modal */}
      <AnimatePresence>
        {editingOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !isSaving && setEditingOrder(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-3xl shadow-2xl max-w-3xl w-full overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                <div className="flex items-center gap-3">
                  <h3 className="text-xl font-bold text-zinc-900">
                    עריכת הזמנה {editingOrder.orderNumber ? `#${editingOrder.orderNumber}` : `#${editingOrder.id.slice(0, 8)}`}
                  </h3>
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                    editingOrder.status === 'pending' ? 'bg-amber-100 text-amber-600' :
                    editingOrder.status === 'completed' ? 'bg-green-100 text-green-600' :
                    'bg-red-100 text-red-600'
                  }`}>
                    {editingOrder.status === 'pending' ? 'ממתין' : editingOrder.status === 'completed' ? 'הושלם' : 'בוטל'}
                  </span>
                </div>
                <button onClick={() => { setEditingOrder(null); setProductSearchTerm(''); setSelectedProductForVariant(null); }} className="text-zinc-400 hover:text-zinc-600 p-1.5 rounded-xl hover:bg-zinc-200/60 transition-colors"><X size={20} /></button>
              </div>

              {/* Status and Tab Bar */}
              <div className="px-6 pt-4 pb-0 bg-white border-b border-zinc-100 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingTab('items')}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-sm font-bold border-b-2 transition-all ${
                      editingTab === 'items'
                        ? 'border-indigo-600 text-indigo-600 bg-indigo-50/50'
                        : 'border-transparent text-zinc-500 hover:text-zinc-800 hover:bg-zinc-50'
                    }`}
                  >
                    <ShoppingBag size={16} />
                    <span>פריטי הזמנה ומלאי</span>
                    <span className="px-2 py-0.5 rounded-full text-xs bg-zinc-100 text-zinc-600 font-semibold">{editingOrder.items.length}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingTab('customer')}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-sm font-bold border-b-2 transition-all ${
                      editingTab === 'customer'
                        ? 'border-indigo-600 text-indigo-600 bg-indigo-50/50'
                        : 'border-transparent text-zinc-500 hover:text-zinc-800 hover:bg-zinc-50'
                    }`}
                  >
                    <FileText size={16} />
                    <span>עריכת טופס הלקוח</span>
                    <span className="px-2 py-0.5 rounded-full text-xs bg-indigo-100 text-indigo-700 font-semibold">
                      {Object.keys(editingCustomer).filter(k => editingCustomer[k]).length}
                    </span>
                  </button>
                </div>

                <div className="flex items-center gap-2 pb-2">
                  <span className="text-xs font-bold text-zinc-500">סטטוס:</span>
                  <select
                    className="px-3 py-1.5 bg-zinc-50 border border-zinc-200 rounded-xl text-xs font-semibold outline-none focus:ring-2 focus:ring-indigo-500"
                    value={editingOrder.status}
                    onChange={(e) => setEditingOrder({ ...editingOrder, status: e.target.value })}
                  >
                    <option value="pending">ממתין</option>
                    <option value="completed">הושלם</option>
                    <option value="cancelled">בוטל</option>
                  </select>
                </div>
              </div>

              <div className="p-6 space-y-6">
                {editingTab === 'items' && (
                  <div className="space-y-4">
                    <div className="max-h-[300px] overflow-y-auto space-y-3 pr-1">
                      {editingOrder.items.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-4 p-4 bg-zinc-50 rounded-2xl border border-zinc-100 hover:border-zinc-200 transition-all">
                          <div className="flex-1">
                            <p className="font-bold text-zinc-900">
                              {item.name}
                              {item.variantName && <span className="text-zinc-500 font-normal mr-1 text-sm">({item.variantName})</span>}
                            </p>
                            <div className="flex items-center gap-2 mt-0.5">
                              <p className="text-xs text-zinc-500">מחיר יח': ₪{item.price}</p>
                              {products.find(p => p.id === item.productId)?.description && (
                                <span className="text-zinc-300">|</span>
                              )}
                              {products.find(p => p.id === item.productId)?.description && (
                                <p className="text-[11px] text-zinc-500 italic line-clamp-1">{products.find(p => p.id === item.productId).description}</p>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <button 
                              onClick={() => {
                                const newItems = [...editingOrder.items];
                                const currentQty = Number(newItems[idx].quantity) || 1;
                                if (currentQty > 1) {
                                  newItems[idx].quantity = currentQty - 1;
                                  setEditingOrder({ ...editingOrder, items: newItems });
                                }
                              }}
                              className="p-1 bg-white border border-zinc-200 rounded-lg text-zinc-400 hover:text-indigo-600 shrink-0"
                            >
                              <Minus size={16} />
                            </button>
                            <input
                              type="number"
                              min="1"
                              value={item.quantity === 0 ? '' : item.quantity}
                              onChange={(e) => {
                                const val = e.target.value === '' ? 0 : parseInt(e.target.value);
                                if (!isNaN(val) && val >= 0) {
                                  const newItems = [...editingOrder.items];
                                  newItems[idx].quantity = val;
                                  setEditingOrder({ ...editingOrder, items: newItems });
                                }
                              }}
                              onBlur={(e) => {
                                if (!item.quantity || item.quantity < 1) {
                                  const newItems = [...editingOrder.items];
                                  newItems[idx].quantity = 1;
                                  setEditingOrder({ ...editingOrder, items: newItems });
                                }
                              }}
                              className="font-bold w-14 text-center bg-white border border-zinc-200 rounded-lg py-1 px-1 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                            />
                            <button 
                              onClick={() => {
                                const newItems = [...editingOrder.items];
                                const currentQty = Number(newItems[idx].quantity) || 0;
                                newItems[idx].quantity = currentQty + 1;
                                setEditingOrder({ ...editingOrder, items: newItems });
                              }}
                              className="p-1 bg-white border border-zinc-200 rounded-lg text-zinc-400 hover:text-indigo-600 shrink-0"
                            >
                              <Plus size={16} />
                            </button>
                          </div>
                          <button 
                            onClick={() => {
                              const newItems = editingOrder.items.filter((_, i) => i !== idx);
                              setEditingOrder({ ...editingOrder, items: newItems });
                            }}
                            className="p-2 text-red-400 hover:text-red-600"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      ))}
                    </div>

                    <div className="space-y-3 pt-3 border-t border-zinc-100">
                      {selectedProductForVariant ? (
                        <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4">
                          <div className="flex justify-between items-center mb-3">
                            <h4 className="font-bold text-indigo-900 text-sm">בחר תת-מוצר עבור {selectedProductForVariant.name}</h4>
                            <button onClick={() => setSelectedProductForVariant(null)} className="text-indigo-500 hover:text-indigo-700">
                              <X size={16} />
                            </button>
                          </div>
                          <div className="space-y-2 max-h-40 overflow-y-auto">
                            {selectedProductForVariant.variants.map((v: any) => (
                              <button
                                key={v.id}
                                onClick={() => {
                                  const existing = editingOrder.items.find(i => i.productId === selectedProductForVariant.id && i.variantId === v.id);
                                  if (existing) {
                                    toast.error('תת-מוצר זה כבר קיים בהזמנה');
                                  } else {
                                    const newItem: OrderItem = {
                                      productId: selectedProductForVariant.id,
                                      sku: selectedProductForVariant.sku,
                                      name: selectedProductForVariant.name,
                                      quantity: 1,
                                      price: v.price !== undefined ? v.price : selectedProductForVariant.price,
                                      variantId: v.id,
                                      variantName: v.name
                                    };
                                    setEditingOrder({
                                      ...editingOrder,
                                      items: [...editingOrder.items, newItem]
                                    });
                                    setSelectedProductForVariant(null);
                                    setProductSearchTerm('');
                                    toast.success('המוצר נוסף');
                                  }
                                }}
                                className="w-full text-right px-3 py-2 bg-white rounded-lg hover:bg-indigo-100 transition-colors flex justify-between items-center border border-indigo-100"
                              >
                                <span className="text-sm font-medium text-indigo-900">{v.name}</span>
                                <span className="text-xs text-indigo-600 font-bold">₪{v.price !== undefined ? v.price : selectedProductForVariant.price} | מלאי: {v.stockQuantity}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <>
                          <p className="text-xs font-bold text-zinc-700">הוספת מוצר להזמנה:</p>
                          <div className="relative">
                            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                            <input
                              type="text"
                              placeholder="חפש מוצר לפי שם או מק״ט..."
                              className="w-full pr-10 pl-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                              value={productSearchTerm || ''}
                              onChange={(e) => setProductSearchTerm(e.target.value)}
                            />
                          </div>
                          
                          {productSearchTerm && (
                            <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden max-h-40 overflow-y-auto shadow-lg">
                              {products
                                .filter(p => p.name.toLowerCase().includes(productSearchTerm.toLowerCase()) || p.sku.toLowerCase().includes(productSearchTerm.toLowerCase()))
                                .map(product => (
                                  <button
                                    key={product.id}
                                    onClick={() => {
                                      if (product.variants && product.variants.length > 0) {
                                        setSelectedProductForVariant(product);
                                      } else {
                                        const existing = editingOrder.items.find(i => i.productId === product.id && !i.variantId);
                                        if (existing) {
                                          toast.error('המוצר כבר קיים בהזמנה');
                                        } else {
                                          const newItem: OrderItem = {
                                            productId: product.id,
                                            sku: product.sku,
                                            name: product.name,
                                            quantity: 1,
                                            price: product.price
                                          };
                                          setEditingOrder({
                                            ...editingOrder,
                                            items: [...editingOrder.items, newItem]
                                          });
                                          setProductSearchTerm('');
                                          toast.success('המוצר נוסף');
                                        }
                                      }
                                    }}
                                    className="w-full text-right px-4 py-2 hover:bg-zinc-50 text-sm border-b border-zinc-100 last:border-0"
                                  >
                                    <div className="flex flex-col gap-0.5">
                                      <div className="flex justify-between items-center">
                                        <span className="font-bold">{product.name}</span>
                                        <span className="text-zinc-400 text-xs">
                                          ₪{product.price} | {product.variants?.length ? `${product.variants.length} תת-מוצרים` : `מלאי: ${product.stockQuantity}`}
                                        </span>
                                      </div>
                                      {product.description && (
                                        <p className="text-[10px] text-zinc-500 line-clamp-1 italic">{product.description}</p>
                                      )}
                                    </div>
                                  </button>
                                ))}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                )}

                {editingTab === 'customer' && (
                  <div className="space-y-4">
                    <div className="bg-indigo-50/70 border border-indigo-100/80 rounded-2xl p-4 flex items-start gap-3">
                      <div className="p-2 bg-indigo-100 text-indigo-700 rounded-xl mt-0.5 shrink-0">
                        <FileText size={18} />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-indigo-950">עריכת שדות הטופס שמולא</h4>
                        <p className="text-xs text-indigo-700 mt-0.5">
                          באפשרותך לערוך, להוסיף או לתקן את הנתונים שהוזנו בטופס הלקוח בעת ביצוע ההזמנה.
                        </p>
                      </div>
                    </div>

                    <div className="max-h-[320px] overflow-y-auto space-y-4 pr-1 pl-1">
                      {/* Form Fields from System Config */}
                      {config?.customerFormFields && config.customerFormFields.length > 0 ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                          {config.customerFormFields.map((field: any) => {
                            const val = editingCustomer[field.id] ?? editingCustomer[field.label] ?? '';
                            return (
                              <div key={field.id} className="space-y-1">
                                <label className="block text-xs font-bold text-zinc-700">
                                  {field.label}
                                  {field.required && <span className="text-red-500 mr-1">*</span>}
                                </label>
                                {field.type === 'select' ? (
                                  <select
                                    value={val}
                                    onChange={(e) => setEditingCustomer({ ...editingCustomer, [field.id]: e.target.value })}
                                    className="w-full px-3.5 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                                  >
                                    <option value="">-- בחר {field.label} --</option>
                                    {field.options?.map((opt: string, i: number) => (
                                      <option key={i} value={opt}>{opt}</option>
                                    ))}
                                  </select>
                                ) : field.type === 'date' ? (
                                  <input
                                    type="date"
                                    value={val}
                                    onChange={(e) => setEditingCustomer({ ...editingCustomer, [field.id]: e.target.value })}
                                    className="w-full px-3.5 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                                  />
                                ) : field.type === 'number' ? (
                                  <input
                                    type="number"
                                    placeholder={`הזן ${field.label}`}
                                    value={val}
                                    onChange={(e) => setEditingCustomer({ ...editingCustomer, [field.id]: e.target.value })}
                                    className="w-full px-3.5 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                                  />
                                ) : field.type === 'email' ? (
                                  <input
                                    type="email"
                                    dir="ltr"
                                    placeholder={`name@example.com`}
                                    value={val}
                                    onChange={(e) => setEditingCustomer({ ...editingCustomer, [field.id]: e.target.value })}
                                    className="w-full px-3.5 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none text-right"
                                  />
                                ) : (
                                  <input
                                    type="text"
                                    placeholder={`הזן ${field.label}`}
                                    value={val}
                                    onChange={(e) => setEditingCustomer({ ...editingCustomer, [field.id]: e.target.value })}
                                    className="w-full px-3.5 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                                  />
                                )}
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                          <div className="space-y-1">
                            <label className="block text-xs font-bold text-zinc-700">שם הלקוח</label>
                            <input
                              type="text"
                              value={editingCustomer.name || editingCustomer.fullName || ''}
                              onChange={(e) => setEditingCustomer({ ...editingCustomer, name: e.target.value })}
                              className="w-full px-3.5 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="block text-xs font-bold text-zinc-700">טלפון</label>
                            <input
                              type="tel"
                              value={editingCustomer.phone || ''}
                              onChange={(e) => setEditingCustomer({ ...editingCustomer, phone: e.target.value })}
                              className="w-full px-3.5 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="block text-xs font-bold text-zinc-700">אימייל</label>
                            <input
                              type="email"
                              dir="ltr"
                              value={editingCustomer.email || ''}
                              onChange={(e) => setEditingCustomer({ ...editingCustomer, email: e.target.value })}
                              className="w-full px-3.5 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none text-right"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="block text-xs font-bold text-zinc-700">כתובת / הערות</label>
                            <input
                              type="text"
                              value={editingCustomer.address || editingCustomer.notes || ''}
                              onChange={(e) => setEditingCustomer({ ...editingCustomer, address: e.target.value })}
                              className="w-full px-3.5 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                          </div>
                        </div>
                      )}

                      {/* Extra / Custom fields on this customer */}
                      {(() => {
                        const configFieldIds = new Set((config?.customerFormFields || []).map((f: any) => f.id));
                        const configFieldLabels = new Set((config?.customerFormFields || []).map((f: any) => f.label));
                        const extraEntries = Object.entries(editingCustomer).filter(([k]) => 
                          !['id', 'createdAt', 'lastPurchase', 'uid'].includes(k) &&
                          !configFieldIds.has(k) &&
                          !configFieldLabels.has(k)
                        );

                        if (extraEntries.length === 0) return null;

                        return (
                          <div className="pt-3 border-t border-zinc-100">
                            <p className="text-xs font-bold text-zinc-500 mb-2">שדות ופרטים נוספים שנשמרו בהזמנה זו:</p>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              {extraEntries.map(([key, val]) => (
                                <div key={key} className="p-2.5 bg-zinc-50 rounded-xl border border-zinc-200 space-y-1">
                                  <div className="flex justify-between items-center">
                                    <label className="text-xs font-bold text-zinc-700">{key}</label>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const copy = { ...editingCustomer };
                                        delete copy[key];
                                        setEditingCustomer(copy);
                                      }}
                                      className="text-zinc-400 hover:text-red-500 text-[11px] flex items-center gap-0.5"
                                      title="הסר שדה"
                                    >
                                      <Trash2 size={12} />
                                      <span>הסר</span>
                                    </button>
                                  </div>
                                  <input
                                    type="text"
                                    value={val ?? ''}
                                    onChange={(e) => setEditingCustomer({ ...editingCustomer, [key]: e.target.value })}
                                    className="w-full px-3 py-1.5 bg-white border border-zinc-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })()}

                      {/* Add new custom field */}
                      <div className="pt-2 border-t border-zinc-100">
                        {showAddCustomField ? (
                          <div className="p-3.5 bg-zinc-50 border border-zinc-200 rounded-2xl space-y-2.5">
                            <p className="text-xs font-bold text-zinc-800">הוספת שדה חדש להזמנה זו:</p>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              <input
                                type="text"
                                placeholder="שם השדה (למשל: תעודת זהות)"
                                value={newCustomKey}
                                onChange={(e) => setNewCustomKey(e.target.value)}
                                className="px-3 py-2 bg-white border border-zinc-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                              />
                              <input
                                type="text"
                                placeholder="ערך השדה"
                                value={newCustomVal}
                                onChange={(e) => setNewCustomVal(e.target.value)}
                                className="px-3 py-2 bg-white border border-zinc-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                              />
                            </div>
                            <div className="flex justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => { setShowAddCustomField(false); setNewCustomKey(''); setNewCustomVal(''); }}
                                className="px-3 py-1.5 text-xs text-zinc-500 font-medium hover:text-zinc-700"
                              >
                                ביטול
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  if (!newCustomKey.trim()) {
                                    toast.error('נא להזין שם שדה');
                                    return;
                                  }
                                  setEditingCustomer({ ...editingCustomer, [newCustomKey.trim()]: newCustomVal });
                                  setNewCustomKey('');
                                  setNewCustomVal('');
                                  setShowAddCustomField(false);
                                  toast.success('השדה נוסף');
                                }}
                                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow"
                              >
                                הוסף שדה
                              </button>
                            </div>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setShowAddCustomField(true)}
                            className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-700 px-3 py-1.5 rounded-xl hover:bg-indigo-50 transition-colors"
                          >
                            <Plus size={15} />
                            <span>הוסף שדה מותאם אישית לטופס</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex justify-between items-center pt-5 border-t border-zinc-100">
                  <div>
                    <p className="text-xs text-zinc-400">סה"כ הזמנה מעודכן:</p>
                    <p className="text-2xl font-bold text-indigo-600">₪{editingOrder.items.reduce((sum, i) => sum + (i.price * i.quantity), 0)}</p>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => { setEditingOrder(null); setProductSearchTerm(''); setSelectedProductForVariant(null); }}
                      className="px-5 py-2.5 text-zinc-500 font-bold hover:text-zinc-700 rounded-xl hover:bg-zinc-100 transition-colors text-sm"
                    >
                      ביטול
                    </button>
                    <button
                      disabled={isSaving}
                      onClick={() => handleUpdateOrder(editingOrder.items, editingOrder.status, editingCustomer)}
                      className="bg-indigo-600 text-white px-7 py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 flex items-center gap-2 disabled:opacity-50 text-sm"
                    >
                      {isSaving ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                      שמור שינויים
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Order Details Modal */}
      <AnimatePresence>
        {selectedOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedOrder(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-3xl shadow-2xl max-w-2xl w-full overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                <div className="flex items-center gap-4">
                  <h3 className="text-xl font-bold text-zinc-900">
                    פרטי הזמנה {selectedOrder.orderNumber ? `#${selectedOrder.orderNumber}` : `#${selectedOrder.id.slice(0, 8)}`}
                  </h3>
                  <button 
                    onClick={() => handlePrint(selectedOrder)}
                    className="p-2 bg-white border border-zinc-200 rounded-xl text-zinc-600 hover:text-indigo-600 hover:border-indigo-200 transition-all flex items-center gap-2 text-sm font-bold"
                  >
                    <Printer size={16} />
                    הדפס
                  </button>
                </div>
                <button onClick={() => setSelectedOrder(null)} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
              </div>
              <div className="p-8 space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-zinc-400 uppercase tracking-wider">פרטי לקוח</p>
                    <div className="text-sm text-zinc-900">
                      {(config?.customerFormFields || []).map((field: any) => {
                        const val = selectedOrder.customer?.[field.id] || selectedOrder.customer?.[field.label];
                        if (!val) return null;
                        return <div key={field.id}><span className="font-bold">{field.label}:</span> {val as string}</div>;
                      })}
                      {Object.entries(selectedOrder.customer || {}).map(([key, val]) => {
                        const label = getFieldLabel(key);
                        const alreadyShown = config?.customerFormFields?.some((f: any) => f.id === key || f.label === label);
                        if (alreadyShown) return null;
                        return <div key={key}><span className="font-bold">{label}:</span> {val as string}</div>;
                      })}
                    </div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-zinc-400 uppercase tracking-wider">בוצע על ידי</p>
                    <p className="text-sm font-bold text-zinc-900">{selectedOrder.createdBy?.name || 'אורח'}</p>
                    <p className="text-[10px] text-zinc-400">{selectedOrder.createdBy?.email}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-zinc-400 uppercase tracking-wider">תאריך</p>
                    <p className="text-sm font-bold text-zinc-900">{selectedOrder.createdAt?.toDate().toLocaleString('he-IL')}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <p className="text-xs font-bold text-zinc-400 uppercase tracking-wider">פריטים</p>
                  <div className="bg-zinc-50 rounded-2xl border border-zinc-100 overflow-hidden">
                    <table className="w-full text-right">
                      <thead className="bg-zinc-100/50">
                        <tr>
                          <th className="px-4 py-3 text-xs font-bold text-zinc-500">מוצר</th>
                          <th className="px-4 py-3 text-xs font-bold text-zinc-500">כמות</th>
                          <th className="px-4 py-3 text-xs font-bold text-zinc-500">מחיר יח'</th>
                          <th className="px-4 py-3 text-xs font-bold text-zinc-500">סה"כ</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-zinc-100">
                        {selectedOrder.items.map((item, idx) => (
                          <tr key={idx}>
                            <td className="px-4 py-3 text-sm font-medium text-zinc-900">
                              {item.name}
                              {item.variantName && <span className="text-zinc-500 font-normal mr-1">({item.variantName})</span>}
                            </td>
                            <td className="px-4 py-3 text-sm text-zinc-500">{item.quantity}</td>
                            <td className="px-4 py-3 text-sm text-zinc-500">₪{item.price}</td>
                            <td className="px-4 py-3 text-sm font-bold text-zinc-900">₪{item.price * item.quantity}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Email Confirmation Status & Send Action */}
                <div className={`p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  !selectedOrder.emailSent
                    ? selectedOrder.emailFailed
                      ? 'bg-red-50/60 border-red-200' 
                      : 'bg-zinc-50 border-zinc-200'
                    : isEmailOutdated(selectedOrder)
                      ? 'bg-orange-50/60 border-orange-200'
                      : 'bg-emerald-50/50 border-emerald-200' 
                }`}>
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-xl ${
                      !selectedOrder.emailSent 
                        ? selectedOrder.emailFailed 
                          ? 'bg-red-100 text-red-700' 
                          : 'bg-amber-100 text-amber-700'
                        : isEmailOutdated(selectedOrder)
                          ? 'bg-orange-100 text-orange-700'
                          : 'bg-emerald-100 text-emerald-700' 
                    } shrink-0`}>
                      {selectedOrder.emailFailed ? <AlertTriangle size={20} /> : <Mail size={20} />}
                    </div>
                    <div>
                      <p className="font-bold text-sm text-zinc-900 flex items-center gap-2">
                        <span>
                          {!selectedOrder.emailSent 
                            ? selectedOrder.emailFailed 
                              ? 'שליחת מייל להזמנה זו נכשלה!' 
                              : 'טרם נשלח מייל אישור להזמנה זו'
                            : isEmailOutdated(selectedOrder)
                              ? 'הזמנה זו עודכנה לאחר שנשלח המייל האחרון'
                              : 'מייל אישור הזמנה נשלח'}
                        </span>
                        {selectedOrder.emailSent && !isEmailOutdated(selectedOrder) && <Check size={14} className="text-emerald-600" />}
                        {selectedOrder.emailFailed && <span className="text-[11px] font-bold text-red-600 bg-red-100 px-2 py-0.5 rounded-md">שגיאה</span>}
                        {isEmailOutdated(selectedOrder) && <span className="text-[11px] font-bold text-orange-600 bg-orange-100 px-2 py-0.5 rounded-md">לא מעודכן</span>}
                      </p>
                      <p className="text-xs text-zinc-500 mt-0.5">
                        {!selectedOrder.emailSent
                          ? selectedOrder.emailFailed
                            ? `שגיאה: ${selectedOrder.emailError || 'שרת דואר לא הגיב'} (נמען: ${selectedOrder.emailSentTo || config?.emailSettings?.reportEmail || 'הדוא"ל המוגדר'})`
                            : `יישלח אל: ${config?.emailSettings?.reportEmail || 'כתובת הדוחות במערכת'}`
                          : `נשלח אל ${selectedOrder.emailSentTo || config?.emailSettings?.reportEmail || 'הדוא"ל המוגדר'} ${selectedOrder.emailSentAt ? `(${selectedOrder.emailSentAt?.toDate ? selectedOrder.emailSentAt.toDate().toLocaleString('he-IL') : new Date(selectedOrder.emailSentAt).toLocaleString('he-IL')})` : ''}`
                        }
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleSendOrderEmail(selectedOrder)}
                    disabled={sendingEmailId === selectedOrder.id}
                    className={`px-5 py-2.5 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 disabled:opacity-50 shrink-0 ${
                      selectedOrder.emailFailed 
                        ? 'bg-red-600 hover:bg-red-700 shadow-red-500/20' 
                        : isEmailOutdated(selectedOrder)
                          ? 'bg-orange-500 hover:bg-orange-600 shadow-orange-500/20'
                          : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/20'
                    }`}
                  >
                    {sendingEmailId === selectedOrder.id ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                    <span>{!selectedOrder.emailSent ? (selectedOrder.emailFailed ? 'נסה לשלוח שוב כעת' : 'שלח מייל אישור עכשיו') : (isEmailOutdated(selectedOrder) ? 'שלח עדכון כעת' : 'שלח שוב מייל אישור')}</span>
                  </button>
                </div>

                <div className="flex justify-between items-center pt-6 border-t border-zinc-100">
                  <span className="text-xl font-bold text-zinc-900">סה"כ לתשלום:</span>
                  <span className="text-3xl font-bold text-indigo-600">₪{selectedOrder.totalAmount}</span>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {orderToDelete && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !isDeleting && setOrderToDelete(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden p-8 text-center"
            >
              <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertTriangle size={32} />
              </div>
              <h3 className="text-xl font-bold text-zinc-900 mb-2">מחיקת הזמנה</h3>
              <p className="text-zinc-500 mb-8">האם אתה בטוח שברצונך למחוק את ההזמנה? פעולה זו אינה ניתנת לביטול.</p>
              
              <div className="space-y-3">
                <button
                  disabled={isDeleting}
                  onClick={() => handleDeleteOrder(true)}
                  className="w-full bg-red-600 text-white py-3 rounded-xl font-bold hover:bg-red-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  מחק והחזר מוצרים למלאי
                </button>
                <button
                  disabled={isDeleting}
                  onClick={() => handleDeleteOrder(false)}
                  className="w-full bg-zinc-100 text-zinc-600 py-3 rounded-xl font-bold hover:bg-zinc-200 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  מחק ללא החזרת מוצרים
                </button>
                <button
                  disabled={isDeleting}
                  onClick={() => setOrderToDelete(null)}
                  className="w-full text-zinc-400 py-2 text-sm font-medium hover:text-zinc-600 transition-all"
                >
                  ביטול
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      </div>

      {/* Printable Area */}
      {showPrintable && (
        <div className="print-container" dir="rtl">
          <div className="flex justify-between items-start mb-10 border-b-2 border-zinc-900 pb-6">
            <div className="flex items-center gap-4">
              {config?.logoUrl && (
                <img src={config.logoUrl} alt="Logo" className="h-16 w-auto object-contain" />
              )}
              <div>
                <p className="text-lg font-black text-zinc-900 mb-0.5">{config?.orgName || config?.siteName || 'מערכת רכש'}</p>
                <p className="text-xs text-zinc-500 font-bold">{config?.siteName}</p>
                <h1 className="text-2xl font-black text-indigo-600 mt-2">סיכום הזמנה</h1>
              </div>
            </div>
            <div className="text-left">
              <p className="text-sm font-bold">הזמנה {showPrintable.orderNumber ? `#${showPrintable.orderNumber}` : `#${showPrintable.id.slice(0, 8)}`}</p>
              <p className="text-xs text-zinc-400">תאריך: {showPrintable.createdAt?.toDate().toLocaleString('he-IL')}</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-8 mb-10">
            <div className="space-y-2">
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">פרטי לקוח</p>
              <div className="text-sm text-zinc-900">
                {(config?.customerFormFields || []).map((field: any) => {
                  const val = showPrintable.customer?.[field.id] || showPrintable.customer?.[field.label];
                  if (!val) return null;
                  return <div key={field.id}><span className="font-bold">{field.label}:</span> {val as string}</div>;
                })}
                {Object.entries(showPrintable.customer || {}).map(([key, val]) => {
                  const label = getFieldLabel(key);
                  const alreadyShown = config?.customerFormFields?.some((f: any) => f.id === key || f.label === label);
                  if (alreadyShown) return null;
                  return <div key={key}><span className="font-bold">{label}:</span> {val as string}</div>;
                })}
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">בוצע על ידי</p>
              <p className="text-sm font-bold text-zinc-900">{showPrintable.createdBy?.name || 'אורח'}</p>
              <p className="text-[10px] text-zinc-400">{showPrintable.createdBy?.email}</p>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">סטטוס</p>
              <p className="text-sm font-bold text-zinc-900">
                {showPrintable.status === 'pending' ? 'ממתין' : showPrintable.status === 'completed' ? 'הושלם' : 'בוטל'}
              </p>
            </div>
          </div>

          <table className="w-full text-right mb-10 border-collapse">
            <thead>
              <tr className="border-b-2 border-zinc-900">
                <th className="py-4 px-2 text-sm font-bold text-zinc-900">מוצר</th>
                <th className="py-4 px-2 text-sm font-bold text-zinc-900">מק"ט</th>
                <th className="py-4 px-2 text-sm font-bold text-zinc-900">כמות</th>
                <th className="py-4 px-2 text-sm font-bold text-zinc-900">מחיר יח'</th>
                <th className="py-4 px-2 text-sm font-bold text-zinc-900">סה"כ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200">
              {showPrintable.items.map((item, idx) => (
                <tr key={idx}>
                  <td className="py-4 px-2 text-sm font-bold text-zinc-900">{item.name}</td>
                  <td className="py-4 px-2 text-sm text-zinc-500 font-mono">{item.sku}</td>
                  <td className="py-4 px-2 text-sm text-zinc-900">{item.quantity}</td>
                  <td className="py-4 px-2 text-sm text-zinc-900">₪{item.price.toLocaleString()}</td>
                  <td className="py-4 px-2 text-sm font-bold text-zinc-900">₪{(item.price * item.quantity).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={4} className="py-8 font-bold text-left pl-4 text-xl">סה"כ לתשלום:</td>
                <td className="py-8 font-black text-3xl text-indigo-600">₪{showPrintable.totalAmount.toLocaleString()}</td>
              </tr>
            </tfoot>
          </table>

          <div className="mt-20 pt-10 border-t border-zinc-100 text-center">
            <p className="text-sm font-bold text-zinc-900 mb-1">תודה רבה על רכישתך!</p>
            <p className="text-[10px] text-zinc-400">הופק במערכת {config?.siteName || 'ניהול הזמנות'} בתאריך {new Date().toLocaleString('he-IL')}</p>
          </div>
        </div>
      )}
    </>
  );
}
