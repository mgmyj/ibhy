import React, { useState, useEffect } from 'react';
import { db, collection, getDocs, addDoc, updateDoc, doc, deleteDoc, handleFirestoreError, OperationType, query, orderBy, limit, getDoc } from '../firebase';
import { Users, UserPlus, Search, FileDown, FileUp, Trash2, Edit2, X, Save, Download, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';
import * as XLSX from 'xlsx';
import { sendEmail } from '../lib/email';

interface Customer {
  id: string;
  name: string;
  associationName?: string;
  contactPerson?: string;
  email?: string;
  phone?: string;
  address?: string;
  notes?: string;
  createdAt?: any;
}

export function Customers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [form, setForm] = useState({ 
    name: '', 
    associationName: '', 
    contactPerson: '', 
    email: '', 
    phone: '', 
    address: '', 
    notes: '' 
  });

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const q = query(collection(db, 'customers'), orderBy('name', 'asc'), limit(100));
        const snapshot = await getDocs(q);
        setCustomers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Customer)));
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, 'customers');
      }
    };
    fetchCustomers();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving) return;
    setIsSaving(true);
    try {
      if (editingCustomer) {
        await updateDoc(doc(db, 'customers', editingCustomer.id), form);
        toast.success('הלקוח עודכן בהצלחה');
      } else {
        await addDoc(collection(db, 'customers'), { ...form, createdAt: new Date() });
        toast.success('הלקוח נוסף בהצלחה');
      }
      setIsAdding(false);
      setEditingCustomer(null);
      setForm({ name: '', associationName: '', contactPerson: '', email: '', phone: '', address: '', notes: '' });
    } catch (err) {
      handleFirestoreError(err, editingCustomer ? OperationType.UPDATE : OperationType.CREATE, 'customers');
    } finally {
      setIsSaving(false);
    }
  };

  const handleExport = async () => {
    const dataToExport = customers.map(c => ({
      'שם מלא': c.name,
      'שם האיגוד': c.associationName || '',
      'איש קשר': c.contactPerson || '',
      'טלפון': c.phone || '',
      'אימייל': c.email || '',
      'כתובת': c.address || '',
      'הערות': c.notes || '',
      'תאריך הצטרפות': c.createdAt?.toDate ? c.createdAt.toDate().toLocaleDateString('he-IL') : ''
    }));

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Customers');
    XLSX.writeFile(wb, 'customers_database.xlsx');
    toast.success('מאגר הלקוחות יוצא בהצלחה');

    // Send copy by email if configured
    try {
      const configDoc = await getDoc(doc(db, 'config', 'system'));
      const config = configDoc.data();
      if (!config?.emailSettings?.disableAllEmails && config?.emailReports?.copyOnExport && config?.emailReports?.recipientEmail) {
        const base64 = XLSX.write(wb, { bookType: 'xlsx', type: 'base64' });
        await sendEmail({
          to: config.emailReports.recipientEmail,
          subject: `מאגר לקוחות - ${config.siteName || 'מערכת רכש'}`,
          html: `
            <div dir="rtl" style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
              <h2 style="color: #2563eb;">מאגר לקוחות</h2>
              <p>שלום רב,</p>
              <p>מצורף בזאת דוח מאגר לקוחות עדכני שהופק ממערכת <strong>${config.siteName || 'מערכת רכש'}</strong>.</p>
              <p><strong>תאריך הפקה:</strong> ${new Date().toLocaleDateString('he-IL')} בשעה ${new Date().toLocaleTimeString('he-IL')}</p>
              <p>הדוח מצורף כקובץ אקסל (Excel) וכולל את כל פרטי הלקוחות הרשומים במערכת.</p>
              <br/>
              <p>בברכה,<br/>צוות המערכת</p>
            </div>
          `,
          attachments: [{
            filename: 'customers_database.xlsx',
            content: base64,
            contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
          }]
        });
        toast.success('עותק מהמאגר נשלח לאימייל');
      }
    } catch (err) {
      console.error('Failed to send customer database email:', err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('האם אתה בטוח שברצונך למחוק לקוח זה?')) return;
    try {
      await deleteDoc(doc(db, 'customers', id));
      toast.success('הלקוח נמחק');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'customers');
    }
  };

  const downloadTemplate = () => {
    const template = [
      { 'שם מלא': 'ישראל ישראלי', 'אימייל': 'israel@example.com', 'טלפון': '0501234567', 'כתובת': 'הרצל 1, תל אביב', 'הערות': 'לקוח VIP' }
    ];
    const ws = XLSX.utils.json_to_sheet(template);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Customers Template');
    XLSX.writeFile(wb, 'customer_import_template.xlsx');
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws) as any[];

        let importedCount = 0;
        for (const row of data) {
          const customerData = {
            name: row['שם מלא'] || row['Name'] || '',
            email: row['אימייל'] || row['Email'] || '',
            phone: row['טלפון'] || row['Phone'] || '',
            address: row['כתובת'] || row['Address'] || '',
            notes: row['הערות'] || row['Notes'] || '',
            createdAt: new Date()
          };

          if (customerData.name) {
            await addDoc(collection(db, 'customers'), customerData);
            importedCount++;
          }
        }
        toast.success(`יובאו ${importedCount} לקוחות בהצלחה`);
      } catch (err) {
        console.error('Import error:', err);
        toast.error('שגיאה בייבוא הקובץ. וודא שהפורמט תקין.');
      }
    };
    reader.readAsBinaryString(file);
  };

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.phone?.includes(searchTerm) ||
    c.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 max-w-7xl mx-auto font-sans text-right" dir="rtl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-bold text-zinc-900 tracking-tight">ספר לקוחות</h2>
          <p className="text-zinc-500 mt-1">נהל את רשימת הלקוחות שלך, הוסף לקוחות חדשים או ייבא מאקסל</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={handleExport}
            className="bg-zinc-100 text-zinc-600 px-4 py-2.5 rounded-xl font-medium hover:bg-zinc-200 transition-all flex items-center gap-2"
          >
            <FileDown size={18} />
            ייצוא לאקסל
          </button>
          <button
            onClick={downloadTemplate}
            className="bg-zinc-100 text-zinc-600 px-4 py-2.5 rounded-xl font-medium hover:bg-zinc-200 transition-all flex items-center gap-2"
          >
            <Download size={18} />
            תבנית ייבוא
          </button>
          <label className="bg-emerald-600 text-white px-4 py-2.5 rounded-xl font-medium hover:bg-emerald-700 transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/20">
            <FileUp size={18} />
            ייבוא מאקסל
            <input type="file" accept=".xlsx, .xls" className="hidden" onChange={handleImport} />
          </label>
          <button
            onClick={() => { setIsAdding(true); setEditingCustomer(null); setForm({ name: '', associationName: '', contactPerson: '', email: '', phone: '', address: '', notes: '' }); }}
            className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-indigo-700 transition-all flex items-center gap-2 shadow-lg shadow-indigo-500/20"
          >
            <UserPlus size={18} />
            הוסף לקוח
          </button>
        </div>
      </div>

      <div className="mb-6 relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
        <input
          type="text"
          placeholder="חיפוש לפי שם, טלפון או אימייל..."
          className="w-full pr-10 pl-4 py-3 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="bg-white rounded-3xl border border-zinc-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead className="bg-zinc-50 border-b border-zinc-100">
              <tr>
                <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase tracking-wider">שם לקוח</th>
                <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase tracking-wider">שם האיגוד</th>
                <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase tracking-wider">איש קשר</th>
                <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase tracking-wider">טלפון</th>
                <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase tracking-wider">פעולות</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {filteredCustomers.map(customer => (
                <tr key={customer.id} className="hover:bg-zinc-50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-bold">
                        {customer.name[0]}
                      </div>
                      <span className="font-bold text-zinc-900">{customer.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-zinc-600">{customer.associationName || '-'}</td>
                  <td className="px-6 py-4 text-zinc-600">{customer.contactPerson || '-'}</td>
                  <td className="px-6 py-4 text-zinc-600">{customer.phone || '-'}</td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button
                        onClick={() => { 
                          setEditingCustomer(customer); 
                          setForm({ 
                            name: customer.name,
                            associationName: customer.associationName || '',
                            contactPerson: customer.contactPerson || '',
                            email: customer.email || '',
                            phone: customer.phone || '',
                            address: customer.address || '',
                            notes: customer.notes || ''
                          }); 
                          setIsAdding(true); 
                        }}
                        className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors rounded-lg"
                      >
                        <Edit2 size={18} />
                      </button>
                      <button
                        onClick={() => handleDelete(customer.id)}
                        className="p-2 text-zinc-400 hover:text-red-600 hover:bg-red-50 transition-colors rounded-lg"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredCustomers.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-zinc-400">
                    <Users size={48} className="mx-auto mb-4 opacity-20" />
                    <p>לא נמצאו לקוחות</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAdding(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                <h3 className="text-xl font-bold text-zinc-900">{editingCustomer ? 'עריכת לקוח' : 'הוספת לקוח חדש'}</h3>
                <button onClick={() => setIsAdding(false)} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
              </div>
              <form onSubmit={handleSave} className="p-8 space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 mb-1">שם מלא</label>
                  <input required type="text" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={form.name || ''} onChange={e => setForm({...form, name: e.target.value})} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">שם האיגוד</label>
                    <input type="text" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={form.associationName || ''} onChange={e => setForm({...form, associationName: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">איש קשר</label>
                    <input type="text" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={form.contactPerson || ''} onChange={e => setForm({...form, contactPerson: e.target.value})} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">טלפון</label>
                    <input type="tel" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={form.phone || ''} onChange={e => setForm({...form, phone: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">אימייל</label>
                    <input type="email" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={form.email || ''} onChange={e => setForm({...form, email: e.target.value})} />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 mb-1">כתובת</label>
                  <input type="text" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={form.address || ''} onChange={e => setForm({...form, address: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 mb-1">הערות</label>
                  <textarea rows={3} className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={form.notes || ''} onChange={e => setForm({...form, notes: e.target.value})} />
                </div>
                <button type="submit" disabled={isSaving} className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 disabled:opacity-50">
                  {isSaving ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
                  {editingCustomer ? 'עדכן לקוח' : 'שמור לקוח'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
