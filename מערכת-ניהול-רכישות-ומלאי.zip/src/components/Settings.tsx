import React, { useState, useEffect } from 'react';
import { db, collection, onSnapshot, query, addDoc, updateDoc, deleteDoc, doc, handleFirestoreError, OperationType, setDoc, getDoc, storage, ref, uploadBytes, getDownloadURL, getDocs, auth, firebaseConfig, writeBatch, orderBy, serverTimestamp, increment } from '../firebase';
import { Users, Settings as SettingsIcon, Shield, UserPlus, Trash2, Edit2, Save, X, CheckCircle2, AlertCircle, AlertTriangle, FormInput, Plus, Layout, Type, List, Calendar, Hash, Image as ImageIcon, Upload, Loader2, Eraser, ChevronUp, ChevronDown, RefreshCw, Package, ShoppingCart, Check, Mail, Bell, BellRing, Send, FileText, FileDown, Archive as ArchiveIcon, ShieldCheck, Eye, EyeOff, HelpCircle, Info, Lock, Clock } from 'lucide-react';
import toast from 'react-hot-toast';
import { motion, AnimatePresence } from 'motion/react';
import { sendEmail, formatReservationEmail, testEmailSettings, getEmailStatus, checkEmailHealth, retryFailedEmails, clearPendingEmails, EmailHealthStatus } from '../services/emailService';
import { notifyAdminEmailFailure } from '../services/adminAlertService';
import { dataCache } from '../lib/cache';

interface UserProfile { id: string; uid: string; name: string; email: string; role: 'admin' | 'user'; }

interface FormField {
  id: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'select' | 'email';
  options?: string[];
  required?: boolean;
  hideInReports?: boolean;
}

interface EmailSettings {
  mainEmail: string;
  reportEmail: string;
  replyToType: 'sender' | 'fixed';
  fixedReplyToEmail?: string;
  senderChoice: 'user' | 'system';
  notifyNewOrder: boolean;
  notifyEditOrder: boolean;
  notifyDeleteOrder: boolean;
  notifyReservation: boolean;
  notifyReservationDelete: boolean;
  notifyReservationToOrder: boolean;
  notifyLowStock: boolean;
  autoDailyReport: boolean;
  autoWeeklyReport: boolean;
  autoMonthlyReport: boolean;
  disableAllEmails: boolean;
}

interface SystemConfig {
  customerFormTitle: string;
  customerFormFields: FormField[];
  siteName: string;
  orgName: string;
  logoUrl: string;
  faviconUrl: string;
  emailSettings?: EmailSettings;
  enableSalesArchive?: boolean;
}

interface SecretsConfig {
  emailUser: string;
  emailPass: string;
  emailFromName: string;
}

interface Reservation {
  id: string;
  productId: string;
  productName: string;
  productSku?: string;
  productCategory?: string;
  variantId?: string;
  variantName?: string;
  quantity: number;
  note?: string;
  createdAt: any;
}

interface Category {
  id: string;
  name: string;
}

interface ProductVariant {
  id: string;
  name: string;
  price?: number;
  stockQuantity: number;
}

interface Product {
  id: string;
  name: string;
  sku: string;
  description?: string;
  stockQuantity: number;
  totalStock: number;
  reservedQuantity?: number;
  price: number;
  categoryId?: string;
  variants?: ProductVariant[];
}

export function Settings({ isAdmin, userRole }: { isAdmin: boolean; userRole?: string }) {
  // System Config
  const [config, setConfig] = useState<SystemConfig>({ 
    customerFormTitle: 'פרטי לקוח וסיום רכישה',
    customerFormFields: [
      { id: 'name', label: 'שם מלא', type: 'text', required: true },
      { id: 'associationName', label: 'שם האיגוד', type: 'text', required: false },
      { id: 'contactPerson', label: 'איש קשר', type: 'text', required: false },
      { id: 'phone', label: 'טלפון', type: 'number', required: true },
      { id: 'email', label: 'דואר אלקטרוני', type: 'email', required: true },
      { id: 'address', label: 'כתובת למשלוח', type: 'text', required: false }
    ],
    siteName: 'מערכת רכש',
    orgName: 'שם הארגון',
    logoUrl: '',
    faviconUrl: '',
    emailSettings: {
      mainEmail: '',
      reportEmail: '',
      replyToType: 'sender',
      fixedReplyToEmail: '',
      senderChoice: 'system',
      notifyNewOrder: true,
      notifyEditOrder: true,
      notifyDeleteOrder: true,
      notifyReservation: true,
      notifyReservationDelete: true,
      notifyReservationToOrder: true,
      notifyLowStock: true,
      autoDailyReport: false,
      autoWeeklyReport: false,
      autoMonthlyReport: false,
      disableAllEmails: false
    }
  });
  
  const [secrets, setSecrets] = useState<SecretsConfig>({
    emailUser: '',
    emailPass: '',
    emailFromName: ''
  });

  const [testingEmail, setTestingEmail] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [showEmailPass, setShowEmailPass] = useState(false);
  const [emailHealthStatus, setEmailHealthStatus] = useState<EmailHealthStatus | null>(null);
  const [checkingHealth, setCheckingHealth] = useState(false);
  const [flushingQueue, setFlushingQueue] = useState(false);
  const [savingEmailSecrets, setSavingEmailSecrets] = useState(false);

  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingFavicon, setUploadingFavicon] = useState(false);
  const [saving, setSaving] = useState(false);
  const [clearingCarts, setClearingCarts] = useState(false);
  const [showConfirmClear, setShowConfirmClear] = useState(false);
  const [sendingReport, setSendingReport] = useState(false);
  const [showConfirmReconcile, setShowConfirmReconcile] = useState(false);
  const [reconciling, setReconciling] = useState(false);
  const [discrepancies, setDiscrepancies] = useState<any[]>([]);
  const [showDiscrepanciesModal, setShowDiscrepanciesModal] = useState(false);
  const [fixingDiscrepancy, setFixingDiscrepancy] = useState<string | null>(null);
  const [generatingReport, setGeneratingReport] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportType, setReportType] = useState<'daily' | 'monthly' | 'range' | 'buyers' | 'bulk'>('daily');
  const [reportDateRange, setReportDateRange] = useState({ start: '', end: '' });
  const [selectedProductId, setSelectedProductId] = useState('all');
  
  // Reservations
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isAddingReservation, setIsAddingReservation] = useState(false);
  const [reservationForm, setReservationForm] = useState({ 
    productId: '', 
    productName: '',
    productSku: '',
    productCategory: '',
    variantId: '',
    variantName: '',
    quantity: 1, 
    note: '' 
  });
  const [isReserving, setIsReserving] = useState(false);

  const [editingField, setEditingField] = useState<FormField | null>(null);
  const [fieldForm, setFieldForm] = useState<FormField>({ id: '', label: '', type: 'text', options: [], required: false });
  const [newOption, setNewOption] = useState('');

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const snapshot = await getDoc(doc(db, 'config', 'system'));
        if (snapshot.exists()) {
          const data = snapshot.data() as any;
          // Migration for old config format if needed
          if (Array.isArray(data.customerFormFields) && typeof data.customerFormFields[0] === 'string') {
            const migratedFields = data.customerFormFields.map((f: string) => ({
              id: f,
              label: f === 'name' ? 'שם מלא' : f === 'phone' ? 'טלפון' : f === 'address' ? 'כתובת' : f,
              type: f === 'phone' ? 'number' : 'text'
            }));
            setConfig({
              customerFormTitle: data.customerFormTitle || 'פרטי לקוח וסיום רכישה',
              customerFormFields: migratedFields,
              siteName: data.siteName || 'מערכת רכש',
              orgName: data.orgName || 'שם הארגון',
              logoUrl: data.logoUrl || '',
              faviconUrl: data.faviconUrl || ''
            });
          } else {
            setConfig({
              ...data,
              faviconUrl: data.faviconUrl || ''
            } as SystemConfig);
          }
        }
        
        if (isAdmin) {
          try {
            const res = await fetch('/api/get-secrets');
            let loaded = false;
            if (res.ok) {
              const contentType = res.headers.get("content-type");
              if (contentType && contentType.includes("application/json")) {
                const data = await res.json();
                if (data && (data.emailUser || data.emailPass)) {
                  if (data.emailPass === 'vooksursntyroudf') data.emailPass = '';
                  setSecrets(data as SecretsConfig);
                  loaded = true;
                }
              } else {
                console.warn("Expected JSON but got:", contentType);
              }
            }
            // If server returned empty, check localStorage backup
            if (!loaded) {
              try {
                const backup = localStorage.getItem('email_secrets_backup');
                if (backup) {
                  const parsed = JSON.parse(backup);
                  if (parsed.emailPass === 'vooksursntyroudf') {
                    localStorage.removeItem('email_secrets_backup');
                  } else if (parsed.emailUser && parsed.emailPass) {
                    setSecrets(parsed);
                    // Resync to server
                    await fetch('/api/save-secrets', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(parsed)
                    });
                  }
                }
              } catch (e) {}
            }
          } catch(e) {
            console.error("Could not fetch secrets config (might not exist yet)", e);
          }

          // Fetch live email health status
          try {
            const health = await getEmailStatus();
            setEmailHealthStatus(health);
          } catch (e) {}
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, 'config/system');
      }
    };
    fetchConfig();
  }, []);

  useEffect(() => {
    if (!isAdmin) return;
    
    const unsubReservations = onSnapshot(query(collection(db, 'reservations'), orderBy('createdAt', 'desc')), (snapshot) => {
      setReservations(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reservation)));
    });

    const unsubProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product)));
    });

    const unsubCategories = onSnapshot(collection(db, 'categories'), (snapshot) => {
      setCategories(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Category)));
    });

    return () => {
      unsubReservations();
      unsubProducts();
      unsubCategories();
    };
  }, [isAdmin]);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('אנא בחר קובץ תמונה תקין');
      return;
    }

    if (file.size > 1024 * 1024) {
      toast.error('הקובץ גדול מדי. אנא העלה לוגו קטן מ-1MB');
      return;
    }

    setUploadingLogo(true);
    try {
      let url = '';
      try {
        const storageRef = ref(storage, `branding/logo_${Date.now()}`);
        console.log('Attempting to upload logo to:', storageRef.fullPath);
        
        const snapshot = await uploadBytes(storageRef, file);
        url = await getDownloadURL(snapshot.ref);
        console.log('Logo uploaded successfully to Storage, URL:', url);
      } catch (storageErr: any) {
        console.warn('Storage upload failed, falling back to Base64:', storageErr);
        if (storageErr.code === 'storage/unauthorized') {
          console.error('Storage permission denied. Check storage.rules');
        }
        const base64 = await fileToBase64(file);
        if (base64.length > 800 * 1024) {
          throw new Error('הלוגו גדול מדי לשמירה כטקסט. אנא הקטן את התמונה.');
        }
        url = base64;
      }

      const configToSave = { ...config, logoUrl: url };
      // Remove id if it exists to avoid saving it as a field
      if ('id' in configToSave) delete (configToSave as any).id;
      
      await setDoc(doc(db, 'config', 'system'), configToSave);
      setConfig(configToSave as SystemConfig);
      toast.success('הלוגו הועלה ונשמר בהצלחה');
    } catch (err: any) {
      console.error('Logo upload/save error:', err);
      if (err.message?.includes('permission-denied') || err.code === 'permission-denied') {
        toast.error('שגיאת הרשאה: אין לך הרשאות לעדכן את הגדרות המערכת. וודא שאתה מחובר כמנהל.');
      } else {
        toast.error(`שגיאה בהעלאת הלוגו: ${err.message || 'שגיאה לא ידועה'}`);
      }
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleFaviconUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('אנא בחר קובץ תמונה תקין');
      return;
    }

    if (file.size > 512 * 1024) {
      toast.error('הקובץ גדול מדי. אנא העלה פאביקון קטן מ-512KB');
      return;
    }

    setUploadingFavicon(true);
    try {
      let url = '';
      try {
        const storageRef = ref(storage, `branding/favicon_${Date.now()}`);
        console.log('Attempting to upload favicon to:', storageRef.fullPath);
        
        const snapshot = await uploadBytes(storageRef, file);
        url = await getDownloadURL(snapshot.ref);
        console.log('Favicon uploaded successfully to Storage, URL:', url);
      } catch (storageErr: any) {
        console.warn('Storage upload failed, falling back to Base64:', storageErr);
        if (storageErr.code === 'storage/unauthorized') {
          console.error('Storage permission denied. Check storage.rules');
        }
        const base64 = await fileToBase64(file);
        if (base64.length > 512 * 1024) {
          throw new Error('הפאביקון גדול מדי לשמירה כטקסט. אנא הקטן את התמונה.');
        }
        url = base64;
      }

      const configToSave = { ...config, faviconUrl: url };
      // Remove id if it exists
      if ('id' in configToSave) delete (configToSave as any).id;

      await setDoc(doc(db, 'config', 'system'), configToSave);
      setConfig(configToSave as SystemConfig);
      toast.success('הפאביקון הועלה ונשמר בהצלחה');
    } catch (err: any) {
      console.error('Favicon upload/save error:', err);
      if (err.message?.includes('permission-denied') || err.code === 'permission-denied') {
        toast.error('שגיאת הרשאה: אין לך הרשאות לעדכן את הגדרות המערכת. וודא שאתה מחובר כמנהל.');
      } else {
        toast.error(`שגיאה בהעלאת הפאביקון: ${err.message || 'שגיאה לא ידועה'}`);
      }
    } finally {
      setUploadingFavicon(false);
    }
  };

  const handleTestEmail = async () => {
    const emailUser = (secrets.emailUser || '').trim().toLowerCase();
    const emailPass = (secrets.emailPass || '').replace(/\s+/g, '').trim();

    if (!emailUser || !emailPass) {
      toast.error('נא להזין כתובת Gmail וסיסמת אפליקציה בת 16 תווים.');
      return;
    }

    setTestingEmail(true);
    setTestResult(null);
    const loadingToast = toast.loading('בודק חיבור לשרת Gmail SMTP...');

    try {
      const data = await testEmailSettings({
        emailUser,
        emailPass
      });

      if (data.success) {
        setTestResult({
          success: true,
          message: data.message || 'החיבור לשרת הדואר של Google (Gmail SMTP) אומת בהצלחה!'
        });
        toast.success('חיבור ה-Gmail אומת בהצלחה!', { id: loadingToast });
      } else {
        setTestResult({
          success: false,
          message: data.error || 'האימות מול שרת הדואר של Google נכשל'
        });
        toast.error('האימות מול Google נכשל', { id: loadingToast });
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: 'שגיאה בתקשורת מול השרת בעת בדיקת החיבור'
      });
      toast.error('שגיאה בבדיקת החיבור', { id: loadingToast });
    } finally {
      setTestingEmail(false);
    }
  };

  const handleRefreshEmailHealth = async () => {
    setCheckingHealth(true);
    const toastId = toast.loading('מאמת חיבור מול שרתי Google...');
    try {
      const res = await checkEmailHealth();
      setEmailHealthStatus(res);
      if (res.healthy) {
        toast.success('חיבור ה-Gmail אומת בהצלחה!', { id: toastId });
      } else {
        toast.error('האימות נכשל: ' + (res.error || 'בדוק סיסמת אפליקציה'), { id: toastId });
      }
      window.dispatchEvent(new CustomEvent('email-status-updated'));
    } catch (err) {
      toast.error('שגיאה בבדיקת החיבור', { id: toastId });
    } finally {
      setCheckingHealth(false);
    }
  };

  const handleFlushEmailQueue = async () => {
    setFlushingQueue(true);
    const toastId = toast.loading('שולח מחדש מיילים שנשמרו בתור...');
    try {
      const res = await retryFailedEmails();
      if (res.success) {
        toast.success(`נשלחו בהצלחה ${res.sent} מתוך ${res.total} מיילים!`, { id: toastId });
        const updatedHealth = await getEmailStatus();
        setEmailHealthStatus(updatedHealth);
        window.dispatchEvent(new CustomEvent('email-status-updated'));
      } else {
        toast.error(`שליחה נכשלה: ${res.error || 'בדקו שהסיסמה תקפה'}`, { id: toastId });
      }
    } catch (err) {
      toast.error('שגיאה בשליחת המיילים הממתינים', { id: toastId });
    } finally {
      setFlushingQueue(false);
    }
  };

  const handleClearEmailQueue = async () => {
    if (!window.confirm('האם אתה בטוח שברצונך למחוק את כל המיילים הממתינים בתור? פעולה זו אינה ניתנת לביטול.')) {
      return;
    }
    try {
      await clearPendingEmails('all');
      toast.success('תור המיילים נוקה בהצלחה');
      const updatedHealth = await getEmailStatus();
      setEmailHealthStatus(updatedHealth);
      window.dispatchEvent(new CustomEvent('email-status-updated'));
    } catch (err) {
      toast.error('שגיאה בניקוי התור');
    }
  };

  const handleSaveOnlyEmailSecrets = async () => {
    setSavingEmailSecrets(true);
    const toastId = toast.loading('שומר פרטי התחברות ל-Gmail...');
    try {
      const cleanedSecrets = {
        emailUser: (secrets.emailUser || '').trim().toLowerCase(),
        emailPass: (secrets.emailPass || '').replace(/\s+/g, '').trim(),
        emailFromName: (secrets.emailFromName || '').trim()
      };
      setSecrets(cleanedSecrets);

      try {
        localStorage.setItem('email_secrets_backup', JSON.stringify(cleanedSecrets));
      } catch (e) {}

      const res = await fetch('/api/save-secrets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cleanedSecrets)
      });
      if (!res.ok) throw new Error('Failed to save email secrets');
      
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        const data = await res.json();
        if (data.health) {
          setEmailHealthStatus(data.health);
        } else {
          const h = await getEmailStatus();
          setEmailHealthStatus(h);
        }
      } else {
        const h = await getEmailStatus();
        setEmailHealthStatus(h);
      }

      window.dispatchEvent(new CustomEvent('email-status-updated'));
      toast.success('פרטי Gmail נשמרו ונבדקו בהצלחה!', { id: toastId });
    } catch (err) {
      toast.error('שגיאה בשמירת פרטי החיבור', { id: toastId });
    } finally {
      setSavingEmailSecrets(false);
    }
  };

  const handleSaveConfig = async () => {
    setSaving(true);
    try {
      const configToSave = { ...config };
      // Remove id if it somehow got in there
      if ('id' in configToSave) delete (configToSave as any).id;
      
      await setDoc(doc(db, 'config', 'system'), configToSave);
      
      const cleanedSecrets = {
        emailUser: (secrets.emailUser || '').trim().toLowerCase(),
        emailPass: (secrets.emailPass || '').replace(/\s+/g, '').trim(),
        emailFromName: (secrets.emailFromName || '').trim()
      };
      setSecrets(cleanedSecrets);

      if (cleanedSecrets.emailUser && cleanedSecrets.emailPass && cleanedSecrets.emailPass !== 'vooksursntyroudf') {
        try {
          localStorage.setItem('email_secrets_backup', JSON.stringify(cleanedSecrets));
        } catch (e) {}

        const secretsRes = await fetch('/api/save-secrets', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(cleanedSecrets)
        });
        if (secretsRes.ok) {
          window.dispatchEvent(new CustomEvent('email-status-updated'));
          const h = await getEmailStatus();
          setEmailHealthStatus(h);
        }
      }

      toast.success('הגדרות נשמרו בהצלחה');
    } catch (err: any) {
      console.error('Error saving config:', err);
      if (err.message?.includes('permission-denied') || err.code === 'permission-denied') {
        toast.error('שגיאת הרשאה: אין לך הרשאות לעדכן את הגדרות המערכת. וודא שאתה מחובר כמנהל.');
      } else {
        toast.error(`שגיאה בשמירת ההגדרות: ${err.message || 'שגיאה לא ידועה'}`);
      }
    } finally {
      setSaving(false);
    }
  };

  const handleSendInventoryReport = async () => {
    if (config.emailSettings?.disableAllEmails) {
      toast.error('מערכת המיילים מושהית. לא ניתן לשלוח דוח מלאי.');
      return;
    }

    if (!config.emailSettings?.reportEmail) {
      toast.error('נא להגדיר אימייל לדיווחים בהגדרות');
      return;
    }

    setSendingReport(true);
    const toastId = toast.loading('מפיק דוח מלאי ושולח למייל...', { id: 'inventory-report' });
    
    try {
      // Fetch current inventory
      const productsSnap = await getDocs(collection(db, 'products'));
      const productsList = productsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));

      // Format report content
      const date = new Date().toLocaleString('he-IL');
      const html = `
        <div dir="rtl" style="font-family: Arial, sans-serif; color: #333; text-align: right;">
          <h2 style="color: #4f46e5;">דוח מלאי מפורט - ${config.orgName || config.siteName}</h2>
          <p>תאריך הפקה: ${date}</p>
          <hr />
          <table style="width: 100%; border-collapse: collapse; margin-top: 20px; direction: rtl;">
            <thead>
              <tr style="background-color: #f3f4f6;">
                <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">שם מוצר</th>
                <th style="border: 1px solid #ddd; padding: 12px; text-align: center;">מק"ט</th>
                <th style="border: 1px solid #ddd; padding: 12px; text-align: center;">מלאי נוכחי</th>
                <th style="border: 1px solid #ddd; padding: 12px; text-align: center;">מחיר</th>
              </tr>
            </thead>
            <tbody>
              ${productsList.map(p => `
                <tr>
                  <td style="border: 1px solid #ddd; padding: 10px;">${p.name}</td>
                  <td style="border: 1px solid #ddd; padding: 10px; text-align: center;">${p.sku || '-'}</td>
                  <td style="border: 1px solid #ddd; padding: 10px; text-align: center; font-weight: bold; color: ${p.stockQuantity <= 5 ? '#ef4444' : '#10b981'};">
                    ${p.stockQuantity}
                  </td>
                  <td style="border: 1px solid #ddd; padding: 10px; text-align: center;">₪${p.price.toLocaleString()}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <p style="margin-top: 30px; font-size: 12px; color: #666;">הופק על ידי מערכת ניהול רכש</p>
        </div>
      `;

      // Determine reply-to
      let replyTo: string | undefined;
      if (config.emailSettings?.replyToType === 'fixed') {
        replyTo = config.emailSettings.fixedReplyToEmail;
      }

      // Determine sender info for reply-to if not fixed
      const userEmail = config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.email : config.emailSettings?.mainEmail;
      const userName = config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.displayName : config.siteName;

      await sendEmail({
        to: config.emailSettings.reportEmail,
        subject: `דוח מלאי מפורט - ${config.orgName || config.siteName} - ${date}`,
        html,
        userEmail: userEmail || undefined,
        userName: userName || undefined,
        replyTo: replyTo || undefined
      });

      toast.success('דוח המלאי נשלח בהצלחה למייל הדיווחים', { id: toastId });
    } catch (error) {
      console.error('Error sending inventory report:', error);
      toast.error('שגיאה בשליחת דוח המלאי', { id: toastId });
    } finally {
      setSendingReport(false);
    }
  };

  const handleGenerateReport = async () => {
    if (config.emailSettings?.disableAllEmails) {
      toast.error('מערכת המיילים מושהית. לא ניתן להפיק דוח למייל.');
      return;
    }

    if (!config.emailSettings?.reportEmail) {
      toast.error('נא להגדיר אימייל לדיווחים בהגדרות');
      return;
    }

    setGeneratingReport(true);
    const toastId = toast.loading('מפיק דוח ושולח למייל...', { id: 'report-gen' });

    try {
      let subject = '';
      if (reportType === 'daily') {
        subject = `דוח יומי - ${new Date().toLocaleDateString('he-IL')}`;
      } else if (reportType === 'monthly') {
        subject = `דוח חודשי - ${new Date().toLocaleString('he-IL', { month: 'long', year: 'numeric' })}`;
      } else if (reportType === 'range' || reportType === 'buyers') {
        subject = `דוח לתקופה: ${reportDateRange.start} עד ${reportDateRange.end}`;
      }

      const ordersSnap = await getDocs(query(collection(db, 'orders'), orderBy('createdAt', 'desc')));
      let orders = ordersSnap.docs.map(d => ({ id: d.id, ...d.data() } as any));

      if (reportDateRange.start || reportDateRange.end) {
        const start = reportDateRange.start ? new Date(reportDateRange.start) : new Date(0);
        const end = reportDateRange.end ? new Date(reportDateRange.end) : new Date();
        end.setHours(23,59,59,999);
        orders = orders.filter((o: any) => {
          const date = o.createdAt?.toDate();
          return date >= start && date <= end;
        });
      }

      if (reportType === 'buyers' && selectedProductId !== 'all') {
        orders = orders.filter((o: any) => o.items?.some((i: any) => i.productId === selectedProductId));
      }

      const html = `
        <div dir="rtl" style="font-family: Arial, sans-serif; color: #333; text-align: right;">
          <h2 style="color: #4f46e5;">${subject} - ${config.orgName || config.siteName}</h2>
          <hr />
          <table style="width: 100%; border-collapse: collapse; margin-top: 20px; direction: rtl;">
            <thead>
              <tr style="background-color: #f3f4f6;">
                <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">מספר הזמנה</th>
                <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">לקוח</th>
                <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">פריטים</th>
                <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">סה"כ</th>
                <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">תאריך</th>
              </tr>
            </thead>
            <tbody>
              ${orders.map((o: any) => `
                <tr>
                  <td style="border: 1px solid #ddd; padding: 10px;">${o.orderNumber || o.id.slice(-6)}</td>
                  <td style="border: 1px solid #ddd; padding: 10px;">${o.customer?.name || '-'}</td>
                  <td style="border: 1px solid #ddd; padding: 10px;">
                    ${o.items?.map((i: any) => `${i.name} (${i.quantity})`).join(', ')}
                  </td>
                  <td style="border: 1px solid #ddd; padding: 10px;">${o.totalAmount?.toLocaleString()} ₪</td>
                  <td style="border: 1px solid #ddd; padding: 10px;">${o.createdAt?.toDate()?.toLocaleString('he-IL')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div style="margin-top: 20px; font-weight: bold;">
            סה"כ הזמנות: ${orders.length} | סה"כ הכנסות: ${orders.reduce((sum: number, o: any) => sum + (o.totalAmount || 0), 0).toLocaleString()} ₪
          </div>
        </div>
      `;

      await sendEmail({
        to: config.emailSettings.reportEmail,
        subject: `${subject} - ${config.orgName || config.siteName}`,
        html
      });

      toast.success('הדוח הונפק ונשלח למייל', { id: toastId });
      setShowReportModal(false);
    } catch (err) {
      console.error('Error generating report:', err);
      toast.error('שגיאה בהנפקת הדוח', { id: toastId });
    } finally {
      setGeneratingReport(false);
    }
  };

  const handleClearCarts = async () => {
    setClearingCarts(true);
    try {
      const cartsSnapshot = await getDocs(collection(db, 'active_carts'));
      const deletePromises = cartsSnapshot.docs.map(doc => deleteDoc(doc.ref));
      await Promise.all(deletePromises);
      toast.success(`נוקו ${cartsSnapshot.size} סלי קניות בהצלחה`);
      setShowConfirmClear(false);
    } catch (err) {
      console.error('Error clearing carts:', err);
      toast.error('שגיאה בניקוי סלי הקניות');
    } finally {
      setClearingCarts(false);
    }
  };

  const handleReconcileInventory = async () => {
    const loadingToast = toast.loading('סורק אי-התאמות במלאי...');
    setReconciling(true);
    setShowConfirmReconcile(false);
    try {
      console.log('Starting inventory reconciliation scan...');
      // 1. Fetch all products
      const productsSnapshot = await getDocs(collection(db, 'products'));
      const allProductsData = productsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      
      // 2. Fetch all orders
      const ordersSnapshot = await getDocs(collection(db, 'orders'));
      const orders = ordersSnapshot.docs.map(doc => doc.data() as any);

      // 3. Fetch all reservations
      const resSnapshot = await getDocs(collection(db, 'reservations'));
      const allReservationsData = resSnapshot.docs.map(doc => doc.data() as any);
      
      // 4. Calculate total ordered per product and variant (excluding cancelled orders)
      const totalOrdered: Record<string, { main: number, variants: Record<string, number> }> = {};
      orders.forEach(order => {
        if (order.status !== 'cancelled' && Array.isArray(order.items)) {
          order.items.forEach((item: any) => {
            if (!totalOrdered[item.productId]) totalOrdered[item.productId] = { main: 0, variants: {} };
            totalOrdered[item.productId].main += (item.quantity || 0);
            if (item.variantId) {
              totalOrdered[item.productId].variants[item.variantId] = (totalOrdered[item.productId].variants[item.variantId] || 0) + (item.quantity || 0);
            }
          });
        }
      });

      // 5. Calculate total reserved per product and variant
      const totalReserved: Record<string, { main: number, variants: Record<string, number> }> = {};
      allReservationsData.forEach(res => {
        if (!totalReserved[res.productId]) totalReserved[res.productId] = { main: 0, variants: {} };
        totalReserved[res.productId].main += (res.quantity || 0);
        if (res.variantId) {
          totalReserved[res.productId].variants[res.variantId] = (totalReserved[res.productId].variants[res.variantId] || 0) + (res.quantity || 0);
        }
      });
      
      // 6. Identify discrepancies
      const foundDiscrepancies: any[] = [];
      
      allProductsData.forEach(product => {
        const ordered = totalOrdered[product.id] || { main: 0, variants: {} };
        const reserved = totalReserved[product.id] || { main: 0, variants: {} };
        const stockQuantity = product.stockQuantity || 0;
        const reservedQuantity = product.reservedQuantity || 0;
        
        // Total stock should be: Available + Reserved + Ordered
        const currentTotal = product.totalStock || (stockQuantity + reservedQuantity + ordered.main);
        
        // Expected available stock is: Total - Reserved - Ordered
        const expectedAvailable = currentTotal - reserved.main - ordered.main;
        
        if (stockQuantity !== expectedAvailable || product.totalStock !== currentTotal || reservedQuantity !== reserved.main) {
          foundDiscrepancies.push({
            id: product.id,
            productId: product.id,
            isVariant: false,
            name: product.name,
            sku: product.sku,
            currentStock: stockQuantity,
            expectedStock: expectedAvailable,
            currentReserved: reservedQuantity,
            expectedReserved: reserved.main,
            currentTotal: product.totalStock || 0,
            expectedTotal: currentTotal
          });
        }

        // Check variants
        if (product.variants && Array.isArray(product.variants)) {
          product.variants.forEach((variant: any) => {
            const vOrdered = ordered.variants[variant.id] || 0;
            const vReserved = reserved.variants[variant.id] || 0;
            const vStockQuantity = variant.stockQuantity || 0;
            
            // Assume variant.totalStock exists, if not, compute it from current state
            const vCurrentTotal = variant.totalStock || (vStockQuantity + vReserved + vOrdered);
            const vExpectedAvailable = vCurrentTotal - vReserved - vOrdered;

            if (vStockQuantity !== vExpectedAvailable || variant.totalStock !== vCurrentTotal) {
              foundDiscrepancies.push({
                id: `${product.id}_${variant.id}`,
                productId: product.id,
                variantId: variant.id,
                isVariant: true,
                name: `${product.name} - ${variant.name}`,
                sku: product.sku,
                currentStock: vStockQuantity,
                expectedStock: vExpectedAvailable,
                currentTotal: variant.totalStock || 0,
                expectedTotal: vCurrentTotal
              });
            }
          });
        }
      });
      
      setDiscrepancies(foundDiscrepancies);
      if (foundDiscrepancies.length > 0) {
        setShowDiscrepanciesModal(true);
        toast.success(`נמצאו ${foundDiscrepancies.length} אי-התאמות במלאי`, { id: loadingToast });
      } else {
        toast.success('לא נמצאו אי-התאמות במלאי', { id: loadingToast });
      }
    } catch (err) {
      console.error('Inventory reconciliation error:', err);
      handleFirestoreError(err, OperationType.GET, 'multiple collections');
      toast.error('שגיאה בביצוע בדיקת מלאי', { id: loadingToast });
    } finally {
      setReconciling(false);
    }
  };

  const handleFixDiscrepancy = async (discrepancy: any) => {
    setFixingDiscrepancy(discrepancy.id);
    try {
      const productRef = doc(db, 'products', discrepancy.productId);
      
      if (discrepancy.isVariant) {
        const productSnap = await getDoc(productRef);
        if (productSnap.exists()) {
          const productData = productSnap.data();
          const newVariants = [...(productData.variants || [])];
          const vIndex = newVariants.findIndex((v: any) => v.id === discrepancy.variantId);
          if (vIndex !== -1) {
            newVariants[vIndex] = {
              ...newVariants[vIndex],
              stockQuantity: discrepancy.expectedStock,
              totalStock: discrepancy.expectedTotal
            };
            await updateDoc(productRef, { variants: newVariants });
          }
        }
      } else {
        await updateDoc(productRef, {
          stockQuantity: discrepancy.expectedStock,
          totalStock: discrepancy.expectedTotal,
          reservedQuantity: discrepancy.expectedReserved
        });
      }
      
      setDiscrepancies(prev => prev.filter(d => d.id !== discrepancy.id));
      toast.success(`המלאי עבור ${discrepancy.name} תוקן בהצלחה`);
    } catch (err) {
      console.error('Error fixing discrepancy:', err);
      handleFirestoreError(err, OperationType.UPDATE, `products/${discrepancy.productId}`);
      toast.error('שגיאה בתיקון המלאי');
    } finally {
      setFixingDiscrepancy(null);
    }
  };

  const handleApproveDiscrepancy = async (discrepancy: any) => {
    setFixingDiscrepancy(discrepancy.id);
    try {
      const productRef = doc(db, 'products', discrepancy.productId);
      
      const newTotal = discrepancy.currentStock + discrepancy.currentTotal - discrepancy.expectedStock;

      if (discrepancy.isVariant) {
        const productSnap = await getDoc(productRef);
        if (productSnap.exists()) {
          const productData = productSnap.data();
          const newVariants = [...(productData.variants || [])];
          const vIndex = newVariants.findIndex((v: any) => v.id === discrepancy.variantId);
          if (vIndex !== -1) {
            newVariants[vIndex] = {
              ...newVariants[vIndex],
              totalStock: newTotal
            };
            await updateDoc(productRef, { variants: newVariants });
          }
        }
      } else {
        await updateDoc(productRef, {
          totalStock: newTotal,
          reservedQuantity: discrepancy.expectedReserved
        });
      }
      
      setDiscrepancies(prev => prev.filter(d => d.id !== discrepancy.id));
      toast.success(`המלאי הכללי עבור ${discrepancy.name} אושר ועודכן`);
    } catch (err) {
      console.error('Error approving discrepancy:', err);
      handleFirestoreError(err, OperationType.UPDATE, `products/${discrepancy.productId}`);
      toast.error('שגיאה באישור המלאי');
    } finally {
      setFixingDiscrepancy(null);
    }
  };

  const handleApproveAllDiscrepancies = async () => {
    const loadingToast = toast.loading('מאשר את כל אי-ההתאמות...');
    setReconciling(true);
    try {
      const batch = writeBatch(db);
      
      const updatesByProduct: Record<string, any> = {};
      
      for (const discrepancy of discrepancies) {
         if (!updatesByProduct[discrepancy.productId]) {
            updatesByProduct[discrepancy.productId] = { variants: {} };
         }
         
         const newTotal = discrepancy.currentStock + discrepancy.currentTotal - discrepancy.expectedStock;
         
         if (discrepancy.isVariant) {
            updatesByProduct[discrepancy.productId].variants[discrepancy.variantId] = {
               totalStock: newTotal
            };
         } else {
            updatesByProduct[discrepancy.productId].main = {
               totalStock: newTotal,
               reservedQuantity: discrepancy.expectedReserved
            };
         }
      }
      
      for (const [productId, updates] of Object.entries(updatesByProduct)) {
         const productRef = doc(db, 'products', productId);
         let updatePayload: any = { ...updates.main };
         
         if (Object.keys(updates.variants).length > 0) {
            const productSnap = await getDoc(productRef);
            if (productSnap.exists()) {
               const productData = productSnap.data();
               const newVariants = [...(productData.variants || [])];
               for (const [vId, vUpdates] of Object.entries(updates.variants)) {
                  const vIndex = newVariants.findIndex((v: any) => v.id === vId);
                  if (vIndex !== -1) {
                     newVariants[vIndex] = { ...newVariants[vIndex], ...(vUpdates as any) };
                  }
               }
               updatePayload.variants = newVariants;
            }
         }
         batch.update(productRef, updatePayload);
      }
      
      await batch.commit();
      setDiscrepancies([]);
      setShowDiscrepanciesModal(false);
      toast.success('המלאי הכללי עורכן עבור כל המוצרים', { id: loadingToast });
    } catch (err) {
      console.error('Inventory reconciliation error:', err);
      handleFirestoreError(err, OperationType.UPDATE, 'multiple products');
      toast.error('שגיאה באישור המלאים', { id: loadingToast });
    } finally {
      setReconciling(false);
    }
  };

  const handleFixAllDiscrepancies = async () => {
    const loadingToast = toast.loading('מתקן את כל אי-ההתאמות...');
    setReconciling(true);
    try {
      const batch = writeBatch(db);
      
      // Group discrepancies by productId
      const updatesByProduct: Record<string, any> = {};
      
      for (const discrepancy of discrepancies) {
         if (!updatesByProduct[discrepancy.productId]) {
            updatesByProduct[discrepancy.productId] = { variants: {} };
         }
         
         if (discrepancy.isVariant) {
            updatesByProduct[discrepancy.productId].variants[discrepancy.variantId] = {
               stockQuantity: discrepancy.expectedStock,
               totalStock: discrepancy.expectedTotal
            };
         } else {
            updatesByProduct[discrepancy.productId].main = {
               stockQuantity: discrepancy.expectedStock,
               totalStock: discrepancy.expectedTotal,
               reservedQuantity: discrepancy.expectedReserved
            };
         }
      }
      
      for (const [productId, updates] of Object.entries(updatesByProduct)) {
         const productRef = doc(db, 'products', productId);
         let updatePayload: any = { ...updates.main };
         
         if (Object.keys(updates.variants).length > 0) {
            const productSnap = await getDoc(productRef);
            if (productSnap.exists()) {
               const productData = productSnap.data();
               const newVariants = [...(productData.variants || [])];
               for (const [vId, vUpdates] of Object.entries(updates.variants)) {
                  const vIndex = newVariants.findIndex((v: any) => v.id === vId);
                  if (vIndex !== -1) {
                     newVariants[vIndex] = { ...newVariants[vIndex], ...(vUpdates as any) };
                  }
               }
               updatePayload.variants = newVariants;
            }
         }
         batch.update(productRef, updatePayload);
      }
      
      await batch.commit();
      setDiscrepancies([]);
      setShowDiscrepanciesModal(false);
      toast.success('כל אי-ההתאמות תוקנו בהצלחה', { id: loadingToast });
      dataCache.products = {};
    } catch (err) {
      console.error('Error fixing all discrepancies:', err);
      handleFirestoreError(err, OperationType.WRITE, 'products');
      toast.error('שגיאה בתיקון המלאי', { id: loadingToast });
    } finally {
      setReconciling(false);
    }
  };

  const handleAddReservation = async () => {
    if (!reservationForm.productId || reservationForm.quantity <= 0) {
      toast.error('אנא בחר מוצר והזן כמות תקינה');
      return;
    }

    const product = products.find(p => p.id === reservationForm.productId);
    if (!product) {
      toast.error('מוצר לא נמצא');
      return;
    }

    if (reservationForm.variantId) {
      const variant = product.variants?.find((v: any) => v.id === reservationForm.variantId);
      if (!variant) {
        toast.error('תת-מוצר לא נמצא');
        return;
      }
      if (variant.stockQuantity < reservationForm.quantity) {
        toast.error('אין מספיק מלאי זמין לשריון בתת-מוצר זה');
        return;
      }
    } else if (product.stockQuantity < reservationForm.quantity) {
      toast.error('אין מספיק מלאי זמין לשריון');
      return;
    }

    setIsReserving(true);
    try {
      const batch = writeBatch(db);
      const category = categories.find(c => c.id === product.categoryId);
      
      // 1. Create reservation
      const resRef = doc(collection(db, 'reservations'));
      const reservationData: any = {
        productId: product.id,
        productName: product.name,
        productSku: product.sku || '',
        productCategory: category?.name || 'ללא קטגוריה',
        quantity: reservationForm.quantity,
        note: reservationForm.note,
        createdAt: serverTimestamp(),
        createdBy: {
          uid: auth.currentUser?.uid || 'admin',
          name: auth.currentUser?.displayName || 'מנהל',
          email: auth.currentUser?.email || ''
        }
      };

      if (reservationForm.variantId) {
        reservationData.variantId = reservationForm.variantId;
        reservationData.variantName = reservationForm.variantName;
      }

      batch.set(resRef, reservationData);

      // 2. Update product stock
      const productRef = doc(db, 'products', product.id);
      const updateData: any = {
        stockQuantity: increment(-reservationForm.quantity),
        reservedQuantity: increment(reservationForm.quantity)
      };

      if (reservationForm.variantId && product.variants) {
        const newVariants = product.variants.map((v: any) => 
          v.id === reservationForm.variantId 
            ? { ...v, stockQuantity: v.stockQuantity - reservationForm.quantity } 
            : v
        );
        updateData.variants = newVariants;
      }

      batch.update(productRef, updateData);

      await batch.commit();
      toast.success('המלאי שוריין בהצלחה');

      // Send notification if enabled
      if (!config.emailSettings?.disableAllEmails && config.emailSettings?.notifyReservation !== false) {
        try {
          const emailData = formatReservationEmail(reservationData, config, 'new');
          await sendEmail({
            ...emailData,
            to: config.emailSettings?.reportEmail || config.emailSettings?.mainEmail || '',
            userEmail: config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.email || undefined : undefined,
            userName: config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.displayName || undefined : undefined,
            replyTo: config.emailSettings?.replyToType === 'fixed' ? config.emailSettings?.fixedReplyToEmail : (auth.currentUser?.email || undefined)
          });
        } catch (emailErr) {
          console.error('Error sending reservation notification:', emailErr);
        }
      }
      setIsAddingReservation(false);
      setReservationForm({ 
        productId: '', 
        productName: '',
        productSku: '',
        productCategory: '',
        variantId: '',
        variantName: '',
        quantity: 1, 
        note: '' 
      });
    } catch (err) {
      console.error('Error adding reservation:', err);
      handleFirestoreError(err, OperationType.WRITE, 'reservations/products');
      toast.error('שגיאה בשריון המלאי');
    } finally {
      setIsReserving(false);
    }
  };

  const [showConfirmCancelRes, setShowConfirmCancelRes] = useState<Reservation | null>(null);
  const [showConfirmConvertRes, setShowConfirmConvertRes] = useState<Reservation | null>(null);

  const handleCancelReservation = async (res: Reservation) => {
    setShowConfirmCancelRes(null);
    try {
      const productDoc = await getDoc(doc(db, 'products', res.productId));
      const product = productDoc.exists() ? productDoc.data() as any : null;

      const batch = writeBatch(db);
      
      // 1. Delete reservation
      batch.delete(doc(db, 'reservations', res.id));

      // 2. Return stock to product
      if (product) {
        const productRef = doc(db, 'products', res.productId);
        const updateData: any = {
          stockQuantity: increment(res.quantity),
          reservedQuantity: increment(-res.quantity)
        };

        if (res.variantId && product.variants) {
          const newVariants = product.variants.map((v: any) => 
            v.id === res.variantId 
              ? { ...v, stockQuantity: v.stockQuantity + res.quantity } 
              : v
          );
          updateData.variants = newVariants;
        }

        batch.update(productRef, updateData);
      }

      await batch.commit();
      toast.success('השריון בוטל והמלאי הוחזר');

      // Send notification if enabled
      if (!config.emailSettings?.disableAllEmails && config.emailSettings?.notifyReservationDelete !== false) {
        try {
          const emailData = formatReservationEmail(res, config, 'delete');
          await sendEmail({
            ...emailData,
            to: config.emailSettings?.reportEmail || config.emailSettings?.mainEmail || '',
            userEmail: config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.email || undefined : undefined,
            userName: config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.displayName || undefined : undefined,
            replyTo: config.emailSettings?.replyToType === 'fixed' ? config.emailSettings?.fixedReplyToEmail : (auth.currentUser?.email || undefined)
          });
        } catch (emailErr) {
          console.error('Error sending reservation delete notification:', emailErr);
        }
      }
    } catch (err) {
      console.error('Error cancelling reservation:', err);
      handleFirestoreError(err, OperationType.WRITE, `reservations/${res.id}`);
      toast.error('שגיאה בביטול השריון');
    }
  };

  const handleConvertToOrder = async (res: Reservation) => {
    setShowConfirmConvertRes(null);
    try {
      const batch = writeBatch(db);
      
      // 1. Get next order number
      const configDocRef = doc(db, 'config', 'system');
      const configDoc = await getDoc(configDocRef);
      let nextOrderNumber = 1000;
      if (configDoc.exists()) {
        nextOrderNumber = (configDoc.data().orderCounter || 1000) + 1;
      }
      batch.set(configDocRef, { orderCounter: nextOrderNumber }, { merge: true });

      const product = products.find(p => p.id === res.productId);
      
      let price = product?.price || 0;
      if (res.variantId && product?.variants) {
        const variant = product.variants.find((v: any) => v.id === res.variantId);
        if (variant && variant.price !== undefined) {
          price = variant.price;
        }
      }

      // 2. Create Order
      const orderRef = doc(collection(db, 'orders'));
      const orderItem: any = {
        productId: res.productId,
        name: res.productName,
        quantity: res.quantity,
        price: price
      };

      if (res.variantId) {
        orderItem.variantId = res.variantId;
        orderItem.variantName = res.variantName;
      }

      batch.set(orderRef, {
        orderNumber: nextOrderNumber,
        customer: { name: res.note || 'לקוח משריון' },
        items: [orderItem],
        totalAmount: price * res.quantity,
        status: 'pending',
        createdAt: serverTimestamp(),
        createdBy: {
          uid: auth.currentUser?.uid || 'admin',
          name: auth.currentUser?.displayName || 'מנהל',
          email: auth.currentUser?.email || ''
        }
      });

      // 3. Delete reservation
      batch.delete(doc(db, 'reservations', res.id));

      // 4. Update reserved quantity (stockQuantity was already deducted when reserved)
      const productRef = doc(db, 'products', res.productId);
      batch.update(productRef, {
        reservedQuantity: increment(-res.quantity)
      });

      await batch.commit();
      toast.success('השריון הפך להזמנה בהצלחה');

      // Send notification if enabled
      if (!config.emailSettings?.disableAllEmails && config.emailSettings?.notifyReservationToOrder !== false) {
        try {
          const emailData = formatReservationEmail(res, config, 'convert');
          await sendEmail({
            ...emailData,
            to: config.emailSettings?.reportEmail || config.emailSettings?.mainEmail || '',
            userEmail: config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.email || undefined : undefined,
            userName: config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.displayName || undefined : undefined,
            replyTo: config.emailSettings?.replyToType === 'fixed' ? config.emailSettings?.fixedReplyToEmail : (auth.currentUser?.email || undefined)
          });
        } catch (emailErr) {
          console.error('Error sending reservation convert notification:', emailErr);
        }
      }
    } catch (err) {
      console.error('Error converting reservation:', err);
      handleFirestoreError(err, OperationType.WRITE, 'orders/reservations');
      toast.error('שגיאה בהמרת השריון להזמנה');
    }
  };

  const addField = () => {
    const id = Math.random().toString(36).substr(2, 9);
    setEditingField({ id, label: '', type: 'text', options: [], required: false });
    setFieldForm({ id, label: '', type: 'text', options: [], required: false });
  };

  const saveField = () => {
    if (!fieldForm.label) return;
    const fields = [...config.customerFormFields];
    const index = fields.findIndex(f => f.id === fieldForm.id);
    if (index > -1) {
      fields[index] = fieldForm;
    } else {
      fields.push(fieldForm);
    }
    setConfig({ ...config, customerFormFields: fields });
    setEditingField(null);
  };

  const removeField = (id: string) => {
    setConfig({ ...config, customerFormFields: config.customerFormFields.filter(f => f.id !== id) });
  };

  const moveField = (index: number, direction: 'up' | 'down') => {
    const newFields = [...config.customerFormFields];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex < 0 || targetIndex >= newFields.length) return;
    
    [newFields[index], newFields[targetIndex]] = [newFields[targetIndex], newFields[index]];
    
    setConfig({
      ...config,
      customerFormFields: newFields
    });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto font-sans text-right" dir="rtl">
      <div className="mb-12">
        <h2 className="text-3xl font-bold text-zinc-900 tracking-tight">הגדרות מערכת</h2>
        <p className="text-zinc-500 mt-1">נהל משתמשים, הרשאות והגדרות טפסים</p>
      </div>

      <div className="grid grid-cols-1 gap-12">
        {/* Inventory Reservations Section */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Package size={24} className="text-amber-600" />
              <h3 className="text-xl font-bold text-zinc-900">שריון מלאים</h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowConfirmClear(true)}
                disabled={clearingCarts}
                className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-xl font-bold hover:bg-red-100 transition-all border border-red-200 disabled:opacity-50 text-sm"
              >
                {clearingCarts ? <Loader2 className="animate-spin" size={16} /> : <Eraser size={16} />}
                ריקון סלים פעילים
              </button>
              <button
                onClick={() => setShowConfirmReconcile(true)}
                disabled={reconciling}
                className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-600 rounded-xl font-bold hover:bg-emerald-100 transition-all border border-emerald-200 disabled:opacity-50 text-sm"
              >
                {reconciling ? <Loader2 className="animate-spin" size={16} /> : <RefreshCw size={16} />}
                סנכרון מלאים
              </button>
              <button
                onClick={() => setIsAddingReservation(true)}
                className="bg-amber-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-amber-700 transition-all shadow-lg shadow-amber-500/20"
              >
                <Plus size={18} />
                שריון מלאי חדש
              </button>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
            {reservations.length === 0 ? (
              <div className="p-12 text-center space-y-4">
                <div className="w-16 h-16 bg-zinc-50 rounded-full flex items-center justify-center mx-auto text-zinc-300">
                  <Package size={32} />
                </div>
                <p className="text-zinc-500 font-medium">אין שריוני מלאי פעילים</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right">
                  <thead>
                    <tr className="bg-zinc-50 border-b border-zinc-100">
                      <th className="px-6 py-4 text-sm font-bold text-zinc-600">מוצר</th>
                      <th className="px-6 py-4 text-sm font-bold text-zinc-600">מק"ט</th>
                      <th className="px-6 py-4 text-sm font-bold text-zinc-600">קטגוריה</th>
                      <th className="px-6 py-4 text-sm font-bold text-zinc-600 text-center">כמות</th>
                      <th className="px-6 py-4 text-sm font-bold text-zinc-600">הערה/לקוח</th>
                      <th className="px-6 py-4 text-sm font-bold text-zinc-600">תאריך</th>
                      <th className="px-6 py-4 text-sm font-bold text-zinc-600 text-left">פעולות</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-100">
                    {reservations.map(res => (
                      <tr key={res.id} className="hover:bg-zinc-50/50 transition-colors">
                        <td className="px-6 py-4">
                          <p className="font-bold text-zinc-900">
                            {res.productName}
                            {res.variantName && <span className="text-zinc-500 font-normal mr-2">({res.variantName})</span>}
                          </p>
                        </td>
                        <td className="px-6 py-4 text-zinc-500 text-xs font-mono">{res.productSku || '-'}</td>
                        <td className="px-6 py-4 text-zinc-500 text-xs">{res.productCategory || '-'}</td>
                        <td className="px-6 py-4 text-center">
                          <span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-xs font-bold">
                            {res.quantity} יח'
                          </span>
                        </td>
                        <td className="px-6 py-4 text-zinc-500 text-sm">{res.note || '-'}</td>
                        <td className="px-6 py-4 text-zinc-400 text-xs">
                          {res.createdAt?.toDate().toLocaleDateString('he-IL')}
                        </td>
                        <td className="px-6 py-4 text-left">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => setShowConfirmConvertRes(res)}
                              className="px-3 py-1.5 bg-emerald-50 text-emerald-600 rounded-lg text-xs font-bold hover:bg-emerald-100 transition-all flex items-center gap-1"
                              title="הפוך להזמנה"
                            >
                              <ShoppingCart size={14} />
                              הפוך להזמנה
                            </button>
                            <button
                              onClick={() => setShowConfirmCancelRes(res)}
                              className="p-1.5 text-zinc-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                              title="בטל שריון"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
        {/* Branding Section */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <Layout size={24} className="text-indigo-600" />
              <h3 className="text-xl font-bold text-zinc-900">מיתוג האתר</h3>
            </div>
            <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 mb-2">שם האתר</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                    value={config.siteName || ''}
                    onChange={(e) => setConfig({ ...config, siteName: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 mb-2">שם הארגון</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                    value={config.orgName || ''}
                    onChange={(e) => setConfig({ ...config, orgName: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-4">לוגו הארגון</label>
                <div className="flex items-center gap-8">
                  <div className="w-32 h-32 bg-zinc-50 rounded-2xl border-2 border-dashed border-zinc-200 flex items-center justify-center overflow-hidden relative group">
                    {config.logoUrl ? (
                      <>
                        <img src={config.logoUrl} alt="Logo" className="w-full h-full object-contain p-2" referrerPolicy="no-referrer" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button onClick={async () => {
                            const newConfig = { ...config, logoUrl: '' };
                            if ('id' in newConfig) delete (newConfig as any).id;
                            await setDoc(doc(db, 'config', 'system'), newConfig);
                            setConfig(newConfig);
                            toast.success('הלוגו הוסר בהצלחה');
                          }} className="text-white bg-red-500 p-2 rounded-full hover:bg-red-600 transition-colors">
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </>
                    ) : (
                      <div className="text-center">
                        <ImageIcon size={32} className="mx-auto text-zinc-300 mb-2" />
                        <p className="text-[10px] font-bold text-zinc-400 uppercase">אין לוגו</p>
                      </div>
                    )}
                  </div>
                  <div className="flex-1 space-y-4">
                    <p className="text-sm text-zinc-500">העלה לוגו בפורמט PNG או JPG. מומלץ להשתמש ברקע שקוף.</p>
                    <div className="flex flex-col gap-3">
                      <div className="relative inline-block">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleLogoUpload}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
                          disabled={uploadingLogo}
                        />
                        <button className="bg-zinc-900 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-zinc-800 transition-all disabled:opacity-50">
                          {uploadingLogo ? <Loader2 className="animate-spin" size={18} /> : <Upload size={18} />}
                          העלאת לוגו
                        </button>
                      </div>
                      <div className="relative">
                        <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                          <ImageIcon size={16} className="text-zinc-400" />
                        </div>
                        <input 
                          type="url" 
                          placeholder="או הדבק קישור ללוגו כאן..." 
                          className="w-full pr-10 pl-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-right"
                          value={config.logoUrl || ''}
                          onChange={(e) => setConfig({ ...config, logoUrl: e.target.value })}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-4">פאביקון (Favicon)</label>
                <div className="flex items-center gap-8">
                  <div className="w-16 h-16 bg-zinc-50 rounded-xl border-2 border-dashed border-zinc-200 flex items-center justify-center overflow-hidden relative group">
                    {config.faviconUrl ? (
                      <>
                        <img src={config.faviconUrl} alt="Favicon" className="w-full h-full object-contain p-2" referrerPolicy="no-referrer" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button onClick={async () => {
                            const newConfig = { ...config, faviconUrl: '' };
                            if ('id' in newConfig) delete (newConfig as any).id;
                            await setDoc(doc(db, 'config', 'system'), newConfig);
                            setConfig(newConfig);
                            toast.success('הפאביקון הוסר בהצלחה');
                          }} className="text-white bg-red-500 p-1.5 rounded-full hover:bg-red-600 transition-colors">
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </>
                    ) : (
                      <div className="text-center">
                        <ImageIcon size={20} className="mx-auto text-zinc-300 mb-1" />
                        <p className="text-[8px] font-bold text-zinc-400 uppercase">אין</p>
                      </div>
                    )}
                  </div>
                  <div className="flex-1 space-y-4">
                    <p className="text-xs text-zinc-500">העלה תמונה קטנה (16x16 או 32x32) שתופיע בלשונית הדפדפן.</p>
                    <div className="relative inline-block">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFaviconUpload}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
                        disabled={uploadingFavicon}
                      />
                      <button className="bg-zinc-100 text-zinc-900 px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-zinc-200 transition-all disabled:opacity-50">
                        {uploadingFavicon ? <Loader2 className="animate-spin" size={16} /> : <Upload size={16} />}
                        העלאת פאביקון
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sales Archive Settings Section */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <ArchiveIcon size={24} className="text-indigo-600" />
              <h3 className="text-xl font-bold text-zinc-900">ניהול מכירות וארכיון</h3>
            </div>
            <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-zinc-900">הפעל מצב ארכיון ומכירות</h4>
                  <p className="text-sm text-zinc-500">
                    הוסף לשונית לניהול מכירות המאפשרת לארכב נתונים ולהתחיל מכירות חדשות.
                  </p>
                </div>
                <button
                  onClick={async () => {
                    const newConfig = { ...config, enableSalesArchive: !config.enableSalesArchive };
                    setConfig(newConfig);
                    await setDoc(doc(db, 'config', 'system'), newConfig);
                    toast.success('הגדרות הארכיון עודכנו');
                  }}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 ${config.enableSalesArchive ? 'bg-indigo-600' : 'bg-zinc-200'}`}
                  dir="ltr"
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${config.enableSalesArchive ? 'translate-x-6' : 'translate-x-1'}`}
                  />
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <FormInput size={24} className="text-indigo-600" />
              <h3 className="text-xl font-bold text-zinc-900">הגדרת טופס לקוח</h3>
            </div>

          <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
            <div>
              <label className="block text-sm font-semibold text-zinc-700 mb-2">כותרת מעל הטופס</label>
              <input
                type="text"
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                value={config.customerFormTitle || ''}
                onChange={(e) => setConfig({ ...config, customerFormTitle: e.target.value })}
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label className="block text-sm font-semibold text-zinc-700">שדות הטופס</label>
                <button
                  onClick={addField}
                  className="text-indigo-600 hover:text-indigo-700 text-sm font-bold flex items-center gap-1"
                >
                  <Plus size={16} />
                  הוסף שדה
                </button>
              </div>
              
              <div className="space-y-2">
                {config.customerFormFields.map((field, index) => (
                  <div key={field.id} className="bg-zinc-50 p-4 rounded-2xl border border-zinc-200 flex items-center justify-between group">
                    <div className="flex items-center gap-4">
                      <div className="flex flex-col gap-1">
                        <button 
                          onClick={() => moveField(index, 'up')}
                          disabled={index === 0}
                          className="p-1 text-zinc-400 hover:text-indigo-600 disabled:opacity-20 transition-all"
                        >
                          <ChevronUp size={14} />
                        </button>
                        <button 
                          onClick={() => moveField(index, 'down')}
                          disabled={index === config.customerFormFields.length - 1}
                          className="p-1 text-zinc-400 hover:text-indigo-600 disabled:opacity-20 transition-all"
                        >
                          <ChevronDown size={14} />
                        </button>
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-bold text-zinc-900">{field.label}</p>
                          {field.required && <span className="text-[10px] bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-bold">חובה</span>}
                          {!field.hideInReports && <span className="text-[10px] bg-indigo-100 text-indigo-600 px-2 py-0.5 rounded-full font-bold">מופיע בדוחות</span>}
                          {field.hideInReports && <span className="text-[10px] bg-zinc-100 text-zinc-500 px-2 py-0.5 rounded-full font-bold">מוסתר בדוחות</span>}
                        </div>
                        <p className="text-xs text-zinc-400">
                          {field.type === 'text' ? 'טקסט חופשי' : 
                           field.type === 'number' ? 'ספרות בלבד' : 
                           field.type === 'date' ? 'תאריך' : 
                           field.type === 'email' ? 'אימייל' : 'רשימה נפתחת'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => { setEditingField(field); setFieldForm(field); }}
                        className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-white rounded-lg transition-all"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => removeField(field.id)}
                        className="p-2 text-zinc-400 hover:text-red-500 hover:bg-white rounded-lg transition-all"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-6 border-t border-zinc-100 flex flex-col gap-4">

              {/* Email Settings Section */}
              <div className="space-y-6 pb-6 border-b border-zinc-100" id="smtp-settings-card">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Mail size={24} className="text-indigo-600" />
                    <div>
                      <h3 className="text-xl font-bold text-zinc-900">הגדרות אימייל (Gmail SMTP)</h3>
                      <p className="text-xs text-zinc-500">ניהול חיבור הדואר, בדיקות אמינות ומניעת ניתוקים</p>
                    </div>
                  </div>
                  
                  {emailHealthStatus && (
                    <div className="flex items-center gap-2">
                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                        emailHealthStatus.healthy 
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                          : 'bg-rose-100 text-rose-800 border border-rose-200 animate-pulse'
                      }`}>
                        <span className={`w-2 h-2 rounded-full ${emailHealthStatus.healthy ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                        {emailHealthStatus.healthy ? 'שרת Google מאומת ומחובר' : 'שגיאת אימות / נדרש עדכון סיסמה'}
                      </span>
                    </div>
                  )}
                </div>
                
                <div className="bg-white p-6 md:p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-7">
                  
                  {/* Real-time Connection Health Card */}
                  <div className={`p-5 rounded-2xl border transition-all ${
                    emailHealthStatus?.healthy
                      ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                      : 'bg-rose-50/80 border-rose-200 text-rose-950'
                  }`}>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-start gap-3">
                        <div className={`p-2.5 rounded-xl shrink-0 ${
                          emailHealthStatus?.healthy ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                        }`}>
                          {emailHealthStatus?.healthy ? <ShieldCheck size={24} /> : <AlertTriangle size={24} />}
                        </div>
                        <div className="space-y-1">
                          <h4 className="font-extrabold text-base">
                            {emailHealthStatus?.healthy 
                              ? 'חיבור ה-Gmail תקין ופעיל לשליחת הודעות' 
                              : 'חיבור ה-Gmail מנותק או סיסמת האפליקציה פגת תוקף'}
                          </h4>
                          <p className="text-xs opacity-90 leading-relaxed max-w-2xl">
                            {emailHealthStatus?.healthy 
                              ? `חשבון השולח המוגדר: ${secrets.emailUser || 'מוגדר'}. כל המיילים של הזמנות ודוחות נשלחים בזמן אמת.`
                              : (emailHealthStatus?.error || 'שרת Google דחה את פרטי ההתחברות (535 Bad Credentials). יש להפיק סיסמת אפליקציה חדשה ולהזינה מטה.')}
                          </p>
                          {emailHealthStatus?.lastChecked && (
                            <p className="text-[11px] opacity-75 pt-0.5">
                              בדיקה אחרונה: {new Date(emailHealthStatus.lastChecked).toLocaleString('he-IL')}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                        <button
                          type="button"
                          onClick={handleRefreshEmailHealth}
                          disabled={checkingHealth}
                          className="px-3.5 py-2 bg-white hover:bg-zinc-50 border border-zinc-200 text-zinc-800 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 disabled:opacity-50"
                        >
                          <RefreshCw size={14} className={checkingHealth ? 'animate-spin text-indigo-600' : 'text-zinc-600'} />
                          <span>{checkingHealth ? 'בודק כעת...' : 'בדיקת דופק עכשיו'}</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Pending Emails Queue Card */}
                  {(emailHealthStatus?.pendingCount ?? 0) > 0 && (
                    <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-950 space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-amber-200/60 rounded-xl text-amber-800">
                            <Clock size={20} />
                          </div>
                          <div>
                            <p className="font-bold text-sm">
                              ישנם <span className="underline font-black text-amber-900">{emailHealthStatus?.pendingCount} מיילים</span> שנשמרו בתור בעת שהחיבור היה מנותק!
                            </p>
                            <p className="text-xs text-amber-800">
                              המיילים הללו לא הלכו לאיבוד. בעת עדכון סיסמה תקינה הם יישלחו אוטומטית, או שתוכל לשלוח אותם בלחיצה.
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={handleFlushEmailQueue}
                            disabled={flushingQueue}
                            className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-all shadow flex items-center gap-1.5 disabled:opacity-50"
                          >
                            <Send size={14} className={flushingQueue ? 'animate-pulse' : ''} />
                            <span>{flushingQueue ? 'שולח...' : 'שלח את כל המיילים שבתור'}</span>
                          </button>
                          <button
                            type="button"
                            onClick={handleClearEmailQueue}
                            className="p-2 text-amber-800 hover:text-red-700 hover:bg-amber-100 rounded-lg transition-colors text-xs font-medium"
                            title="נקה תור"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* SMTP Credentials Form */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                      <h4 className="font-bold text-base text-zinc-900 flex items-center gap-2">
                        <Lock size={18} className="text-indigo-600" />
                        <span>פרטי חשבון Gmail לשליחה</span>
                      </h4>
                      <a
                        href="https://myaccount.google.com/apppasswords"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-indigo-600 hover:text-indigo-800 font-bold hover:underline flex items-center gap-1"
                      >
                        <span>הפקת סיסמת אפליקציה ב-Google (16 אותיות)</span>
                        <span>↗</span>
                      </a>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-semibold text-zinc-700 mb-1.5">כתובת Gmail לשליחה</label>
                        <input
                          type="email"
                          placeholder="example@gmail.com"
                          className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-left font-mono text-sm"
                          dir="ltr"
                          value={secrets.emailUser || ''}
                          onChange={(e) => {
                            setSecrets({ ...secrets, emailUser: e.target.value });
                            setTestResult(null);
                          }}
                        />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-1.5">
                          <label className="block text-sm font-semibold text-zinc-700">סיסמת אפליקציה (16 תווים)</label>
                          <button
                            type="button"
                            onClick={() => setShowEmailPass(!showEmailPass)}
                            className="text-xs text-zinc-500 hover:text-indigo-600 flex items-center gap-1 font-medium"
                          >
                            {showEmailPass ? <EyeOff size={14} /> : <Eye size={14} />}
                            <span>{showEmailPass ? 'הסתר' : 'הצג סיסמה'}</span>
                          </button>
                        </div>
                        <div className="relative">
                          <input
                            type={showEmailPass ? "text" : "password"}
                            placeholder="xxxx xxxx xxxx xxxx"
                            className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-left tracking-wider font-mono text-sm"
                            dir="ltr"
                            value={secrets.emailPass || ''}
                            onChange={(e) => {
                              setSecrets({ ...secrets, emailPass: e.target.value });
                              setTestResult(null);
                            }}
                          />
                        </div>
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-sm font-semibold text-zinc-700 mb-1.5">שם השולח (יופיע לנמענים)</label>
                        <input
                          type="text"
                          placeholder='לדוגמה: "מערכת רכש והזמנות"'
                          className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                          value={secrets.emailFromName || ''}
                          onChange={(e) => setSecrets({ ...secrets, emailFromName: e.target.value })}
                        />
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="pt-2 flex flex-wrap items-center gap-3">
                      <button
                        type="button"
                        onClick={handleSaveOnlyEmailSecrets}
                        disabled={savingEmailSecrets || !secrets.emailUser || !secrets.emailPass}
                        className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-all flex items-center gap-2 text-sm shadow-md shadow-indigo-600/20 disabled:opacity-50"
                      >
                        {savingEmailSecrets ? (
                          <Loader2 size={16} className="animate-spin" />
                        ) : (
                          <Save size={16} />
                        )}
                        <span>{savingEmailSecrets ? 'שומר ומאמת...' : 'שמור והחל פרטי Gmail'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleTestEmail}
                        disabled={testingEmail || !secrets.emailUser || !secrets.emailPass}
                        className="px-4 py-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 rounded-xl font-bold transition-all flex items-center gap-2 text-sm disabled:opacity-50"
                      >
                        {testingEmail ? (
                          <Loader2 size={16} className="animate-spin text-zinc-600" />
                        ) : (
                          <Send size={16} className="text-zinc-600" />
                        )}
                        <span>{testingEmail ? 'בודק חיבור מול Google...' : 'בדיקת שליחה ואימות'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          notifyAdminEmailFailure({
                            orderNumber: 1084,
                            customerName: 'ישראל ישראלי (הדמיית בדיקה)',
                            error: '535-5.7.8 Username and Password not accepted (סימולציית שגיאה)',
                            recipient: config?.emailSettings?.reportEmail || 'admin@domain.com',
                            totalAmount: 480,
                            onRetry: () => {
                              toast.success('סימולציה: ההזמנה נשלחה מחדש בהצלחה!');
                            }
                          });
                        }}
                        className="px-4 py-2.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl font-bold transition-all flex items-center gap-2 text-sm"
                        title="הפעל סימולציה של התראת כישלון מייל דחופה למנהל"
                      >
                        <BellRing size={16} className="text-red-600" />
                        <span>בדיקת התראה דחופה למנהל</span>
                      </button>
                    </div>

                    {testResult && (
                      <div
                        className={`p-4 rounded-2xl border text-sm transition-all ${
                          testResult.success
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                            : 'bg-rose-50 border-rose-200 text-rose-800'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          {testResult.success ? (
                            <CheckCircle2 size={20} className="text-emerald-600 shrink-0 mt-0.5" />
                          ) : (
                            <AlertTriangle size={20} className="text-rose-600 shrink-0 mt-0.5" />
                          )}
                          <div className="space-y-1">
                            <p className="font-bold">{testResult.message}</p>
                            {!testResult.success && (
                              <ul className="list-disc list-inside text-xs space-y-1 text-rose-700 mt-2">
                                <li>ודאו שאימות דו-שלבי (2-Step Verification) מופעל בחשבון Google.</li>
                                <li>השתמשו ב"סיסמת אפליקציות" בת 16 אותיות בלבד (לא בסיסמה הראשית של החשבון).</li>
                                <li>ודאו שכתובת המייל שהזנתם זהה בדיוק לחשבון בו הופקה הסיסמה.</li>
                              </ul>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Comprehensive Guide: Preventing Password Invalidation */}
                  <div className="p-5 rounded-2xl bg-indigo-50/60 border border-indigo-100 text-zinc-700 space-y-3">
                    <div className="flex items-center gap-2 text-indigo-950 font-bold text-sm">
                      <HelpCircle size={18} className="text-indigo-600" />
                      <span>מידע חשוב: למה הסיסמה התנתקה בעבר וכיצד פתרנו זאת לצמיתות?</span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-zinc-600 leading-relaxed">
                      <div className="space-y-1.5 p-3.5 bg-white rounded-xl border border-indigo-100/80 shadow-xs">
                        <p className="font-bold text-zinc-900 flex items-center gap-1.5">
                          <Check size={14} className="text-emerald-600" />
                          <span>מה גרם לסיסמה להראות כפגת תוקף כל הזמן?</span>
                        </p>
                        <p>
                          בשרתי ענן (Cloud Run), מערכת הקבצים הזמנית מתאפסת בכל אתחול שרת או שינה. בעבר הסיסמה נשמרה רק בקובץ זמני, ולכן בכל הפעלה מחדש המערכת חזרה לברירת מחדל ישנה שנחסמה ע"י גוגל (קוד 535).
                          <b> כעת פתרנו זאת לצמיתות:</b> פרטי ה-Gmail נשמרים מוצפנים ישירות בבסיס הנתונים בענן (Firestore), ולכן נשמרים לעד בכל אתחול שרת ומכל מחשב!
                        </p>
                      </div>

                      <div className="space-y-1.5 p-3.5 bg-white rounded-xl border border-indigo-100/80 shadow-xs">
                        <p className="font-bold text-zinc-900 flex items-center gap-1.5">
                          <ShieldCheck size={14} className="text-indigo-600" />
                          <span>מתי גוגל מבטלת סיסמת אפליקציה?</span>
                        </p>
                        <p>
                          סיסמת אפליקציה בת 16 אותיות של Google <b>אינה</b> פגת תוקף לפי זמן קצוב. היא מתבטלת רק במקרים הבאים:
                        </p>
                        <ul className="list-disc list-inside space-y-1 pt-1 text-zinc-700">
                          <li><b>שינוי הסיסמה הראשית של חשבון ה-Google</b> (מבטל מיידית את כל סיסמאות האפליקציה).</li>
                          <li><b>שינוי או כיבוי אימות דו-שלבי (2FA)</b> בחשבון ה-Google.</li>
                          <li><b>מחיקה יזומה</b> מתוך עמוד <a href="https://myaccount.google.com/apppasswords" target="_blank" rel="noopener noreferrer" className="text-indigo-600 underline font-bold">myaccount.google.com/apppasswords</a>.</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  {/* Preferences */}
                  <div className="space-y-4 pt-4 border-t border-zinc-100">
                    <h4 className="font-bold text-base text-zinc-900 border-b border-zinc-100 pb-2">כתובת לקבלת דוחות תקופתיים</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-semibold text-zinc-700 mb-1.5">אימייל לקבלת דוחות שוטפים</label>
                        <input
                          type="email"
                          className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-left font-mono text-sm"
                          dir="ltr"
                          value={config.emailSettings?.reportEmail || ''}
                          onChange={(e) => setConfig({
                            ...config,
                            emailSettings: { ...config.emailSettings, reportEmail: e.target.value } as any
                          })}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <button
                onClick={handleSaveConfig}
                disabled={saving}
                className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {saving ? (
                  <Loader2 className="animate-spin" size={20} />
                ) : (
                  <Save size={20} />
                )}
                {saving ? 'שומר...' : 'שמור הגדרות מערכת'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Report Generation Modal */}
        <AnimatePresence>
          {showReportModal && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl space-y-6"
              >
                <div className="flex items-center justify-between border-b border-zinc-100 pb-4">
                  <h3 className="text-2xl font-bold text-zinc-900">הנפקת דוח</h3>
                  <button onClick={() => setShowReportModal(false)} className="text-zinc-400 hover:text-zinc-600">
                    <X size={24} />
                  </button>
                </div>

                <div className="space-y-4">
                  {(reportType === 'range' || reportType === 'buyers') && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-bold text-zinc-700 mb-1">מתאריך</label>
                        <input
                          type="date"
                          className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                          value={reportDateRange.start}
                          onChange={e => setReportDateRange({ ...reportDateRange, start: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-zinc-700 mb-1">עד תאריך</label>
                        <input
                          type="date"
                          className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                          value={reportDateRange.end}
                          onChange={e => setReportDateRange({ ...reportDateRange, end: e.target.value })}
                        />
                      </div>
                    </div>
                  )}

                  {reportType === 'buyers' && (
                    <div>
                      <label className="block text-sm font-bold text-zinc-700 mb-1">בחר מוצר</label>
                      <select
                        className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                        value={selectedProductId}
                        onChange={e => setSelectedProductId(e.target.value)}
                      >
                        <option value="all">כל המוצרים</option>
                        {products.map(p => (
                          <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  <p className="text-sm text-zinc-500">
                    הדוח יישלח לכתובת: <span className="font-bold text-zinc-900">{config.emailSettings?.reportEmail}</span>
                  </p>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowReportModal(false)}
                    className="flex-1 px-6 py-4 bg-zinc-100 text-zinc-600 rounded-2xl font-bold hover:bg-zinc-200 transition-all"
                  >
                    ביטול
                  </button>
                  <button
                    onClick={handleGenerateReport}
                    disabled={generatingReport}
                    className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {generatingReport ? <Loader2 className="animate-spin" size={20} /> : <Send size={20} />}
                    הנפק ושלח
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Confirmation Modal for Clearing Carts */}
        <AnimatePresence>
          {/* Add Reservation Modal */}
      {isAddingReservation && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="bg-white rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl"
          >
            <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-amber-50/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center text-amber-600">
                  <Package size={20} />
                </div>
                <h3 className="text-xl font-bold text-zinc-900">שריון מלאי חדש</h3>
              </div>
              <button
                onClick={() => setIsAddingReservation(false)}
                className="p-2 hover:bg-white rounded-full transition-colors text-zinc-400"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-bold text-zinc-700 mb-2">בחר מוצר</label>
                <select
                  className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-amber-500"
                  value={reservationForm.productId}
                  onChange={(e) => {
                    const productId = e.target.value;
                    const product = products.find(p => p.id === productId);
                    const category = categories.find(c => c.id === product?.categoryId);
                    setReservationForm({ 
                      ...reservationForm, 
                      productId,
                      productName: product?.name || '',
                      productSku: product?.sku || '',
                      productCategory: category?.name || ''
                    });
                  }}
                >
                  <option value="">בחר מוצר מהרשימה...</option>
                  {products.map(p => {
                    const category = categories.find(c => c.id === p.categoryId);
                    return (
                      <option key={p.id} value={p.id}>
                        {p.name} | מק"ט: {p.sku || '-'} | קטגוריה: {category?.name || '-'} | מלאי: {p.stockQuantity}
                      </option>
                    );
                  })}
                </select>

                {reservationForm.productId && products.find(p => p.id === reservationForm.productId)?.variants && products.find(p => p.id === reservationForm.productId)!.variants!.length > 0 && (
                  <div className="mt-4">
                    <label className="block text-sm font-bold text-zinc-700 mb-2">בחר תת-מוצר (וריאציה)</label>
                    <select
                      className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-amber-500"
                      value={reservationForm.variantId || ''}
                      onChange={(e) => {
                        const variantId = e.target.value;
                        const product = products.find(p => p.id === reservationForm.productId);
                        const variant = product?.variants?.find((v: any) => v.id === variantId);
                        setReservationForm({
                          ...reservationForm,
                          variantId,
                          variantName: variant?.name || ''
                        });
                      }}
                    >
                      <option value="">בחר תת-מוצר (רשות)...</option>
                      {products.find(p => p.id === reservationForm.productId)?.variants?.map((v: any) => (
                        <option key={v.id} value={v.id}>
                          {v.name} | מלאי: {v.stockQuantity}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {reservationForm.productId && products.find(p => p.id === reservationForm.productId)?.description && (
                  <p className="mt-2 text-xs text-zinc-500 bg-zinc-50 p-2 rounded-lg border border-zinc-100">
                    <span className="font-bold">תיאור:</span> {products.find(p => p.id === reservationForm.productId)?.description}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-bold text-zinc-700 mb-2">כמות לשריון</label>
                <input
                  type="number"
                  min="1"
                  className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-amber-500"
                  value={reservationForm.quantity}
                  onChange={(e) => setReservationForm({ ...reservationForm, quantity: parseInt(e.target.value) || 0 })}
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-zinc-700 mb-2">הערה / שם לקוח</label>
                <input
                  type="text"
                  placeholder="למי משוריין או סיבת השריון..."
                  className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-amber-500"
                  value={reservationForm.note}
                  onChange={(e) => setReservationForm({ ...reservationForm, note: e.target.value })}
                />
              </div>

              <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100 flex gap-3">
                <AlertCircle className="text-amber-600 shrink-0" size={20} />
                <p className="text-sm text-amber-800 leading-relaxed">
                  שריון מלאי יגרע את הכמות מהמלאי הזמין למכירה באתר, אך ישמור אותה במערכת תחת "כמות משוריינת".
                </p>
              </div>
            </div>

            <div className="p-6 bg-zinc-50 border-t border-zinc-100 flex gap-3">
              <button
                onClick={handleAddReservation}
                disabled={isReserving || !reservationForm.productId || reservationForm.quantity <= 0}
                className="flex-1 bg-amber-600 text-white py-4 rounded-2xl font-bold hover:bg-amber-700 transition-all shadow-lg shadow-amber-500/20 disabled:opacity-50 disabled:shadow-none flex items-center justify-center gap-2"
              >
                {isReserving ? <Loader2 className="animate-spin" size={20} /> : <Check size={20} />}
                בצע שריון מלאי
              </button>
              <button
                onClick={() => setIsAddingReservation(false)}
                className="px-8 py-4 bg-white text-zinc-600 rounded-2xl font-bold border border-zinc-200 hover:bg-zinc-50 transition-all"
              >
                ביטול
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {showConfirmClear && (
            <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => !clearingCarts && setShowConfirmClear(false)}
                className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="relative bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden"
              >
                <div className="p-8 text-center space-y-6">
                  <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto text-red-500">
                    <AlertCircle size={40} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold text-zinc-900">ריקון סלים פעילים</h3>
                    <p className="text-zinc-500">האם אתה בטוח שברצונך לרוקן את כל סלי הקניות הפעילים? פעולה זו אינה ניתנת לביטול.</p>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowConfirmClear(false)}
                      disabled={clearingCarts}
                      className="flex-1 px-6 py-4 bg-zinc-100 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-200 transition-all disabled:opacity-50"
                    >
                      ביטול
                    </button>
                    <button
                      onClick={handleClearCarts}
                      disabled={clearingCarts}
                      className="flex-1 px-6 py-4 bg-red-600 text-white rounded-2xl font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {clearingCarts ? <Loader2 className="animate-spin" size={20} /> : <Trash2 size={20} />}
                      כן, רוקן הכל
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}

          {showConfirmConvertRes && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl text-center space-y-6"
              >
                <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                  <ShoppingCart size={40} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-zinc-900">הפיכת שריון להזמנה</h3>
                  <p className="text-zinc-500">
                    האם אתה בטוח שברצונך להפוך את השריון של <span className="font-bold text-zinc-900">{showConfirmConvertRes.productName}</span> להזמנה חדשה?
                  </p>
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowConfirmConvertRes(null)}
                    className="flex-1 px-6 py-4 bg-zinc-100 text-zinc-600 rounded-2xl font-bold hover:bg-zinc-200 transition-all"
                  >
                    ביטול
                  </button>
                  <button
                    onClick={() => handleConvertToOrder(showConfirmConvertRes)}
                    className="flex-1 px-6 py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20"
                  >
                    אישור והמרה
                  </button>
                </div>
              </motion.div>
            </div>
          )}

          {showConfirmCancelRes && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl text-center space-y-6"
              >
                <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto text-red-600">
                  <AlertCircle size={40} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-zinc-900">ביטול שריון מלאי</h3>
                  <p className="text-zinc-500">
                    האם אתה בטוח שברצונך לבטל את השריון? המלאי יחזור למלאי הזמין של המוצר.
                  </p>
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowConfirmCancelRes(null)}
                    className="flex-1 px-6 py-4 bg-zinc-100 text-zinc-600 rounded-2xl font-bold hover:bg-zinc-200 transition-all"
                  >
                    חזור
                  </button>
                  <button
                    onClick={() => handleCancelReservation(showConfirmCancelRes)}
                    className="flex-1 px-6 py-4 bg-red-600 text-white rounded-2xl font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-500/20"
                  >
                    בטל שריון
                  </button>
                </div>
              </motion.div>
            </div>
          )}

          {showConfirmReconcile && (
            <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => !reconciling && setShowConfirmReconcile(false)}
                className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="relative bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden"
              >
                <div className="p-8 text-center space-y-6">
                  <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-emerald-500">
                    <RefreshCw size={40} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold text-zinc-900">בדיקת מלאים וסנכרון</h3>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowConfirmReconcile(false)}
                      disabled={reconciling}
                      className="flex-1 px-6 py-4 bg-zinc-100 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-200 transition-all disabled:opacity-50"
                    >
                      ביטול
                    </button>
                    <button
                      onClick={handleReconcileInventory}
                      disabled={reconciling}
                      className="flex-1 px-6 py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {reconciling ? <Loader2 className="animate-spin" size={20} /> : <CheckCircle2 size={20} />}
                      בצע סנכרון
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Field Edit Modal */}
        <AnimatePresence>
          {editingField && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setEditingField(null)}
                className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="relative bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden"
              >
                <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                  <h3 className="text-xl font-bold text-zinc-900">הגדרת שדה</h3>
                  <button onClick={() => setEditingField(null)} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
                </div>
                <div className="p-8 space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">תווית השדה (Label)</label>
                    <input 
                      required 
                      type="text" 
                      className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" 
                      value={fieldForm.label || ''} 
                      onChange={e => setFieldForm({...fieldForm, label: e.target.value})} 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">סוג קלט</label>
                    <select 
                      className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                      value={fieldForm.type || 'text'}
                      onChange={e => setFieldForm({...fieldForm, type: e.target.value as any})}
                    >
                      <option value="text">טקסט חופשי</option>
                      <option value="number">ספרות בלבד</option>
                      <option value="date">תאריך</option>
                      <option value="email">אימייל</option>
                      <option value="select">רשימה נפתחת</option>
                    </select>
                  </div>

                  <div className="flex gap-4">
                    <label className="flex-1 flex items-center gap-3 p-4 bg-zinc-50 rounded-2xl border border-zinc-100 cursor-pointer hover:bg-zinc-100 transition-colors">
                      <div className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer"
                          checked={fieldForm.required || false}
                          onChange={(e) => setFieldForm({ ...fieldForm, required: e.target.checked })}
                        />
                        <div className="w-11 h-6 bg-zinc-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                      </div>
                      <span className="font-bold text-zinc-700">שדה חובה</span>
                    </label>

                    <label className="flex-1 flex items-center gap-3 p-4 bg-zinc-50 rounded-2xl border border-zinc-100 cursor-pointer hover:bg-zinc-100 transition-colors">
                      <div className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer"
                          checked={fieldForm.hideInReports || false}
                          onChange={(e) => setFieldForm({ ...fieldForm, hideInReports: e.target.checked })}
                        />
                        <div className="w-11 h-6 bg-zinc-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                      </div>
                      <span className="font-bold text-zinc-700">הסתר בדוחות</span>
                    </label>
                  </div>

                  {fieldForm.type === 'select' && (
                    <div className="space-y-3">
                      <label className="block text-sm font-semibold text-zinc-700">אפשרויות ברשימה</label>
                      <div className="flex flex-wrap gap-2">
                        {fieldForm.options?.map(opt => (
                          <div key={opt} className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-lg text-sm font-bold flex items-center gap-2">
                            {opt}
                            <button onClick={() => setFieldForm({...fieldForm, options: fieldForm.options?.filter(o => o !== opt)})} className="hover:text-red-500">
                              <X size={14} />
                            </button>
                          </div>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <input 
                          type="text" 
                          placeholder="אפשרות חדשה..." 
                          className="flex-1 px-3 py-2 border border-zinc-200 rounded-lg outline-none text-sm"
                          value={newOption || ''}
                          onChange={e => setNewOption(e.target.value)}
                          onKeyPress={e => {
                            if (e.key === 'Enter') {
                              if (newOption && !fieldForm.options?.includes(newOption)) {
                                setFieldForm({...fieldForm, options: [...(fieldForm.options || []), newOption]});
                                setNewOption('');
                              }
                            }
                          }}
                        />
                        <button 
                          onClick={() => {
                            if (newOption && !fieldForm.options?.includes(newOption)) {
                              setFieldForm({...fieldForm, options: [...(fieldForm.options || []), newOption]});
                              setNewOption('');
                            }
                          }}
                          className="bg-zinc-900 text-white px-4 py-2 rounded-lg text-sm font-bold"
                        >
                          הוסף
                        </button>
                      </div>
                    </div>
                  )}

                  <button 
                    onClick={saveField}
                    className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
                  >
                    <Save size={20} />
                    שמור שדה
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Discrepancies Modal */}
        <AnimatePresence>
          {showDiscrepanciesModal && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="bg-white rounded-3xl p-8 max-w-4xl w-full shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto"
              >
                <div className="flex items-center justify-between border-b border-zinc-100 pb-4">
                  <div className="flex items-center gap-3">
                    <AlertCircle size={32} className="text-amber-500" />
                    <div>
                      <h3 className="text-2xl font-bold text-zinc-900">נמצאו אי-התאמות במלאי</h3>
                      <p className="text-zinc-500">להלן רשימת המוצרים שהמלאי שלהם אינו מסונכרן עם ההזמנות והשריונים</p>
                    </div>
                  </div>
                  <button onClick={() => setShowDiscrepanciesModal(false)} className="text-zinc-400 hover:text-zinc-600 transition-colors">
                    <X size={24} />
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-right">
                    <thead>
                      <tr className="bg-zinc-50 border-b border-zinc-100">
                        <th className="px-4 py-3 text-sm font-bold text-zinc-600">מוצר</th>
                        <th className="px-4 py-3 text-sm font-bold text-zinc-600">כללי נוכחי</th>
                        <th className="px-4 py-3 text-sm font-bold text-zinc-600">כללי צפוי</th>
                        <th className="px-4 py-3 text-sm font-bold text-zinc-600">זמין נוכחי</th>
                        <th className="px-4 py-3 text-sm font-bold text-zinc-600">זמין צפוי</th>
                        <th className="px-4 py-3 text-sm font-bold text-zinc-600">משוריין נוכחי</th>
                        <th className="px-4 py-3 text-sm font-bold text-zinc-600">משוריין צפוי</th>
                        <th className="px-4 py-3 text-sm font-bold text-zinc-600 text-left">פעולות</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-100">
                      {discrepancies.map(d => (
                        <tr key={d.id} className={`transition-colors ${d.isVariant ? 'bg-indigo-50/30 hover:bg-indigo-50/50' : 'hover:bg-zinc-50/50'}`}>
                          <td className="px-4 py-3">
                            <p className="font-bold text-zinc-900 flex items-center gap-2">
                              {d.isVariant && <span className="text-[10px] bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded">תת-מוצר</span>}
                              {d.name}
                            </p>
                            <p className="text-[10px] text-zinc-400 font-mono">{d.sku || '-'}</p>
                          </td>
                          <td className="px-4 py-3 text-zinc-600">{d.currentTotal !== undefined && d.currentTotal !== null && d.currentTotal !== '' ? d.currentTotal : '-'}</td>
                          <td className="px-4 py-3 text-emerald-600 font-bold">{d.expectedTotal}</td>
                          <td className="px-4 py-3 text-zinc-600">{d.currentStock}</td>
                          <td className="px-4 py-3 text-emerald-600 font-bold">{d.expectedStock}</td>
                          <td className="px-4 py-3 text-zinc-600">{d.isVariant ? '-' : d.currentReserved}</td>
                          <td className="px-4 py-3 text-amber-600 font-bold">{d.isVariant ? '-' : d.expectedReserved}</td>
                          <td className="px-4 py-3 text-left">
                            <div className="flex items-center gap-2 justify-end">
                              <button
                                onClick={() => handleApproveDiscrepancy(d)}
                                disabled={fixingDiscrepancy === d.id}
                                className="px-3 py-1.5 bg-blue-50 text-blue-600 rounded-lg text-xs font-bold hover:bg-blue-100 transition-all flex items-center gap-1 disabled:opacity-50"
                                title="אשר - מסכים שהמלאי הנוכחי נכון, ויעדכן את המלאי הכללי"
                              >
                                {fixingDiscrepancy === d.id ? <Loader2 className="animate-spin" size={14} /> : <Check size={14} />}
                                אשר
                              </button>
                              <button
                                onClick={() => handleFixDiscrepancy(d)}
                                disabled={fixingDiscrepancy === d.id}
                                className="px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-xs font-bold hover:bg-indigo-100 transition-all flex items-center gap-1 disabled:opacity-50"
                                title="תקן - יעדכן את המלאי הנוכחי לפי המלאי הכללי"
                              >
                                {fixingDiscrepancy === d.id ? <Loader2 className="animate-spin" size={14} /> : <Check size={14} />}
                                תקן
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="flex gap-3 pt-6 border-t border-zinc-100 flex-wrap">
                  <button
                    onClick={() => setShowDiscrepanciesModal(false)}
                    className="px-6 py-4 bg-zinc-100 text-zinc-600 rounded-2xl font-bold hover:bg-zinc-200 transition-all"
                  >
                    סגור
                  </button>
                  <button
                    onClick={() => {
                      const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + 
                        "מק״ט,שם מוצר,מלאי נוכחי,מלאי צפוי,משוריין נוכחי,משוריין צפוי\n" +
                        discrepancies.map(d => 
                          `${d.sku || ''},"${d.name}",${d.currentStock},${d.expectedStock},${d.isVariant ? '-' : d.currentReserved},${d.isVariant ? '-' : d.expectedReserved}`
                        ).join("\n");
                      const encodedUri = encodeURI(csvContent);
                      const link = document.createElement("a");
                      link.setAttribute("href", encodedUri);
                      link.setAttribute("download", `דוח_פערי_מלאי_${new Date().toLocaleDateString('he-IL').replace(/\./g, '-')}.csv`);
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                    }}
                    className="flex-1 px-6 py-4 bg-indigo-50 text-indigo-600 border border-indigo-200 rounded-2xl font-bold hover:bg-indigo-100 transition-all flex items-center justify-center gap-2"
                  >
                    <FileDown size={20} />
                    הורד כקובץ Excel
                  </button>
                  <button
                    onClick={handleApproveAllDiscrepancies}
                    className="flex-1 px-6 py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2"
                    title="מעדכן את כל המלאים הכלליים כך שיתאימו למלאי הנוכחי בשטח"
                  >
                    <CheckCircle2 size={20} />
                    אשר את כל הנוכחי
                  </button>
                  <button
                    onClick={handleFixAllDiscrepancies}
                    className="flex-1 px-6 py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2"
                    title="מעדכן את כל המלאים הנוכחיים כך שיתאימו למלאי הכללי המוגדר"
                  >
                    <CheckCircle2 size={20} />
                    תקן את כל המוצרים
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Debug Info - Only visible for admins or in dev */}
        <div className="mt-12 p-6 bg-zinc-100 rounded-2xl border border-zinc-200 opacity-50 hover:opacity-100 transition-opacity">
          <h3 className="text-sm font-bold text-zinc-500 mb-4 flex items-center gap-2">
            <Shield size={16} />
            מידע דיאגנוסטי (מנהל מערכת)
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono text-zinc-600">
            <div className="space-y-1">
              <p>Project ID: {firebaseConfig.projectId}</p>
              <p>Storage Bucket: {firebaseConfig.storageBucket}</p>
              <p>Database ID: {firebaseConfig.firestoreDatabaseId}</p>
            </div>
            <div className="space-y-1">
              <p>User UID: {auth.currentUser?.uid || 'Not Logged In'}</p>
              <p>User Email: {auth.currentUser?.email || 'N/A'}</p>
              <p>Is Admin: {isAdmin ? 'Yes' : 'No'}</p>
            </div>
          </div>
        </div>
      </div>
    );
}
