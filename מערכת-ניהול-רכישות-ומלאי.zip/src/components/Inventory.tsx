import React, { useState, useEffect } from 'react';
import { db, collection, query, addDoc, updateDoc, deleteDoc, doc, handleFirestoreError, OperationType, storage, ref, uploadBytes, getDownloadURL, writeBatch, getDocs, getDoc, limit, where, onSnapshot } from '../firebase';
import { Package, Plus, Trash2, Edit2, Image as ImageIcon, Search, ChevronRight, LayoutGrid, List, Save, X, Upload, Loader2, FileUp, FileDown, ChevronUp, ChevronDown, RefreshCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';
import * as XLSX from 'xlsx';
import { dataCache, CACHE_DURATION } from '../lib/cache';

interface Category {
  id: string;
  name: string;
  description?: string;
  order?: number;
}

interface SubCategory {
  id: string;
  categoryId: string;
  name: string;
  isMandatoryForParent?: boolean;
  startTime?: string;
  endTime?: string;
  duration?: string;
  googleMapsUrl?: string;
  order?: number;
}

interface Product {
  id: string;
  sku: string;
  name: string;
  description?: string;
  image?: string;
  price: number;
  categoryId: string;
  subCategoryId: string;
  stockQuantity: number;
  totalStock: number;
  reservedQuantity?: number;
  startTime?: string;
  endTime?: string;
  duration?: string;
  hideLowStockAlert?: boolean;
  variants?: any[];
}

export function Inventory({ pendingEditId, onEditHandled }: { pendingEditId?: string | null, onEditHandled?: () => void }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [subCategories, setSubCategories] = useState<SubCategory[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [config, setConfig] = useState<any>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [isAddingSubCategory, setIsAddingSubCategory] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editingSubCategory, setEditingSubCategory] = useState<SubCategory | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [uploading, setUploading] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importMode, setImportMode] = useState<'add' | 'replace'>('add');
  const [importProgress, setImportProgress] = useState(0);
  const [importTotal, setImportTotal] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isBatchImageUpload, setIsBatchImageUpload] = useState(false);
  const [batchUploadProgress, setBatchUploadProgress] = useState(0);
  const [batchUploadTotal, setBatchUploadTotal] = useState(0);
  const [batchUploadResults, setBatchUploadResults] = useState<{success: number, failed: number, skipped: number}>({success: 0, failed: 0, skipped: 0});

  // Form states
  const [productForm, setProductForm] = useState<Partial<Product>>({
    sku: '', name: '', description: '', image: '', price: 0, categoryId: '', subCategoryId: '', stockQuantity: 0, totalStock: 0,
    startTime: '', endTime: '', duration: '', hideLowStockAlert: false, variants: []
  });
  
  const addVariant = () => {
    setProductForm({
      ...productForm,
      variants: [...(productForm.variants || []), { id: Date.now().toString(), name: '', stockQuantity: 0, totalStock: 0, price: 0 }]
    });
  };
  
  const updateVariant = (index: number, field: string, value: any) => {
    const newVariants = [...(productForm.variants || [])];
    newVariants[index] = { ...newVariants[index], [field]: value };
    setProductForm({ ...productForm, variants: newVariants });
  };
  
  const removeVariant = (index: number) => {
    const newVariants = [...(productForm.variants || [])];
    newVariants.splice(index, 1);
    setProductForm({ ...productForm, variants: newVariants });
  };
  const [categoryForm, setCategoryForm] = useState({ name: '', description: '' });
  const [subCategoryForm, setSubCategoryForm] = useState({ 
    categoryId: '', 
    name: '',
    isMandatoryForParent: false,
    startTime: '',
    endTime: '',
    duration: '',
    googleMapsUrl: ''
  });

  useEffect(() => {
    const unsubCategories = onSnapshot(query(collection(db, 'categories'), limit(100)), (snap) => {
      const cats = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Category));
      const sortedCats = cats.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
      setCategories(sortedCats);
      dataCache.categories = sortedCats;
    }, (err) => {
      console.error('Error listening to categories:', err);
    });
    
    const unsubSubCategories = onSnapshot(query(collection(db, 'subCategories'), limit(100)), (snap) => {
      const subs = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as SubCategory));
      const sortedSubs = subs.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
      setSubCategories(sortedSubs);
      dataCache.subCategories = sortedSubs;
    }, (err) => {
      console.error('Error listening to subcategories:', err);
    });

    const unsubConfig = onSnapshot(doc(db, 'config', 'system'), (docSnap) => {
      if (docSnap.exists()) {
        const conf = docSnap.data();
        setConfig(conf);
        dataCache.config = conf;
      }
    }, (err) => {
      console.error('Error listening to config:', err);
    });

    return () => {
      unsubCategories();
      unsubSubCategories();
      unsubConfig();
    };
  }, []);

  const [refreshKey, setRefreshKey] = useState(0);
  const [visibleCount, setVisibleCount] = useState(20);

  useEffect(() => {
    setVisibleCount(20);
  }, [searchTerm, selectedCategory]);

  // Listen for products for real-time inventory updates
  useEffect(() => {
    const q = query(collection(db, 'products'), limit(2000));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const prods = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) } as Product));
      setProducts(prods);
      
      // Update cache for other components
      dataCache.products['all'] = { data: prods, timestamp: Date.now() };
    }, (err) => {
      console.error('Error listening to inventory products:', err);
    });

    return () => unsubscribe();
  }, [refreshKey]);

  useEffect(() => {
    if (pendingEditId && products.length > 0) {
      const product = products.find(p => p.id === pendingEditId);
      if (product) {
        setEditingProduct(product);
        setProductForm({ ...product });
        setIsAddingProduct(true);
        if (onEditHandled) onEditHandled();
      }
    }
  }, [pendingEditId, products, onEditHandled]);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleBatchImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsProcessing(true);
    setBatchUploadTotal(files.length);
    setBatchUploadProgress(0);
    setBatchUploadResults({success: 0, failed: 0, skipped: 0});

    const results = {success: 0, failed: 0, skipped: 0};

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];

        if (!file.type.startsWith('image/')) {
          results.failed++;
          setBatchUploadProgress(i + 1);
          continue;
        }

        const fileName = file.name.substring(0, file.name.lastIndexOf('.'));
        const product = products.find(p => p.sku.trim().toLowerCase() === fileName.trim().toLowerCase());

        if (!product) {
          results.skipped++;
          setBatchUploadProgress(i + 1);
          continue;
        }

        try {
          let url = '';
          try {
            const storageRef = ref(storage, `products/${Date.now()}_${file.name}`);
            console.log(`Attempting to upload product image to: ${storageRef.fullPath}`);
            
            // Add a timeout to the upload to prevent infinite loading
            const uploadPromise = uploadBytes(storageRef, file);
            const timeoutPromise = new Promise((_, reject) => 
              setTimeout(() => reject(new Error('Storage upload timed out')), 10000)
            );
            
            const snapshot = await Promise.race([uploadPromise, timeoutPromise]) as any;
            url = await getDownloadURL(snapshot.ref);
            console.log(`Product image uploaded successfully to Storage, URL: ${url}`);
          } catch (storageErr: any) {
            console.warn(`Storage upload failed or timed out for SKU ${fileName}, falling back to Base64:`, storageErr);
            const base64 = await fileToBase64(file);
            if (base64.length > 800 * 1024) {
              throw new Error('File too large for Base64');
            }
            url = base64;
          }
          
          await updateDoc(doc(db, 'products', product.id), { image: url });
          results.success++;
        } catch (err: any) {
          console.error(`Error uploading image for SKU ${fileName}:`, err);
          results.failed++;
        }
        
        setBatchUploadProgress(i + 1);
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    } finally {
      setBatchUploadResults(results);
      setIsProcessing(false);
      toast.success(`הסתיים: ${results.success} הצליחו, ${results.skipped} לא נמצאו מוצרים תואמים, ${results.failed} נכשלו`);
      if (e.target) e.target.value = '';
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('אנא בחר קובץ תמונה תקין');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error('הקובץ גדול מדי. אנא העלה תמונה קטנה מ-5MB');
      return;
    }

    setUploading(true);
    try {
      let url = '';
      try {
        const storageRef = ref(storage, `products/${Date.now()}_${file.name}`);
        console.log('Attempting to upload product image to:', storageRef.fullPath);
        
        // Add a timeout to the upload to prevent infinite loading
        const uploadPromise = uploadBytes(storageRef, file);
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Storage upload timed out')), 10000)
        );
        
        const snapshot = await Promise.race([uploadPromise, timeoutPromise]) as any;
        url = await getDownloadURL(snapshot.ref);
        console.log('Product image uploaded successfully to Storage, URL:', url);
      } catch (storageErr: any) {
        console.warn('Storage upload failed or timed out, falling back to Base64:', storageErr);
        const base64 = await fileToBase64(file);
        if (base64.length > 800 * 1024) {
          throw new Error('התמונה גדולה מדי לשמירה ללא אחסון ענן. אנא הקטן את התמונה.');
        }
        url = base64;
      }
      
      setProductForm(prev => ({ ...prev, image: url }));
      toast.success('התמונה הועלתה בהצלחה');
    } catch (err: any) {
      const errorMsg = err.code ? `[${err.code}] ${err.message}` : err.message || 'שגיאה לא ידועה';
      toast.error(`שגיאה בהעלאת התמונה: ${errorMsg}`);
      console.error('Product image upload error:', err);
    } finally {
      setUploading(false);
    }
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving) return;
    setIsSaving(true);
    try {
      const { id, ...data } = productForm as any;
      if (data.variants && Array.isArray(data.variants)) {
        data.variants = data.variants.map((v: any) => ({
          ...v,
          price: Number(v.price) || 0,
          stockQuantity: Number(v.stockQuantity) || 0,
          totalStock: Number(v.totalStock) || 0
        }));
      }
      if (editingProduct) {
        await updateDoc(doc(db, 'products', editingProduct.id), data);
        toast.success('המוצר עודכן בהצלחה');
      } else {
        await addDoc(collection(db, 'products'), data);
        toast.success('המוצר נוסף בהצלחה');
      }
      setIsAddingProduct(false);
      setEditingProduct(null);
      setProductForm({ 
        sku: '', name: '', description: '', image: '', price: 0, categoryId: '', subCategoryId: '', stockQuantity: 0, totalStock: 0,
        startTime: '', endTime: '', duration: '', hideLowStockAlert: false
      });
      dataCache.products = {};
      setRefreshKey(prev => prev + 1);
    } catch (err) {
      toast.error('שגיאה בשמירת המוצר');
      handleFirestoreError(err, editingProduct ? OperationType.UPDATE : OperationType.CREATE, 'products');
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving) return;
    setIsSaving(true);
    try {
      if (editingCategory) {
        await updateDoc(doc(db, 'categories', editingCategory.id), categoryForm);
        toast.success('הקטגוריה עודכנה בהצלחה');
      } else {
        const order = categories.length;
        await addDoc(collection(db, 'categories'), { ...categoryForm, order });
        toast.success('הקטגוריה נוספה בהצלחה');
      }
      setIsAddingCategory(false);
      setEditingCategory(null);
      setCategoryForm({ name: '', description: '' });
      dataCache.categories = null;
      setRefreshKey(prev => prev + 1);
    } catch (err) {
      toast.error('שגיאה בשמירת הקטגוריה');
      handleFirestoreError(err, editingCategory ? OperationType.UPDATE : OperationType.CREATE, 'categories');
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddSubCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subCategoryForm.categoryId) {
      toast.error('יש לבחור קטגוריית אב');
      return;
    }
    if (!subCategoryForm.name) {
      toast.error('יש להזין שם לתת-הקטגוריה');
      return;
    }
    if (isSaving) return;
    setIsSaving(true);
    try {
      if (editingSubCategory) {
        await updateDoc(doc(db, 'subCategories', editingSubCategory.id), subCategoryForm);
        toast.success('תת-הקטגוריה עודכנה בהצלחה');
      } else {
        const order = subCategories.filter(s => s.categoryId === subCategoryForm.categoryId).length;
        await addDoc(collection(db, 'subCategories'), { ...subCategoryForm, order });
        toast.success('תת-הקטגוריה נוספה בהצלחה');
      }
      setIsAddingSubCategory(false);
      setEditingSubCategory(null);
      setSubCategoryForm({ 
        categoryId: '', 
        name: '',
        isMandatoryForParent: false,
        startTime: '',
        endTime: '',
        duration: '',
        googleMapsUrl: ''
      });
      dataCache.subCategories = null;
      setRefreshKey(prev => prev + 1);
    } catch (err) {
      toast.error('שגיאה בשמירת תת-הקטגוריה');
      handleFirestoreError(err, editingSubCategory ? OperationType.UPDATE : OperationType.CREATE, 'subCategories');
    } finally {
      setIsSaving(false);
    }
  };

  const moveCategory = async (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= categories.length) return;

    const newCategories = [...categories];
    [newCategories[index], newCategories[targetIndex]] = [newCategories[targetIndex], newCategories[index]];

    try {
      const batch = writeBatch(db);
      newCategories.forEach((cat, i) => {
        batch.update(doc(db, 'categories', cat.id), { order: i });
      });
      await batch.commit();
      toast.success('סדר הקטגוריות עודכן');
    } catch (err) {
      console.error('Error moving category:', err);
      toast.error('שגיאה בשינוי סדר הקטגוריות');
    }
  };

  const moveSubCategory = async (catId: string, index: number, direction: 'up' | 'down') => {
    const catSubs = subCategories.filter(s => s.categoryId === catId);
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= catSubs.length) return;

    const newSubs = [...catSubs];
    [newSubs[index], newSubs[targetIndex]] = [newSubs[targetIndex], newSubs[index]];

    try {
      const batch = writeBatch(db);
      newSubs.forEach((sub, i) => {
        batch.update(doc(db, 'subCategories', sub.id), { order: i });
      });
      await batch.commit();
      toast.success('סדר תת-הקטגוריות עודכן');
    } catch (err) {
      console.error('Error moving sub-category:', err);
      toast.error('שגיאה בשינוי סדר תת-הקטגוריות');
    }
  };

  const deleteProduct = async (id: string) => {
    if (!confirm('האם אתה בטוח שברצונך למחוק מוצר זה?')) return;
    try {
      await deleteDoc(doc(db, 'products', id));
      toast.success('המוצר נמחק בהצלחה');
      dataCache.products = {};
      setRefreshKey(prev => prev + 1);
    } catch (err) {
      toast.error('שגיאה במחיקת המוצר');
      handleFirestoreError(err, OperationType.DELETE, 'products');
    }
  };

  const downloadTemplate = () => {
    const baseHeaders = ['מק"ט', 'שם מוצר', 'תיאור', 'מחיר', 'מלאי נוכחי', 'מלאי כללי', 'שם קטגוריה', 'שם תת-קטגוריה', 'שעת התחלה', 'שעת סיום', 'משך זמן'];
    for (let i = 1; i <= 10; i++) {
      baseHeaders.push(`תת מוצר ${i} - שם`);
      baseHeaders.push(`תת מוצר ${i} - מחיר`);
      baseHeaders.push(`תת מוצר ${i} - מלאי נוכחי`);
      baseHeaders.push(`תת מוצר ${i} - מלאי כללי`);
    }
    const headers = [baseHeaders];
    const ws = XLSX.utils.aoa_to_sheet(headers);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Products Template');

    const subHeaders = [['שם קטגוריה', 'שם תת-קטגוריה', 'שעת התחלה', 'שעת סיום', 'משך זמן', 'קישור גוגל מאפס']];
    const subWs = XLSX.utils.aoa_to_sheet(subHeaders);
    XLSX.utils.book_append_sheet(wb, subWs, 'SubCategories Template');

    XLSX.writeFile(wb, 'import_templates.xlsx');
  };

  const handleImportSubCategories = async (data: any[]) => {
    let count = 0;
    const chunks = [];
    for (let i = 0; i < data.length; i += 500) {
      chunks.push(data.slice(i, i + 500));
    }

    for (const chunk of chunks) {
      const batch = writeBatch(db);
      for (const row of chunk) {
        const categoryName = row['שם קטגוריה'];
        const subCategoryName = row['שם תת-קטגוריה'];
        
        let categoryId = categories.find(c => c.name === categoryName)?.id || '';
        if (!categoryId || !subCategoryName) continue;

        const subData = {
          categoryId,
          name: String(subCategoryName),
          startTime: String(row['שעת התחלה'] || ''),
          endTime: String(row['שעת סיום'] || ''),
          duration: String(row['משך זמן'] || ''),
          googleMapsUrl: String(row['קישור גוגל מאפס'] || ''),
          isMandatoryForParent: row['חובה'] === 'כן' || row['isMandatory'] === true
        };

        const existing = subCategories.find(s => s.name === subCategoryName && s.categoryId === categoryId);
        if (existing) {
          batch.update(doc(db, 'subCategories', existing.id), subData);
        } else {
          const newRef = doc(collection(db, 'subCategories'));
          batch.set(newRef, subData);
        }
        count++;
      }
      await batch.commit();
    }

    if (count > 0) {
      toast.success(`${count} תתי-קטגוריות יובאו בהצלחה`);
    }
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setImportProgress(0);
    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const dataBuffer = evt.target?.result;
        const wb = XLSX.read(dataBuffer, { type: 'array' });
        
        // Check for SubCategories sheet first
        if (wb.SheetNames.includes('SubCategories Template')) {
          const subWs = wb.Sheets['SubCategories Template'];
          const subData = XLSX.utils.sheet_to_json(subWs) as any[];
          if (subData.length > 0) {
            await handleImportSubCategories(subData);
          }
        }

        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const rawData = XLSX.utils.sheet_to_json(ws) as any[];

        if (rawData.length === 0) {
          if (!wb.SheetNames.includes('SubCategories Template')) {
            toast.error('הקובץ ריק או שאינו מכיל נתונים בגיליון הראשון');
          }
          setIsProcessing(false);
          return;
        }

        // Normalize keys (trim spaces)
        const data = rawData.map(row => {
          const newRow: any = {};
          Object.keys(row).forEach(key => {
            newRow[key.trim()] = row[key];
          });
          return newRow;
        });

        // Check for mandatory headers in the first row
        const mandatoryHeaders = ['מק"ט', 'שם מוצר', 'מחיר', 'מלאי כללי', 'מלאי נוכחי', 'שם קטגוריה', 'שם תת-קטגוריה'];
        const firstRow = data[0];
        const missingHeaders = mandatoryHeaders.filter(h => !(h in firstRow));

        if (missingHeaders.length > 0) {
          toast.error(`חסרות עמודות חובה בקובץ: ${missingHeaders.join(', ')}. אנא השתמש בתבנית הייבוא.`);
          setIsProcessing(false);
          return;
        }

        setImportTotal(data.length);
        
        // Handle deletion if in replace mode
        if (importMode === 'replace') {
          const snapshot = await getDocs(collection(db, 'products'));
          const chunks = [];
          for (let i = 0; i < snapshot.docs.length; i += 500) {
            chunks.push(snapshot.docs.slice(i, i + 500));
          }
          for (const chunk of chunks) {
            const deleteBatch = writeBatch(db);
            chunk.forEach(doc => deleteBatch.delete(doc.ref));
            await deleteBatch.commit();
          }
        }

        // Keep track of newly created categories/subcategories to avoid duplicates within the same import
        const tempCategories = [...categories];
        const tempSubCategories = [...subCategories];
        let importedCount = 0;
        let skippedCount = 0;
        let skipReasons: string[] = [];

        // Process in chunks of 500 for Firestore batch limits
        const dataChunks = [];
        for (let i = 0; i < data.length; i += 500) {
          dataChunks.push(data.slice(i, i + 500));
        }

        let currentProgress = 0;
        for (const chunk of dataChunks) {
          const batch = writeBatch(db);
          
          for (const row of chunk) {
            currentProgress++;
            if (currentProgress === 1) console.log('First row keys:', Object.keys(row));
            const sku = row['מק"ט'];
            const productName = row['שם מוצר'];
            const price = row['מחיר'];
            const totalStock = row['מלאי כללי'];
            const currentStock = row['מלאי נוכחי'];
            const categoryName = row['שם קטגוריה'];
            const subCategoryName = row['שם תת-קטגוריה'];
            
            // Skip empty rows or rows missing mandatory fields
            const missingFields = [];
            if (!sku) missingFields.push('מק"ט');
            if (!productName) missingFields.push('שם מוצר');
            if (price === undefined) missingFields.push('מחיר');
            if (totalStock === undefined) missingFields.push('מלאי כללי');
            if (currentStock === undefined) missingFields.push('מלאי נוכחי');
            if (!categoryName) missingFields.push('שם קטגוריה');
            if (!subCategoryName) missingFields.push('שם תת-קטגוריה');

            if (missingFields.length > 0) {
              skippedCount++;
              if (skipReasons.length < 3) {
                skipReasons.push(`שורה ${currentProgress}: חסר ${missingFields.join(', ')}`);
              }
              continue;
            }

            let categoryId = tempCategories.find(c => c.name === categoryName)?.id || '';
            
            // Auto-create category if missing
            if (!categoryId) {
              const catRef = doc(collection(db, 'categories'));
              const newCat = { name: categoryName, description: 'נוצר אוטומטית מייבוא' };
              batch.set(catRef, newCat);
              categoryId = catRef.id;
              tempCategories.push({ id: categoryId, ...newCat });
            }

            let subCategoryId = '';
            if (subCategoryName) {
              subCategoryId = tempSubCategories.find(s => s.name === subCategoryName && s.categoryId === categoryId)?.id || '';
              
              // Auto-create subcategory if missing
              if (!subCategoryId) {
                const subRef = doc(collection(db, 'subCategories'));
                const googleMapsUrl = String(row['קישור גוגל מאפס'] || '');
                console.log(`Creating subcategory ${subCategoryName} with URL: ${googleMapsUrl}`);
                const newSub = { 
                  categoryId, 
                  name: subCategoryName,
                  startTime: String(row['שעת התחלה'] || ''),
                  endTime: String(row['שעת סיום'] || ''),
                  duration: String(row['משך זמן'] || ''),
                  googleMapsUrl,
                  isMandatoryForParent: row['חובה'] === 'כן' || row['isMandatory'] === true
                };
                batch.set(subRef, newSub);
                subCategoryId = subRef.id;
                tempSubCategories.push({ id: subCategoryId, ...newSub });
              }
            }

            const parsedVariants: any[] = [];
            
            // Backwards compatibility for old format
            const variantsRaw = String(row['תת מוצרים'] || row['תת מוצרים (פורמט: שם:מחיר:מלאי;שם2:מחיר:מלאי)'] || '');
            if (variantsRaw) {
              const parts = variantsRaw.split(';');
              parts.forEach((p, idx) => {
                const [vName, vPrice, vStock] = p.split(':');
                if (vName && vName.trim() !== '') {
                  parsedVariants.push({
                    id: Date.now().toString() + Math.random().toString(36).substr(2, 5) + idx,
                    name: vName.trim(),
                    price: vPrice ? Number(vPrice) : 0,
                    stockQuantity: vStock ? Number(vStock) : 0
                  });
                }
              });
            }

            // New format (10 columns)
            for (let i = 1; i <= 10; i++) {
              const vName = row[`תת מוצר ${i} - שם`];
              const vPrice = row[`תת מוצר ${i} - מחיר`];
              const vStock = row[`תת מוצר ${i} - מלאי`] || row[`תת מוצר ${i} - מלאי נוכחי`];
              const vTotalStock = row[`תת מוצר ${i} - מלאי כללי`];
              
              if (vName) {
                parsedVariants.push({
                  id: Date.now().toString() + Math.random().toString(36).substr(2, 5) + 'c' + i,
                  name: String(vName).trim(),
                  price: vPrice !== undefined ? Number(vPrice) : 0,
                  stockQuantity: vStock !== undefined ? Number(vStock) : 0,
                  totalStock: vTotalStock !== undefined ? Number(vTotalStock) : (vStock !== undefined ? Number(vStock) : 0)
                });
              }
            }

            const productData = {
              sku: String(sku),
              name: String(productName),
              description: String(row['תיאור'] || ''),
              price: Number(price),
              stockQuantity: Number(currentStock),
              totalStock: Number(totalStock),
              categoryId,
              subCategoryId,
              image: String(row['תמונה'] || row['image'] || ''),
              startTime: String(row['שעת התחלה'] || ''),
              endTime: String(row['שעת סיום'] || ''),
              duration: String(row['משך זמן'] || ''),
              variants: parsedVariants
            };

            const newDocRef = doc(collection(db, 'products'));
            batch.set(newDocRef, productData);
            importedCount++;
            setImportProgress(currentProgress);
          }
          
          await batch.commit();
        }

        if (importedCount === 0) {
          toast.error(`לא יובאו מוצרים. ${skippedCount} שורות דולגו עקב נתונים חסרים.\nדוגמאות:\n${skipReasons.join('\n')}`);
          setIsProcessing(false);
          e.target.value = '';
          return;
        }

        // Reset filters to show all products after successful import
        setSelectedCategory('all');
        setSearchTerm('');

        if (skippedCount > 0) {
          toast.success(`יובאו ${importedCount} מוצרים. ${skippedCount} שורות דולגו עקב חוסר בנתונים. המסננים אופסו כדי להציג את כל המוצרים.`);
        } else {
          toast.success(`יובאו ${importedCount} מוצרים בהצלחה. המסננים אופסו כדי להציג את כל המוצרים.`);
        }
        setIsImporting(false);
      } catch (err) {
        console.error('Import error details:', err);
        toast.error('שגיאה בתהליך הייבוא. וודא שהקובץ אינו פתוח בתוכנה אחרת ושהפורמט תקין. בדוק את חיבור האינטרנט שלך.');
      } finally {
        setIsProcessing(false);
        e.target.value = '';
      }
    };
    reader.onerror = (err) => {
      console.error('FileReader error:', err);
      toast.error('שגיאה בקריאת הקובץ');
      setIsProcessing(false);
    };
    reader.readAsArrayBuffer(file);
  };

  const getStockColor = (qty: number) => {
    if (qty < 20) return 'text-red-500';
    if (qty <= 50) return 'text-orange-500';
    return 'text-emerald-500';
  };

  const getStockBg = (qty: number) => {
    if (qty < 20) return 'bg-red-500';
    if (qty <= 50) return 'bg-orange-500';
    return 'bg-emerald-500';
  };


  const clearCache = () => {
    dataCache.categories = null;
    dataCache.subCategories = null;
    dataCache.config = null;
    dataCache.products = {};
    dataCache.lastFetch = 0;
    setRefreshKey(prev => prev + 1);
    toast.success('הזיכרון המטמון נוקה');
  };

  const filteredProducts = products.filter(p => 
    (selectedCategory === 'all' || p.categoryId === selectedCategory) &&
    (p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.sku.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="p-6 max-w-7xl mx-auto font-sans text-right" dir="rtl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
            <Package size={24} />
          </div>
          <div>
            <h2 className="text-3xl font-bold text-zinc-900 tracking-tight">ניהול מלאי ומוצרים</h2>
            <p className="text-zinc-500 mt-1">נהל את הקטלוג שלך, עדכן מלאים והוסף מוצרים חדשים</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={clearCache}
              className="p-2 text-zinc-400 hover:text-indigo-600 transition-colors"
              title="נקה זיכרון מטמון"
            >
              <RefreshCcw size={18} />
            </button>
          </div>
        </div>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => {
              const cacheKey = searchTerm ? `inv_search_${searchTerm}` : `inv_cat_${selectedCategory}`;
              if (dataCache.products[cacheKey]) dataCache.products[cacheKey].timestamp = 0;
              setRefreshKey(prev => prev + 1);
              toast.success('מרענן נתונים...');
            }}
            className="bg-zinc-100 text-zinc-400 p-2.5 rounded-xl hover:bg-zinc-200 transition-all border border-zinc-200"
            title="רענן מוצרים"
          >
            <RefreshCcw size={18} />
          </button>
          <button
            onClick={downloadTemplate}
            className="bg-zinc-100 text-zinc-900 px-5 py-2.5 rounded-xl font-medium hover:bg-zinc-200 transition-all flex items-center gap-2 border border-zinc-200"
          >
            <FileDown size={18} />
            תבנית ייבוא
          </button>
          <button
            onClick={() => setIsBatchImageUpload(true)}
            className="bg-zinc-100 text-zinc-900 px-5 py-2.5 rounded-xl font-medium hover:bg-zinc-200 transition-all flex items-center gap-2 border border-zinc-200"
          >
            <ImageIcon size={18} />
            העלאת תמונות לפי מק"ט
          </button>
          <button
            onClick={() => setIsImporting(true)}
            className="bg-zinc-100 text-zinc-900 px-5 py-2.5 rounded-xl font-medium hover:bg-zinc-200 transition-all flex items-center gap-2 border border-zinc-200"
          >
            <FileUp size={18} />
            ייבוא מוצרים
          </button>
          <button
            onClick={() => setIsAddingCategory(true)}
            className="bg-zinc-100 text-zinc-900 px-5 py-2.5 rounded-xl font-medium hover:bg-zinc-200 transition-all flex items-center gap-2 border border-zinc-200"
          >
            <LayoutGrid size={18} />
            קטגוריה
          </button>
          <button
            onClick={() => setIsAddingSubCategory(true)}
            className="bg-zinc-100 text-zinc-900 px-5 py-2.5 rounded-xl font-medium hover:bg-zinc-200 transition-all flex items-center gap-2 border border-zinc-200"
          >
            <List size={18} />
            תת-קטגוריה
          </button>
          <button
            onClick={() => setIsAddingProduct(true)}
            className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-indigo-700 transition-all flex items-center gap-2 shadow-lg shadow-indigo-500/20"
          >
            <Plus size={18} />
            מוצר חדש
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
          <input
            type="text"
            placeholder='חיפוש לפי שם או מק"ט...'
            className="w-full pr-10 pl-4 py-3 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
            value={searchTerm || ''}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <select
          className="w-full px-4 py-3 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all appearance-none"
          value={selectedCategory || 'all'}
          onChange={(e) => setSelectedCategory(e.target.value)}
        >
          <option value="all">כל הקטגוריות</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      {/* Categories & Sub-categories Management Section */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-6">
          <LayoutGrid size={24} className="text-indigo-600" />
          <h3 className="text-xl font-bold text-zinc-900">ניהול קטגוריות ותתי-קטגוריות</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.length === 0 && (
            <div className="col-span-full p-12 bg-zinc-50 rounded-3xl border-2 border-dashed border-zinc-200 text-center">
              <p className="text-zinc-500">טרם נוצרו קטגוריות. לחץ על כפתור "קטגוריה" למעלה כדי להתחיל.</p>
            </div>
          )}
          {categories.map((cat, index) => (
            <div key={cat.id} className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm space-y-4">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="flex flex-col gap-1">
                    <button 
                      onClick={() => moveCategory(index, 'up')}
                      disabled={index === 0}
                      className="p-1 text-zinc-400 hover:text-indigo-600 disabled:opacity-20 transition-all"
                    >
                      <ChevronUp size={14} />
                    </button>
                    <button 
                      onClick={() => moveCategory(index, 'down')}
                      disabled={index === categories.length - 1}
                      className="p-1 text-zinc-400 hover:text-indigo-600 disabled:opacity-20 transition-all"
                    >
                      <ChevronDown size={14} />
                    </button>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-zinc-900 text-lg">{cat.name}</h4>
                    </div>
                    <p className="text-xs text-zinc-400">{cat.description || 'אין תיאור'}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button 
                    onClick={() => { 
                      setEditingCategory(cat); 
                      setCategoryForm({ 
                        name: cat.name, 
                        description: cat.description || ''
                      }); 
                      setIsAddingCategory(true); 
                    }}
                    className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                  >
                    <Edit2 size={16} />
                  </button>
                  <button 
                    onClick={async () => {
                      if (confirm('האם אתה בטוח שברצונך למחוק קטגוריה זו? כל המוצרים תחתיה יימחקו גם הם.')) {
                        try {
                          const batch = writeBatch(db);
                          
                          // Delete all products in this category
                          const productsInCat = products.filter(p => p.categoryId === cat.id);
                          productsInCat.forEach(p => batch.delete(doc(db, 'products', p.id)));
                          
                          // Delete all subcategories in this category
                          const subsInCat = subCategories.filter(s => s.categoryId === cat.id);
                          subsInCat.forEach(s => batch.delete(doc(db, 'subCategories', s.id)));
                          
                          // Delete the category itself
                          batch.delete(doc(db, 'categories', cat.id));
                          
                          await batch.commit();
                          toast.success('הקטגוריה וכל המוצרים תחתיה נמחקו בהצלחה');
                          dataCache.categories = null;
                          dataCache.products = {};
                          setRefreshKey(prev => prev + 1);
                        } catch (err) {
                          toast.error('שגיאה במחיקה');
                        }
                      }
                    }}
                    className="p-2 text-zinc-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              
              <div className="space-y-2">
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">תתי-קטגוריות</p>
                <div className="space-y-1">
                  {subCategories.filter(s => s.categoryId === cat.id).map((sub, sIndex, filteredSubs) => (
                    <div key={sub.id} className="flex justify-between items-center bg-zinc-50 px-3 py-2 rounded-xl border border-zinc-100 group">
                      <div className="flex items-center gap-2">
                        <div className="flex flex-col opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => moveSubCategory(cat.id, sIndex, 'up')}
                            disabled={sIndex === 0}
                            className="text-zinc-400 hover:text-indigo-600 disabled:opacity-0 transition-all"
                          >
                            <ChevronUp size={12} />
                          </button>
                          <button 
                            onClick={() => moveSubCategory(cat.id, sIndex, 'down')}
                            disabled={sIndex === filteredSubs.length - 1}
                            className="text-zinc-400 hover:text-indigo-600 disabled:opacity-0 transition-all"
                          >
                            <ChevronDown size={12} />
                          </button>
                        </div>
                        <span className="text-sm font-medium text-zinc-700">{sub.name}</span>
                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => { 
                            setEditingSubCategory(sub); 
                            setSubCategoryForm({ 
                              categoryId: sub.categoryId, 
                              name: sub.name,
                              isMandatoryForParent: sub.isMandatoryForParent || false,
                              startTime: sub.startTime || '',
                              endTime: sub.endTime || '',
                              duration: sub.duration || '',
                              googleMapsUrl: sub.googleMapsUrl || ''
                            }); 
                            setIsAddingSubCategory(true); 
                          }}
                          className="p-1 text-zinc-400 hover:text-indigo-600"
                        >
                          <Edit2 size={14} />
                        </button>
                        <button 
                          onClick={async () => {
                            if (confirm('למחוק תת-קטגוריה זו? כל המוצרים תחתיה יימחקו גם הם.')) {
                              try {
                                const batch = writeBatch(db);
                                
                                // Delete all products in this subcategory
                                const productsInSub = products.filter(p => p.subCategoryId === sub.id);
                                productsInSub.forEach(p => batch.delete(doc(db, 'products', p.id)));
                                
                                // Delete the subcategory itself
                                batch.delete(doc(db, 'subCategories', sub.id));
                                
                                await batch.commit();
                                toast.success('תת-הקטגוריה וכל המוצרים תחתיה נמחקו בהצלחה');
                                dataCache.subCategories = null;
                                dataCache.products = {};
                                setRefreshKey(prev => prev + 1);
                              } catch (err) {
                                toast.error('שגיאה במחיקה');
                              }
                            }
                          }}
                          className="p-1 text-zinc-400 hover:text-red-500"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                  <button 
                    onClick={() => { 
                      setSubCategoryForm({ 
                        categoryId: cat.id, 
                        name: '',
                        isMandatoryForParent: false,
                        startTime: '',
                        endTime: '',
                        duration: '',
                        googleMapsUrl: ''
                      }); 
                      setIsAddingSubCategory(true); 
                    }}
                    className="w-full py-2 border-2 border-dashed border-zinc-100 rounded-xl text-xs font-bold text-zinc-400 hover:border-indigo-200 hover:text-indigo-400 transition-all flex items-center justify-center gap-1"
                  >
                    <Plus size={12} />
                    הוסף תת-קטגוריה
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-3 mb-6">
        <Package size={24} className="text-indigo-600" />
        <h3 className="text-xl font-bold text-zinc-900">ניהול מוצרים</h3>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.length === 0 && (
          <div className="col-span-full p-20 bg-white rounded-3xl border border-zinc-200 text-center space-y-4">
            <div className="w-20 h-20 bg-zinc-50 rounded-full flex items-center justify-center mx-auto text-zinc-300">
              <Package size={40} />
            </div>
            <div>
              <p className="text-lg font-bold text-zinc-900">לא נמצאו מוצרים</p>
              <p className="text-zinc-500">נסה לשנות את מסנני החיפוש או להוסיף מוצר חדש</p>
            </div>
          </div>
        )}
        {filteredProducts.slice(0, visibleCount).map(product => (
          <motion.div
            layout
            key={product.id}
            className="bg-white rounded-2xl border border-zinc-200 overflow-hidden hover:shadow-xl transition-all group"
          >
            <div className="aspect-square relative bg-zinc-100 overflow-hidden">
              {product.image ? (
                <img 
                  src={product.image} 
                  alt={product.name} 
                  loading="lazy"
                  className="w-full h-full object-contain p-2 group-hover:scale-110 transition-transform duration-500" 
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                    const fallback = target.nextElementSibling;
                    if (fallback) fallback.classList.remove('hidden');
                  }}
                />
              ) : null}
              <div className={`w-full h-full flex items-center justify-center text-zinc-300 ${product.image ? 'hidden fallback' : ''}`}>
                {config?.logoUrl ? (
                  <img 
                    src={config.logoUrl} 
                    alt={product.name}
                    className="w-full h-full object-contain p-4 opacity-50 grayscale hover:grayscale-0 transition-all duration-300"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <ImageIcon size={48} />
                )}
              </div>
              <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-zinc-900 shadow-sm">
                {product.sku}
              </div>
            </div>
            <div className="p-5">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-zinc-900 line-clamp-1">{product.name}</h3>
                  <p className="text-xs text-zinc-500 font-medium">
                    {categories.find(c => c.id === product.categoryId)?.name}
                    {product.subCategoryId && ` > ${subCategories.find(s => s.id === product.subCategoryId)?.name}`}
                  </p>
                </div>
                <span className="text-indigo-600 font-bold">₪{product.price}</span>
              </div>
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-zinc-100">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${getStockBg(product.stockQuantity)}`} />
                  <span className={`text-sm font-bold ${getStockColor(product.stockQuantity)}`}>
                    {product.stockQuantity}/{product.totalStock || product.stockQuantity} יח' כללי
                    {product.reservedQuantity > 0 && (
                      <span className="text-amber-600 mr-1 text-[10px]">({product.reservedQuantity} משוריין)</span>
                    )}
                    {product.variants && product.variants.length > 0 && (
                      <div className="text-zinc-500 text-[10px] font-normal mt-1 flex flex-wrap gap-1">
                        {product.variants.map((v: any) => (
                           <span key={v.id} className="bg-zinc-100 px-1.5 py-0.5 rounded-md">
                             {v.name}: <span className={v.stockQuantity <= 0 ? 'text-red-500 font-bold' : ''}>{v.stockQuantity}</span>/{v.totalStock || v.stockQuantity}
                           </span>
                        ))}
                      </div>
                    )}
                  </span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setEditingProduct(product);
                      setProductForm(product);
                      setIsAddingProduct(true);
                    }}
                    className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors rounded-lg"
                  >
                    <Edit2 size={18} />
                  </button>
                  <button
                    onClick={() => deleteProduct(product.id)}
                    className="p-2 text-zinc-400 hover:text-red-600 hover:bg-red-50 transition-colors rounded-lg"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
      
      {visibleCount < filteredProducts.length && (
        <div className="mt-12 flex justify-center pb-8">
          <button
            onClick={() => setVisibleCount(prev => prev + 20)}
            className="px-8 py-3 bg-white border border-zinc-200 rounded-xl text-zinc-600 font-bold hover:bg-zinc-50 transition-colors shadow-sm"
          >
            טען עוד מוצרים
          </button>
        </div>
      )}

      {/* Import Modal */}
      <AnimatePresence>
        {isImporting && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                <h3 className="text-xl font-bold text-zinc-900">ייבוא מוצרים מאקסל</h3>
                <button onClick={() => setIsImporting(false)} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
              </div>
              <div className="p-8 space-y-6">
                <div className="space-y-3">
                  <label className="block text-sm font-semibold text-zinc-700">שיטת ייבוא</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setImportMode('add')}
                      className={`py-3 px-4 rounded-xl border-2 transition-all font-medium ${importMode === 'add' ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-zinc-100 text-zinc-500 hover:border-zinc-200'}`}
                    >
                      הוספה למלאי
                    </button>
                    <button
                      onClick={() => setImportMode('replace')}
                      className={`py-3 px-4 rounded-xl border-2 transition-all font-medium ${importMode === 'replace' ? 'border-red-600 bg-red-50 text-red-600' : 'border-zinc-100 text-zinc-500 hover:border-zinc-200'}`}
                    >
                      החלפת מלאי
                    </button>
                  </div>
                  <p className="text-xs text-zinc-400">
                    {importMode === 'add' ? '* המוצרים יתווספו למלאי הקיים.' : '* כל המלאי הקיים יימחק ויוחלף במוצרים מהקובץ.'}
                  </p>
                </div>

                <div className="relative">
                  <input
                    type="file"
                    accept=".xlsx, .xls, .csv"
                    onChange={handleImport}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    disabled={isProcessing}
                  />
                  <div className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all ${isProcessing ? 'border-indigo-400 bg-indigo-50' : 'border-zinc-200 hover:border-indigo-400'}`}>
                    {isProcessing ? (
                      <div className="space-y-4">
                        <Loader2 className="mx-auto text-indigo-600 animate-spin" size={32} />
                        <div>
                          <p className="text-sm font-bold text-zinc-900">מעבד מוצרים...</p>
                          <p className="text-xs text-zinc-500 mt-1">{importProgress} מתוך {importTotal}</p>
                        </div>
                        <div className="w-full bg-zinc-200 rounded-full h-2 overflow-hidden">
                          <motion.div 
                            className="bg-indigo-600 h-full"
                            initial={{ width: 0 }}
                            animate={{ width: `${(importProgress / importTotal) * 100}%` }}
                          />
                        </div>
                      </div>
                    ) : (
                      <>
                        <FileUp className="mx-auto text-zinc-400 mb-2" size={32} />
                        <p className="text-sm font-medium text-zinc-900">לחץ להעלאת קובץ</p>
                        <p className="text-xs text-zinc-400 mt-1">Excel או CSV בלבד</p>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add/Edit Product Modal */}
      <AnimatePresence>
        {isAddingProduct && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full flex flex-col max-h-[90vh]"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50 shrink-0">
                <h3 className="text-xl font-bold text-zinc-900">{editingProduct ? 'עריכת מוצר' : 'הוספת מוצר חדש'}</h3>
                <button onClick={() => { setIsAddingProduct(false); setEditingProduct(null); }} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
              </div>
              <form onSubmit={handleAddProduct} className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6 overflow-y-auto">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">שם המוצר</label>
                    <input required type="text" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={productForm.name || ''} onChange={e => setProductForm({...productForm, name: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">מק"ט (SKU)</label>
                    <input required type="text" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={productForm.sku || ''} onChange={e => setProductForm({...productForm, sku: e.target.value})} />
                  </div>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-zinc-700 mb-1">תת-קטגוריה</label>
                      <select 
                        required 
                        className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" 
                        value={productForm.subCategoryId || ''} 
                        onChange={e => {
                          const subId = e.target.value;
                          const sub = subCategories.find(s => s.id === subId);
                          setProductForm({
                            ...productForm, 
                            subCategoryId: subId,
                            categoryId: sub ? sub.categoryId : ''
                          });
                        }}
                      >
                        <option value="">בחר תת-קטגוריה</option>
                        {categories.map(cat => (
                          <optgroup key={cat.id} label={cat.name}>
                            {subCategories.filter(s => s.categoryId === cat.id).map(s => (
                              <option key={s.id} value={s.id}>{s.name}</option>
                            ))}
                          </optgroup>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-zinc-700 mb-1">מחיר (₪)</label>
                      <input required type="number" className="w-full px-3 py-3 text-center border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={productForm.price || 0} onChange={e => setProductForm({...productForm, price: Number(e.target.value)})} />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="block text-sm font-semibold text-zinc-700">מלאי (נוכחי/כללי)</label>
                      <div className="flex items-center gap-2">
                        <input 
                          required 
                          type="number" 
                          placeholder="נוכחי"
                          className="w-full px-2 py-3 text-center border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" 
                          value={productForm.stockQuantity || 0} 
                          onChange={e => setProductForm({...productForm, stockQuantity: Number(e.target.value)})} 
                        />
                        <span className="text-zinc-400">/</span>
                        <input 
                          required 
                          type="number" 
                          placeholder="כללי"
                          className="w-full px-2 py-3 text-center border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" 
                          value={productForm.totalStock || 0} 
                          onChange={e => setProductForm({...productForm, totalStock: Number(e.target.value)})} 
                        />
                      </div>
                    </div>
                  </div>
                  
                  {/* Variants Section */}
                  <div className="md:col-span-2 mt-6 border-t border-zinc-100 pt-6">
                    <div className="flex justify-between items-center mb-4">
                      <label className="block text-sm font-bold text-zinc-800">תת-פריטים (וריאציות)</label>
                      <div className="flex items-center gap-2">
                        <select 
                          className="text-xs bg-zinc-50 border border-zinc-200 text-zinc-600 px-2 py-1 rounded-lg outline-none max-w-[150px]"
                          onChange={e => {
                            if (e.target.value) {
                              const p = products.find(prod => prod.id === e.target.value);
                              if (p && p.variants) {
                                setProductForm({ 
                                  ...productForm, 
                                  variants: [...(productForm.variants || []), ...p.variants.map((v: any) => ({
                                    ...v, 
                                    id: Date.now().toString() + Math.random().toString(36).substr(2, 5)
                                  }))]
                                });
                              }
                              e.target.value = '';
                            }
                          }}
                        >
                          <option value="">שכפל ממוצר...</option>
                          {products.filter(p => p.variants && p.variants.length > 0).map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                          ))}
                        </select>
                        <button type="button" onClick={addVariant} className="text-xs bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full font-bold hover:bg-indigo-100 transition-colors flex items-center gap-1">
                          <Plus size={14} /> הוסף תת-פריט
                        </button>
                      </div>
                    </div>
                    
                    {productForm.variants && productForm.variants.length > 0 ? (
                      <div className="space-y-3">
                        {productForm.variants.map((variant, idx) => (
                          <div key={variant.id} className="grid grid-cols-12 gap-3 bg-white p-3 rounded-xl border border-zinc-200 items-end shadow-sm">
                            <div className="col-span-12 sm:col-span-5">
                              <label className="text-[10px] text-zinc-500 block mb-1">שם (למשל: מידה לארג', צבע כחול)</label>
                              <input 
                                type="text" 
                                placeholder="שם הוריאציה"
                                className="w-full px-3 py-2 border border-zinc-200 rounded-lg outline-none text-sm focus:ring-2 focus:ring-indigo-500"
                                value={variant.name}
                                onChange={e => updateVariant(idx, 'name', e.target.value)}
                                required
                              />
                            </div>
                            <div className="col-span-3 sm:col-span-2">
                              <label className="text-[10px] text-zinc-500 block mb-1">מחיר (₪)</label>
                              <input 
                                type="number" 
                                placeholder="מחיר"
                                className="w-full px-2 py-2 text-center border border-zinc-200 rounded-lg outline-none text-sm focus:ring-2 focus:ring-indigo-500"
                                value={variant.price === undefined ? '' : variant.price}
                                onChange={e => updateVariant(idx, 'price', e.target.value === '' ? '' : Number(e.target.value))}
                              />
                            </div>
                            <div className="col-span-3 sm:col-span-2">
                              <label className="text-[10px] text-zinc-500 block mb-1">נוכחי</label>
                              <input 
                                type="number" 
                                placeholder="נוכחי"
                                className="w-full px-2 py-2 text-center border border-zinc-200 rounded-lg outline-none text-sm focus:ring-2 focus:ring-indigo-500"
                                value={variant.stockQuantity === undefined ? '' : variant.stockQuantity}
                                onChange={e => updateVariant(idx, 'stockQuantity', e.target.value === '' ? '' : Number(e.target.value))}
                                required
                              />
                            </div>
                            <div className="col-span-4 sm:col-span-2">
                              <label className="text-[10px] text-zinc-500 block mb-1">כללי</label>
                              <input 
                                type="number" 
                                placeholder="כללי"
                                className="w-full px-2 py-2 text-center border border-zinc-200 rounded-lg outline-none text-sm focus:ring-2 focus:ring-indigo-500"
                                value={variant.totalStock === undefined ? '' : variant.totalStock}
                                onChange={e => updateVariant(idx, 'totalStock', e.target.value === '' ? '' : Number(e.target.value))}
                                required
                              />
                            </div>
                            <div className="col-span-2 sm:col-span-1 flex justify-end">
                              <button type="button" onClick={() => removeVariant(idx)} className="w-full flex items-center justify-center p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors h-[38px] border border-transparent hover:border-red-100">
                                <Trash2 size={16} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-zinc-500 bg-zinc-50 p-3 rounded-lg text-center">אין תת-פריטים. לחץ על "הוסף תת-פריט" כדי להוסיף מידות, צבעים או סוגים שונים לאותו מוצר.</p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-zinc-700 mb-1">שעת התחלה (מוצר)</label>
                      <input type="time" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={productForm.startTime || ''} onChange={e => setProductForm({...productForm, startTime: e.target.value})} />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-zinc-700 mb-1">שעת סיום (מוצר)</label>
                      <input type="time" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={productForm.endTime || ''} onChange={e => setProductForm({...productForm, endTime: e.target.value})} />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">משך זמן פעילות (מוצר)</label>
                    <input type="text" placeholder="למשל: שעה וחצי" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={productForm.duration || ''} onChange={e => setProductForm({...productForm, duration: e.target.value})} />
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">תמונת מוצר</label>
                    <div className="space-y-3">
                      <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-zinc-200 border-dashed rounded-2xl hover:border-indigo-500 transition-colors relative group">
                        {productForm.image ? (
                          <div className="relative w-full aspect-video">
                            <img src={productForm.image} loading="lazy" alt="Preview" className="w-full h-full object-contain rounded-xl p-2" referrerPolicy="no-referrer" />
                            <button 
                              type="button"
                              onClick={() => setProductForm({...productForm, image: ''})}
                              className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 shadow-lg"
                            >
                              <X size={16} />
                            </button>
                          </div>
                        ) : (
                          <div className="space-y-1 text-center">
                            {uploading ? (
                              <Loader2 className="mx-auto h-12 w-12 text-indigo-500 animate-spin" />
                            ) : (
                              <Upload className="mx-auto h-12 w-12 text-zinc-400" />
                            )}
                            <div className="flex text-sm text-zinc-600">
                              <label className="relative cursor-pointer bg-white rounded-md font-bold text-indigo-600 hover:text-indigo-500">
                                <span>העלה תמונה</span>
                                <input type="file" className="sr-only" accept="image/*" onChange={handleImageUpload} disabled={uploading} />
                              </label>
                            </div>
                            <p className="text-xs text-zinc-500">PNG, JPG עד 5MB</p>
                          </div>
                        )}
                      </div>
                      <div className="relative">
                        <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                          <ImageIcon size={16} className="text-zinc-400" />
                        </div>
                        <input 
                          type="url" 
                          placeholder="או הדבק קישור לתמונה כאן..." 
                          className="w-full pr-10 pl-4 py-2 text-sm border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                          value={productForm.image || ''}
                          onChange={e => setProductForm({...productForm, image: e.target.value})}
                        />
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">תיאור מוצר</label>
                    <textarea rows={4} className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={productForm.description || ''} onChange={e => setProductForm({...productForm, description: e.target.value})} />
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                    <input 
                      type="checkbox" 
                      id="hideLowStockAlert"
                      className="w-5 h-5 rounded border-zinc-300 text-indigo-600 focus:ring-indigo-500"
                      checked={!productForm.hideLowStockAlert}
                      onChange={e => setProductForm({...productForm, hideLowStockAlert: !e.target.checked})}
                    />
                    <label htmlFor="hideLowStockAlert" className="text-sm font-bold text-zinc-700 cursor-pointer">
                      הצג התראות על מלאי נמוך למוצר זה
                    </label>
                  </div>
                </div>
                <div className="md:col-span-2 flex justify-end gap-3 pt-6 border-t border-zinc-100">
                  <button type="button" onClick={() => { setIsAddingProduct(false); setEditingProduct(null); }} className="px-6 py-3 text-zinc-600 font-bold hover:bg-zinc-100 rounded-xl transition-all">ביטול</button>
                  <button type="submit" disabled={isSaving} className="px-10 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 disabled:opacity-50 flex items-center gap-2">
                    {isSaving ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                    שמור מוצר
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Batch Image Upload Modal */}
      <AnimatePresence>
        {isBatchImageUpload && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                <h3 className="text-xl font-bold text-zinc-900">העלאת תמונות לפי מק"ט</h3>
                <button onClick={() => setIsBatchImageUpload(false)} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
              </div>
              <div className="p-8 space-y-6">
                <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-100">
                  <p className="text-sm text-indigo-700 leading-relaxed">
                    בחר מספר תמונות מהמחשב. המערכת תשייך כל תמונה למוצר באופן אוטומטי אם שם הקובץ (ללא הסיומת) תואם למק"ט המוצר.
                  </p>
                </div>

                <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100">
                  <p className="text-xs text-amber-700 leading-relaxed">
                    שים לב: אם ההעלאה לענן נכשלת, המערכת תנסה לשמור את התמונה באופן מקומי (Base64) עבור קבצים קטנים מ-500KB. 
                    מומלץ לוודא ששירות ה-Storage מופעל בפיירבייס להעלאת קבצים גדולים.
                  </p>
                </div>

                {isProcessing ? (
                  <div className="space-y-4">
                    <div className="flex justify-between text-sm font-bold">
                      <span className="text-zinc-600">מעבד תמונות...</span>
                      <span className="text-indigo-600">{batchUploadProgress} / {batchUploadTotal}</span>
                    </div>
                    <div className="w-full bg-zinc-100 h-3 rounded-full overflow-hidden">
                      <motion.div 
                        className="bg-indigo-600 h-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${(batchUploadProgress / batchUploadTotal) * 100}%` }}
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center text-xs font-bold">
                      <div className="bg-emerald-50 text-emerald-600 p-2 rounded-lg">
                        {batchUploadResults.success} הצליחו
                      </div>
                      <div className="bg-zinc-50 text-zinc-500 p-2 rounded-lg">
                        {batchUploadResults.skipped} לא נמצאו
                      </div>
                      <div className="bg-red-50 text-red-600 p-2 rounded-lg">
                        {batchUploadResults.failed} נכשלו
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="relative group">
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handleBatchImageUpload}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                      />
                      <div className="border-2 border-dashed border-zinc-200 rounded-2xl p-8 text-center group-hover:border-indigo-500 transition-all">
                        <Upload className="mx-auto h-12 w-12 text-zinc-400 mb-2 group-hover:text-indigo-500" />
                        <p className="font-bold text-zinc-900">לחץ לבחירת תמונות</p>
                        <p className="text-xs text-zinc-500 mt-1">ניתן לבחור מספר קבצים בו-זמנית</p>
                      </div>
                    </div>
                    
                    {batchUploadTotal > 0 && !isProcessing && (
                      <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-200">
                        <div className="flex justify-between items-center mb-2">
                          <p className="text-sm font-bold text-zinc-900">תוצאות העלאה אחרונה:</p>
                          <button 
                            onClick={() => { setBatchUploadTotal(0); setBatchUploadResults({success: 0, failed: 0, skipped: 0}); }}
                            className="text-xs text-indigo-600 hover:text-indigo-700 font-bold"
                          >
                            נקה תוצאות
                          </button>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-center text-xs font-bold">
                          <div className="text-emerald-600">{batchUploadResults.success} הצליחו</div>
                          <div className="text-zinc-500">{batchUploadResults.skipped} לא נמצאו</div>
                          <div className="text-red-600">{batchUploadResults.failed} נכשלו</div>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <button
                  onClick={() => setIsBatchImageUpload(false)}
                  className="w-full py-4 bg-zinc-900 text-white font-bold rounded-2xl hover:bg-zinc-800 transition-all"
                >
                  סגור
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Category Modal */}
      <AnimatePresence>
        {isAddingCategory && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                <h3 className="text-xl font-bold text-zinc-900">הוספת קטגוריה</h3>
                <button onClick={() => setIsAddingCategory(false)} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
              </div>
              <form onSubmit={handleAddCategory} className="p-8 space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 mb-1">שם הקטגוריה</label>
                  <input required type="text" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={categoryForm.name || ''} onChange={e => setCategoryForm({...categoryForm, name: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 mb-1">תיאור</label>
                  <textarea className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={categoryForm.description || ''} onChange={e => setCategoryForm({...categoryForm, description: e.target.value})} />
                </div>
                <div className="flex justify-end gap-3 pt-4">
                  <button type="button" onClick={() => setIsAddingCategory(false)} className="px-6 py-2 text-zinc-600 font-bold hover:bg-zinc-100 rounded-xl transition-all">ביטול</button>
                  <button type="submit" disabled={isSaving} className="px-8 py-2 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 disabled:opacity-50 flex items-center gap-2">
                    {isSaving ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                    שמור
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Sub-Category Modal */}
      <AnimatePresence>
        {isAddingSubCategory && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                <h3 className="text-xl font-bold text-zinc-900">{editingSubCategory ? 'עריכת תת-קטגוריה' : 'הוספת תת-קטגוריה'}</h3>
                <button onClick={() => { setIsAddingSubCategory(false); setEditingSubCategory(null); }} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
              </div>
              <form onSubmit={handleAddSubCategory} className="p-8 space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 mb-1">קטגוריית אב</label>
                  <select required className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={subCategoryForm.categoryId || ''} onChange={e => setSubCategoryForm({...subCategoryForm, categoryId: e.target.value})}>
                    <option value="">בחר קטגוריה</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 mb-1">שם תת-הקטגוריה</label>
                  <input required type="text" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={subCategoryForm.name || ''} onChange={e => setSubCategoryForm({...subCategoryForm, name: e.target.value})} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">שעת התחלה</label>
                    <input type="time" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={subCategoryForm.startTime || ''} onChange={e => setSubCategoryForm({...subCategoryForm, startTime: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-zinc-700 mb-1">שעת סיום</label>
                    <input type="time" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={subCategoryForm.endTime || ''} onChange={e => setSubCategoryForm({...subCategoryForm, endTime: e.target.value})} />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 mb-1">משך זמן פעילות</label>
                  <input type="text" placeholder="למשל: שעה וחצי" className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={subCategoryForm.duration || ''} onChange={e => setSubCategoryForm({...subCategoryForm, duration: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 mb-1">קישור גוגל מאפס</label>
                  <input type="url" placeholder="https://goo.gl/maps/..." className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={subCategoryForm.googleMapsUrl || ''} onChange={e => setSubCategoryForm({...subCategoryForm, googleMapsUrl: e.target.value})} />
                </div>
                <div className="flex items-center gap-3 p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                  <input 
                    type="checkbox" 
                    id="isMandatoryForParent"
                    className="w-5 h-5 rounded border-zinc-300 text-indigo-600 focus:ring-indigo-500"
                    checked={subCategoryForm.isMandatoryForParent}
                    onChange={e => setSubCategoryForm({...subCategoryForm, isMandatoryForParent: e.target.checked})}
                  />
                  <label htmlFor="isMandatoryForParent" className="text-sm font-bold text-zinc-700 cursor-pointer">
                    חובה להזמין מוצר מתת-קטגוריה זו בהזמנת מוצר מקטגוריית האב
                  </label>
                </div>
                <div className="flex justify-end gap-3 pt-4">
                  <button type="button" onClick={() => { setIsAddingSubCategory(false); setEditingSubCategory(null); }} className="px-6 py-2 text-zinc-600 font-bold hover:bg-zinc-100 rounded-xl transition-all">ביטול</button>
                  <button type="submit" disabled={isSaving} className="px-8 py-2 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 disabled:opacity-50 flex items-center gap-2">
                    {isSaving ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                    שמור
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
