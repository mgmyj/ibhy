import React, { useState, useEffect } from 'react';
import { db, collection, getDocs, handleFirestoreError, OperationType, doc, updateDoc, query, limit, where } from '../firebase';
import { AlertTriangle, X, Package, Check, Edit2, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';

export function LowStockAlert({ isAdmin }: { isAdmin: boolean }) {
  const [lowStockProducts, setLowStockProducts] = useState<any[]>([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [hasNewAlert, setHasNewAlert] = useState(false);

  useEffect(() => {
    if (!isAdmin) return;

    const fetchLowStock = async () => {
      try {
        const snapshot = await getDocs(query(
          collection(db, 'products'), 
          where('stockQuantity', '<', 20),
          limit(100)
        ));
        const products = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) }));
        const lowStock = products.filter((p: any) => !p.hideLowStockAlert);
        
        if (lowStock.length > lowStockProducts.length && lowStockProducts.length > 0) {
          setHasNewAlert(true);
        }
        
        setLowStockProducts(lowStock);
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, 'products');
      }
    };

    fetchLowStock();
  }, [isAdmin]);

  const dismissAlert = async (productId: string) => {
    try {
      await updateDoc(doc(db, 'products', productId), {
        hideLowStockAlert: true
      });
      toast.success('ההתראה הוסרה לצמיתות עבור מוצר זה');
    } catch (err) {
      console.error('Error dismissing alert:', err);
      handleFirestoreError(err, OperationType.UPDATE, `products/${productId}`);
      toast.error('שגיאה בהסרת ההתראה');
    }
  };

  const editProduct = (productId: string) => {
    // Dispatch custom event to change tab and open edit modal
    window.dispatchEvent(new CustomEvent('change-tab', { detail: 'inventory' }));
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('edit-product', { detail: productId }));
    }, 100);
    setIsExpanded(false);
  };

  if (!isAdmin || lowStockProducts.length === 0) return null;

  return (
    <div className="fixed bottom-6 left-6 z-[100] flex flex-col items-end gap-3" dir="rtl">
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20, x: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0, x: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20, x: -20 }}
            className="bg-white rounded-3xl shadow-2xl w-80 overflow-hidden border border-red-100 flex flex-col max-h-[70vh]"
          >
            <div className="p-4 bg-red-600 text-white flex justify-between items-center">
              <div className="flex items-center gap-2">
                <AlertTriangle size={18} />
                <h3 className="font-bold text-sm">מוצרים במלאי נמוך ({lowStockProducts.length})</h3>
              </div>
              <button onClick={() => setIsExpanded(false)} className="hover:bg-white/20 p-1 rounded-lg transition-colors">
                <X size={18} />
              </button>
            </div>
            
            <div className="overflow-y-auto p-3 space-y-2">
              {lowStockProducts.map(product => (
                <div key={product.id} className="p-3 bg-zinc-50 rounded-2xl border border-zinc-100 flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center text-zinc-400 border border-zinc-100">
                        <Package size={14} />
                      </div>
                      <div>
                        <p className="font-bold text-xs text-zinc-900 truncate max-w-[120px]">{product.name}</p>
                        <p className="text-[10px] text-zinc-400">מלאי: <span className="text-red-600 font-bold">{product.stockQuantity}</span></p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <button 
                        onClick={() => dismissAlert(product.id)}
                        className="p-1.5 bg-white border border-zinc-200 rounded-lg text-emerald-600 hover:bg-emerald-50 transition-all"
                        title="אל תציג שוב"
                      >
                        <Check size={14} />
                      </button>
                      <button 
                        onClick={() => editProduct(product.id)}
                        className="p-1.5 bg-white border border-zinc-200 rounded-lg text-indigo-600 hover:bg-indigo-50 transition-all"
                        title="ערוך מוצר"
                      >
                        <Edit2 size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        layout
        onClick={() => {
          setIsExpanded(!isExpanded);
          setHasNewAlert(false);
        }}
        className={`relative group flex items-center gap-3 p-4 rounded-2xl shadow-xl transition-all ${
          hasNewAlert ? 'bg-red-600 animate-bounce' : 'bg-red-500 hover:bg-red-600'
        } text-white`}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <div className="relative">
          <AlertTriangle size={24} />
          {hasNewAlert && (
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-white rounded-full animate-ping" />
          )}
        </div>
        {!isExpanded && (
          <div className="flex flex-col items-start">
            <span className="text-xs font-bold leading-none">מלאי נמוך!</span>
            <span className="text-[10px] opacity-80">{lowStockProducts.length} מוצרים</span>
          </div>
        )}
        {isExpanded ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
      </motion.button>
    </div>
  );
}
