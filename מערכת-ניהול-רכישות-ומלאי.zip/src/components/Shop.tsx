import React, { useState, useEffect, useRef } from 'react';
import { db, collection, getDocs, addDoc, updateDoc, doc, handleFirestoreError, OperationType, serverTimestamp, auth, setDoc, deleteDoc, runTransaction, getDoc, query, orderBy, limit, where, onSnapshot } from '../firebase';
import { ShoppingCart, Search, Filter, ChevronLeft, CreditCard, User, Phone, MapPin, CheckCircle2, X, Minus, Plus, ShoppingBag, Check, Clock, Timer, RefreshCcw, Loader2, ClipboardList, Mail, Send, PanelRightClose, PanelRightOpen, Grid } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';
import { dataCache, CACHE_DURATION } from '../lib/cache';
import { sendEmail, formatOrderEmail } from '../services/emailService';
import { notifyAdminEmailFailure } from '../services/adminAlertService';

interface Category { id: string; name: string; order?: number; }
interface SubCategory { 
  id: string; 
  name: string; 
  categoryId: string; 
  startTime?: string;
  endTime?: string;
  duration?: string;
  googleMapsUrl?: string;
  isMandatoryForParent?: boolean;
  order?: number;
}
interface Product { 
  id: string; 
  sku: string; 
  name: string; 
  description?: string; 
  image?: string; 
  price: number; 
  categoryId: string; 
  subCategoryId?: string; 
  stockQuantity: number; 
  totalStock?: number; 
  reservedQuantity?: number;
  startTime?: string;
  endTime?: string;
  duration?: string;
  variants?: any[];
}
interface CartItem extends Product { quantity: number; variantId?: string; variantName?: string; variantPrice?: number; cartItemId?: string; }

interface FormField {
  id: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'select' | 'email';
  options?: string[];
  required?: boolean;
}

interface EmailSettings {
  mainEmail: string;
  reportEmail: string;
  replyToType: 'sender' | 'fixed';
  fixedReplyToEmail?: string;
  senderChoice: 'user' | 'system';
  notifyNewOrder: boolean;
  notifyEditOrder: boolean;
  notifyDeleteOrder: boolean;
  notifyReservation: boolean;
  notifyLowStock: boolean;
  disableAllEmails?: boolean;
}

interface SystemConfig {
  customerFormTitle: string;
  customerFormFields: FormField[];
  siteName: string;
  orgName: string;
  logoUrl: string;
  emailSettings?: EmailSettings;
}

interface Customer { id: string; name: string; associationName?: string; contactPerson?: string; email?: string; phone?: string; address?: string; city?: string; }

export function Shop({ isAdmin, userRole, allowedCategories, onNavigate }: { isAdmin?: boolean; userRole?: string; allowedCategories?: string[]; onNavigate?: (tab: any) => void }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [subCategories, setSubCategories] = useState<SubCategory[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [gridCols, setGridCols] = useState<number>(() => {
    const saved = localStorage.getItem('shop_grid_cols');
    return saved ? parseInt(saved, 10) : 4;
  });
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'price' | 'stock' | 'name'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [minPrice, setMinPrice] = useState<number | ''>('');
  const [maxPrice, setMaxPrice] = useState<number | ''>('');
  const [startTimeFilter, setStartTimeFilter] = useState<string>('');
  const [endTimeFilter, setEndTimeFilter] = useState<string>('');
  const [orderComplete, setOrderComplete] = useState(false);
  const [lastOrder, setLastOrder] = useState<any>(null);
  const [lastCustomer, setLastCustomer] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isSubmittingRef = useRef(false);
  const [sendingEmail, setSendingEmail] = useState(false);
  const [extraEmail, setExtraEmail] = useState('');
  const [showExtraEmailInput, setShowExtraEmailInput] = useState(false);
  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>({});
  const [config, setConfig] = useState<SystemConfig>({ 
    customerFormTitle: 'פרטי לקוח וסיום רכישה',
    customerFormFields: [
      { id: 'name', label: 'שם מלא', type: 'text', required: true },
      { id: 'associationName', label: 'שם האיגוד', type: 'text', required: false },
      { id: 'contactPerson', label: 'איש קשר', type: 'text', required: false },
      { id: 'phone', label: 'טלפון', type: 'number', required: true },
      { id: 'email', label: 'דואר אלקטרוני', type: 'text', required: true },
      { id: 'city', label: 'עיר', type: 'text', required: false },
      { id: 'address', label: 'כתובת למשלוח', type: 'text', required: false }
    ],
    siteName: 'מערכת רכש',
    orgName: 'שם הארגון',
    logoUrl: '',
    emailSettings: {
      mainEmail: '',
      reportEmail: '',
      replyToType: 'sender',
      fixedReplyToEmail: '',
      senderChoice: 'system',
      notifyNewOrder: true,
      notifyEditOrder: true,
      notifyDeleteOrder: true,
      notifyReservation: true,
      notifyLowStock: true,
      disableAllEmails: false
    }
  });

  // Customer form
  const [customer, setCustomer] = useState<Record<string, any>>({});
  const [customerSearch, setCustomerSearch] = useState('');
  const [showCustomerResults, setShowCustomerResults] = useState(false);
  const [activeCarts, setActiveCarts] = useState<Record<string, number>>({});
  const [allActiveCarts, setAllActiveCarts] = useState<any[]>([]);
  const [showActiveCartsModal, setShowActiveCartsModal] = useState(false);
  const cartLoaded = useRef(false);
  const docExisted = useRef(false);
  const cartRef = useRef(cart);

  useEffect(() => {
    cartRef.current = cart;
  }, [cart]);

  const [sessionId] = useState(() => {
    const saved = localStorage.getItem('shop_session_id');
    if (saved) return saved;
    const newId = Math.random().toString(36).substr(2, 9);
    localStorage.setItem('shop_session_id', newId);
    return newId;
  });

  useEffect(() => {
    const userId = auth.currentUser?.uid || `guest_${sessionId}`;
    const userEmail = auth.currentUser?.email || 'אורח';
    const userName = auth.currentUser?.displayName || 'אורח';

    if (cart.length > 0 && cartLoaded.current) {
      const cartData = cart.reduce((acc, item) => {
        acc[item.id] = (acc[item.id] || 0) + item.quantity;
        return acc;
      }, {});
      const detailedItems = cart.map(item => ({
        id: item.id,
        cartItemId: item.cartItemId || item.id,
        quantity: item.quantity,
        variantId: item.variantId || null,
        variantName: item.variantName || null,
        variantPrice: item.variantPrice !== undefined ? item.variantPrice : null
      }));
      setDoc(doc(db, 'active_carts', userId), {
        items: cartData,
        detailedItems: detailedItems,
        updatedAt: serverTimestamp(),
        userEmail,
        userName,
        totalItems: cart.reduce((sum, item) => sum + item.quantity, 0),
        totalAmount: cart.reduce((sum, item) => sum + ((item.variantPrice !== undefined ? item.variantPrice : item.price) * item.quantity), 0)
      }).then(() => {
        docExisted.current = true;
      }).catch(err => {
        if (err.code === 'permission-denied') {
          handleFirestoreError(err, OperationType.WRITE, `active_carts/${userId}`);
        }
        console.error('Error updating active cart:', err);
      });
    } else if (cart.length === 0 && cartLoaded.current && docExisted.current) {
      deleteDoc(doc(db, 'active_carts', userId)).then(() => {
        docExisted.current = false;
      }).catch(err => {
        if (err.code === 'permission-denied') {
          handleFirestoreError(err, OperationType.DELETE, `active_carts/${userId}`);
        }
        console.error('Error deleting active cart:', err);
      });
    }
  }, [cart, sessionId]);

  // Load initial cart from Firestore
  useEffect(() => {
    if (products.length === 0 || cartLoaded.current) return;
    
    const userId = auth.currentUser?.uid || `guest_${sessionId}`;
    const getInitialCart = async () => {
      try {
        const docSnap = await getDoc(doc(db, 'active_carts', userId));
        if (docSnap.exists()) {
          const data = docSnap.data();
          const newCart: CartItem[] = [];
          
          if (data.detailedItems && Array.isArray(data.detailedItems)) {
            data.detailedItems.forEach(item => {
              const product = products.find(p => p.id === item.id);
              if (product) {
                newCart.push({
                   ...product,
                   quantity: item.quantity,
                   cartItemId: item.cartItemId,
                   variantId: item.variantId,
                   variantName: item.variantName,
                   variantPrice: item.variantPrice !== null ? item.variantPrice : undefined
                });
              }
            });
          } else {
            const items = data.items || {};
            Object.entries(items).forEach(([prodId, qty]) => {
              const product = products.find(p => p.id === prodId);
              if (product) {
                newCart.push({ ...product, quantity: qty as number });
              }
            });
          }
          
          if (newCart.length > 0) {
            setCart(newCart);
          }
          docExisted.current = true;
        }
      } catch (err) {
        console.error('Error loading initial cart:', err);
      } finally {
        cartLoaded.current = true;
      }
    };
    
    getInitialCart();
  }, [products, sessionId]);

  // Listen for external cart deletions (e.g. by admin)
  // Removed onSnapshot to save quota. Using one-time fetch on mount instead.
  useEffect(() => {
    const userId = auth.currentUser?.uid || `guest_${sessionId}`;
    const checkCartExists = async () => {
      try {
        const snapshot = await getDoc(doc(db, 'active_carts', userId));
        docExisted.current = snapshot.exists();
      } catch (err) {
        console.error('Error checking own active cart:', err);
      }
    };
    checkCartExists();
  }, [sessionId]);

  useEffect(() => {
    if (!isAdmin) {
      setActiveCarts({});
      setAllActiveCarts([]);
    }
  }, [isAdmin]);
    
  useEffect(() => {
    // Removed isAdmin check so all users listen to active_carts
    const q = query(collection(db, 'active_carts'), limit(100));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const totals = {};
      const allCarts = [];
      const userId = auth.currentUser?.uid || `guest_${sessionId}`;
      
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        if (doc.id !== userId) {
          if (data.detailedItems && Array.isArray(data.detailedItems)) {
            data.detailedItems.forEach(item => {
              const key = item.variantId ? `${item.id}-${item.variantId}` : item.id;
              totals[key] = (totals[key] || 0) + item.quantity;
              
              // Also keep the parent product total for general availability checks if needed,
              // but we prefix it or just keep it. We'll just add it to the parent id as well so we can show total per product,
              // but we need a way to distinguish. Let's just track the exact ID (with variant).
              // We'll also track the parent total.
              if (item.variantId) {
                totals[item.id] = (totals[item.id] || 0) + item.quantity;
              }
            });
          } else {
            const items = data.items || {};
            Object.entries(items).forEach(([productId, qty]) => {
              totals[productId] = (totals[productId] || 0) + qty;
            });
          }
        }
        allCarts.push({ id: doc.id, ...data });
      });
      
      setActiveCarts(totals);
      setAllActiveCarts(allCarts);
    }, (err) => {
      if (err instanceof Error && err.message.includes('permission-denied')) {
        handleFirestoreError(err, OperationType.LIST, 'active_carts');
      }
      console.error('Error listening to active carts:', err);
    });

    return () => unsubscribe();
  }, [isAdmin, sessionId]);

  useEffect(() => {
    const unsubCategories = onSnapshot(query(collection(db, 'categories'), limit(100)), (snap) => {
      const cats = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Category));
      const sortedCats = cats.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
      setCategories(sortedCats);
      dataCache.categories = sortedCats;
    }, (err) => {
      console.error('Error listening to categories:', err);
    });
    
    const unsubSubCategories = onSnapshot(query(collection(db, 'subCategories'), limit(100)), (snap) => {
      const subs = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as SubCategory));
      const sortedSubs = subs.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
      setSubCategories(sortedSubs);
      dataCache.subCategories = sortedSubs;
    }, (err) => {
      console.error('Error listening to subcategories:', err);
    });

    const unsubConfig = onSnapshot(doc(db, 'config', 'system'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as any;
        dataCache.config = data;
        if (Array.isArray(data.customerFormFields) && typeof data.customerFormFields[0] === 'string') {
          const migratedFields = data.customerFormFields.map((f: string) => ({
            id: f,
            label: f === 'name' ? 'שם מלא' : f === 'phone' ? 'טלפון' : f === 'address' ? 'כתובת' : f,
            type: f === 'phone' ? 'number' : 'text'
          }));
          setConfig({
            customerFormTitle: data.customerFormTitle || 'פרטי לקוח וסיום רכישה',
            customerFormFields: migratedFields,
            siteName: data.siteName || 'מערכת רכש',
            orgName: data.orgName || 'שם הארגון',
            logoUrl: data.logoUrl || ''
          } as SystemConfig);
        } else {
          setConfig(data as SystemConfig);
        }
      }
    }, (err) => {
      console.error('Error listening to config:', err);
    });

    return () => {
      unsubCategories();
      unsubSubCategories();
      unsubConfig();
    };
  }, []);

  const [refreshKey, setRefreshKey] = useState(0);
  const [visibleCount, setVisibleCount] = useState(20);

  useEffect(() => {
    setVisibleCount(20);
  }, [searchTerm, selectedCategory, selectedSubCategory, sortBy, sortOrder, minPrice, maxPrice, startTimeFilter, endTimeFilter]);

  // Listen for products for real-time inventory updates
  useEffect(() => {
    const q = query(collection(db, 'products'), limit(2000));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const prods = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) } as Product));
      setProducts(prods);
      
      // Update cache for other components
      dataCache.products['all'] = { data: prods, timestamp: Date.now() };
    }, (err) => {
      console.error('Error listening to products:', err);
    });

    return () => unsubscribe();
  }, [refreshKey]);

  useEffect(() => {
    const searchCustomers = async (term: string) => {
      if (!term || term.length < 2) {
        setCustomers([]);
        return;
      }
      try {
        const q = query(collection(db, 'customers'), orderBy('name'), limit(50));
        const snapshot = await getDocs(q);
        const fetchedCustomers = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) } as Customer));
        setCustomers(fetchedCustomers.filter(c => 
          c.name.toLowerCase().includes(term.toLowerCase()) || 
          c.phone?.includes(term) ||
          c.email?.toLowerCase().includes(term.toLowerCase())
        ));
      } catch (err) {
        console.error('Error searching customers:', err);
      }
    };

    if (customerSearch) {
      const timer = setTimeout(() => searchCustomers(customerSearch), 300);
      return () => clearTimeout(timer);
    } else {
      setCustomers([]);
    }
  }, [customerSearch]);

  const setCartItemQuantity = (product: Product, variant: any | null, quantity: number) => {
    const cartItemId = variant ? `${product.id}-${variant.id}` : product.id;
    
    if (quantity <= 0) {
      setCart(prev => prev.filter(item => (item.cartItemId || item.id) !== cartItemId));
      return;
    }
    
    // Category restriction
    if (cart.length > 0) {
      const firstItem = cart[0];
      if (firstItem.categoryId && firstItem.categoryId !== product.categoryId) {
        toast.error('לא ניתן להזמין מוצרים מקטגוריות שונות באותה הזמנה');
        return;
      }
    }
    
    const originalStock = variant ? variant.stockQuantity : product.stockQuantity;
    const lookupId = variant ? `${product.id}-${variant.id}` : product.id;
    const qtyInOtherCarts = activeCarts[lookupId] || 0;
    const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
    
    const finalQuantity = Math.min(quantity, actualStock);
    if (quantity > actualStock) {
      toast.error(`הכמות המבוקשת חסרה במלאי הפנוי עבור ${variant?.name || product.name}`);
    }

    if (finalQuantity <= 0) {
       return; 
    }

    const existingItemIndex = cart.findIndex(item => (item.cartItemId || item.id) === cartItemId);
    if (existingItemIndex === -1) {
      toast.success('נוסף לסל!');
    }

    setCart(prev => {
      const index = prev.findIndex(item => (item.cartItemId || item.id) === cartItemId);
      if (index >= 0) {
        const newCart = [...prev];
        newCart[index] = { ...newCart[index], quantity: finalQuantity };
        return newCart;
      } else {
        return [...prev, {
          ...product,
          quantity: finalQuantity,
          variantId: variant?.id,
          variantName: variant?.name,
          variantPrice: variant?.price,
          cartItemId
        }];
      }
    });
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(item => (item.cartItemId || item.id) !== cartItemId));
  };

  const updateQuantity = (cartItemId: string, delta: number) => {
    // Find item to check stock before updating
    const item = cart.find(i => (i.cartItemId || i.id) === cartItemId);
    if (item) {
      const originalStock = item.variantId ? (item.variants?.find(v => v.id === item.variantId)?.stockQuantity || 0) : item.stockQuantity;
      const lookupId = item.variantId ? `${item.id}-${item.variantId}` : item.id;
      const qtyInOtherCarts = activeCarts[lookupId] || 0;
      const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
      
      if (delta > 0 && item.quantity >= actualStock) {
        toast.error('הכמות המבוקשת חסרה במלאי הפנוי (יתכן ומוצרים תפוסים בסלים אחרים)');
      }
    }

    setCart(prev => prev.map(item => {
      if ((item.cartItemId || item.id) === cartItemId) {
        const originalStock = item.variantId ? (item.variants?.find(v => v.id === item.variantId)?.stockQuantity || 0) : item.stockQuantity;
        const lookupId = item.variantId ? `${item.id}-${item.variantId}` : item.id;
        const qtyInOtherCarts = activeCarts[lookupId] || 0;
        const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
        const newQty = Math.max(1, Math.min(item.quantity + delta, actualStock));
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const totalAmount = cart.reduce((sum, item) => sum + ((item.variantPrice ?? item.price) * item.quantity), 0);

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingRef.current || isSubmitting) return;
    
    isSubmittingRef.current = true;
    setIsSubmitting(true);
    try {
      const currentUser = auth.currentUser;
      
      // 0. Final Stock Check
      for (const item of cart) {
        const product = products.find(p => p.id === item.id);
        if (!product || product.stockQuantity < item.quantity) {
          toast.error(`המלאי של ${item.name} אזל או פחת. אנא עדכן את הסל.`);
          return;
        }
      }

      // 0.1 Mandatory Sub-Category Check
      const categoriesInCart = Array.from(new Set(cart.map(item => item.categoryId)));
      for (const catId of categoriesInCart) {
        const mandatorySubs = subCategories.filter(s => s.categoryId === catId && s.isMandatoryForParent);
        for (const sub of mandatorySubs) {
          const hasProductFromSub = cart.some(item => item.subCategoryId === sub.id);
          if (!hasProductFromSub) {
            const catName = categories.find(c => c.id === catId)?.name || 'הקטגוריה';
            toast.error(`חובה לבחור לפחות מוצר אחד מתת-הקטגוריה "${sub.name}" עבור ${catName}`);
            return;
          }
        }
      }

      // 0.2 Mandatory Customer Fields Check
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      for (const field of config.customerFormFields) {
        if (field.required && !customer[field.id]) {
          toast.error(`חובה למלא את השדה "${field.label}"`);
          return;
        }
        if (field.type === 'email' && customer[field.id] && !emailRegex.test(customer[field.id])) {
          toast.error(`כתובת המייל בשדה "${field.label}" אינה תקינה`);
          return;
        }
      }

      // 1. Save/Update Customer
      let customerId = 'guest';
      const { id: _, ...customerData } = customer; // Strip id if present
      
      const existingCustomer = customers.find(c => 
        (customer.phone && c.phone === customer.phone) || 
        (customer.email && c.email === customer.email)
      );

      try {
        if (existingCustomer) {
          customerId = existingCustomer.id;
          await updateDoc(doc(db, 'customers', customerId), {
            ...customerData,
            lastPurchase: serverTimestamp()
          });
        } else if (customer.name) {
          const newCust = await addDoc(collection(db, 'customers'), {
            ...customerData,
            createdAt: serverTimestamp(),
            lastPurchase: serverTimestamp()
          });
          customerId = newCust.id;
        }
      } catch (err) {
        handleFirestoreError(err, existingCustomer ? OperationType.UPDATE : OperationType.CREATE, existingCustomer ? `customers/${customerId}` : 'customers');
      }

      // 2. Create Order & Update Stock & Increment Counter (Transaction)
      let finalOrderData: any = null;
      await runTransaction(db, async (transaction) => {
        // --- ALL READS FIRST ---
        
        // Get order counter
        const configDocRef = doc(db, 'config', 'system');
        const configDoc = await transaction.get(configDocRef);
        
        // Group cart items by productId to avoid concurrent overwrites for variants of the same product
        const itemsByProduct = cart.reduce((acc, item) => {
          if (!acc[item.id]) acc[item.id] = [];
          acc[item.id].push(item);
          return acc;
        }, {} as Record<string, typeof cart>);

        // Get all products in cart to check stock
        const productSnapshots: { id: string; doc: any; items: typeof cart }[] = [];
        for (const [productId, items] of Object.entries(itemsByProduct)) {
          const productRef = doc(db, 'products', productId);
          const productDoc = await transaction.get(productRef);
          if (!productDoc.exists()) throw new Error(`Product ${productId} not found`);
          productSnapshots.push({ id: productId, doc: productDoc, items });
        }

        // --- CALCULATIONS & VALIDATIONS ---
        
        let nextOrderNumber = 1000;
        if (configDoc.exists()) {
          const currentCounter = configDoc.data().orderCounter || 1000;
          nextOrderNumber = currentCounter + 1;
        }

        // Validate stock for all grouped items
        const productUpdates: Record<string, any> = {};
        for (const { id, doc, items } of productSnapshots) {
          const productData = doc.data();
          let newStockQuantity = productData.stockQuantity;
          let newVariants = productData.variants ? [...productData.variants] : [];
          
          for (const item of items) {
            if (item.variantId) {
               const vIndex = newVariants.findIndex((v: any) => v.id === item.variantId);
               if (vIndex === -1 || newVariants[vIndex].stockQuantity < item.quantity) {
                 throw new Error(`Not enough stock for ${item.name} - ${item.variantName}`);
               }
               newVariants[vIndex] = { ...newVariants[vIndex], stockQuantity: newVariants[vIndex].stockQuantity - item.quantity };
               // Deduct from parent as well, since parent stock represents the total physical items or is used as a fallback counter
               newStockQuantity -= item.quantity;
            } else {
               if (newStockQuantity < item.quantity) throw new Error(`Not enough stock for ${item.name}`);
               newStockQuantity -= item.quantity;
            }
          }
          
          productUpdates[id] = {
             hasVariantsUpdate: items.some(i => i.variantId),
             hasStockUpdate: true,
             variants: newVariants,
             stockQuantity: newStockQuantity
          };
        }

        // --- ALL WRITES LAST ---
        
        // Increment counter
        transaction.set(configDocRef, { orderCounter: nextOrderNumber }, { merge: true });

        // Create Order
        const orderRef = doc(collection(db, 'orders'));
        const orderData = {
          orderNumber: nextOrderNumber,
          customer: customerData,
          customerId: customerId,
          createdBy: {
            uid: auth.currentUser?.uid || 'guest',
            name: auth.currentUser?.displayName || 'אורח',
            email: auth.currentUser?.email || ''
          },
          items: cart.map(item => ({
            productId: item.id,
            sku: item.sku,
            name: item.name,
            quantity: item.quantity,
            price: item.variantPrice !== undefined ? item.variantPrice : item.price,
            variantId: item.variantId || null,
            variantName: item.variantName || null
          })),
          totalAmount,
          status: 'pending',
          createdAt: serverTimestamp()
        };
        transaction.set(orderRef, orderData);
        finalOrderData = { ...orderData, id: orderRef.id };

        // Update Stock
        for (const { id, doc } of productSnapshots) {
          const updateData: any = {};
          if (productUpdates[id].hasStockUpdate) updateData.stockQuantity = productUpdates[id].stockQuantity;
          if (productUpdates[id].hasVariantsUpdate) updateData.variants = productUpdates[id].variants;
          if (Object.keys(updateData).length > 0) {
             transaction.update(doc.ref, updateData);
          }
        }
      }).catch(err => handleFirestoreError(err, OperationType.WRITE, 'transaction/checkout'));

      // 3. Send Email
      if (finalOrderData && !config.emailSettings?.disableAllEmails) {
        try {
          const emailContent = formatOrderEmail(finalOrderData, config, customer);
          
          // Determine reply-to
          let replyTo: string | undefined;
          if (config.emailSettings?.replyToType === 'fixed') {
            replyTo = config.emailSettings.fixedReplyToEmail;
          }

          // Determine sender info for reply-to if not fixed
          const userEmail = config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.email : config.emailSettings?.mainEmail;
          const userName = config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.displayName : config.siteName;

          // Find the customer's email address from the dynamic form fields
          const emailField = config.customerFormFields?.find(f => f.type === 'email');
          const customerEmail = emailField ? customer[emailField.id] : customer.email;
          
          // DO NOT send to customerEmail anymore as per user request
          
          // Send copy to report email (or main email) if configured
          const reportDestination = config.emailSettings?.reportEmail || config.emailSettings?.mainEmail;
          if (reportDestination && config.emailSettings?.notifyNewOrder !== false) {
            const emailRes = await sendEmail({
              to: reportDestination,
              subject: emailContent.subject,
              html: emailContent.html,
              userEmail: userEmail || undefined,
              userName: userName || undefined,
              replyTo: replyTo || undefined
            });
            if (emailRes.success) {
              try {
                const updateData: any = {
                  emailSent: true,
                  emailSentAt: serverTimestamp(),
                  emailSentTo: reportDestination,
                  emailFailed: false,
                  emailError: null
                };
                if (emailRes.messageId) {
                  updateData.emailMessageId = emailRes.messageId;
                }
                await updateDoc(doc(db, 'orders', finalOrderData.id), updateData);
              } catch (e) {}
            } else {
              const failReason = emailRes.error || (emailRes.reason === 'bad_credentials' ? 'שגיאת אימות שרת דואר (535 Bad Credentials)' : 'שליחת מייל נכשלה בשרת');
              try {
                await updateDoc(doc(db, 'orders', finalOrderData.id), {
                  emailSent: false,
                  emailFailed: true,
                  emailError: failReason,
                  emailFailedAt: serverTimestamp(),
                  emailSentTo: reportDestination
                });
              } catch (e) {}

              const customerDisplayName = (customer?.name || customer?.fullName || (customer ? Object.values(customer)[0] : '') || finalOrderData.customerName || 'לקוח') as string;

              notifyAdminEmailFailure({
                orderId: finalOrderData.id,
                orderNumber: finalOrderData.orderNumber,
                customerName: customerDisplayName,
                error: failReason,
                recipient: reportDestination,
                totalAmount: finalOrderData.totalAmount
              });
            }
          }
        } catch (emailErr: any) {
          console.warn('Failed to send order notification email:', emailErr);
          const errMsg = emailErr?.message || 'שגיאת תקשורת עם שרת הדואר';
          const reportDestination = config.emailSettings?.reportEmail || config.emailSettings?.mainEmail;
          if (finalOrderData?.id) {
            try {
              await updateDoc(doc(db, 'orders', finalOrderData.id), {
                emailSent: false,
                emailFailed: true,
                emailError: errMsg,
                emailFailedAt: serverTimestamp(),
                emailSentTo: reportDestination
              });
            } catch (e) {}
          }

          const customerDisplayName = (customer?.name || customer?.fullName || (customer ? Object.values(customer)[0] : '') || finalOrderData?.customerName || 'לקוח') as string;

          notifyAdminEmailFailure({
            orderId: finalOrderData?.id,
            orderNumber: finalOrderData?.orderNumber,
            customerName: customerDisplayName,
            error: errMsg,
            recipient: reportDestination,
            totalAmount: finalOrderData?.totalAmount
          });
        }
      }

      setLastOrder(finalOrderData);
      setLastCustomer(customer);
      setOrderComplete(true);
      setCart([]);
      setIsCheckoutOpen(false);
      setCustomer({});
    } catch (err) {
      console.error('Checkout error:', err);
      toast.error('אירעה שגיאה בביצוע ההזמנה. אנא נסה שוב.');
    } finally {
      isSubmittingRef.current = false;
      setIsSubmitting(false);
    }
  };

  const clearAllCarts = async () => {
    if (!window.confirm('האם אתה בטוח שברצונך לרוקן את כל הסלים הפעילים של כל המשתמשים?')) return;
    try {
      const snapshot = await getDocs(collection(db, 'active_carts'));
      const deletePromises = snapshot.docs.map(d => deleteDoc(d.ref));
      await Promise.all(deletePromises);
      toast.success('כל הסלים רוקנו בהצלחה');
    } catch (err) {
      console.error('Error clearing all carts:', err);
      toast.error('שגיאה בריקון הסלים');
    }
  };

  const deleteSpecificCart = async (cartId: string) => {
    if (!window.confirm('האם אתה בטוח שברצונך למחוק סל זה?')) return;
    try {
      await deleteDoc(doc(db, 'active_carts', cartId));
      toast.success('הסל נמחק בהצלחה');
    } catch (err) {
      console.error('Error deleting specific cart:', err);
      toast.error('שגיאה במחיקת הסל');
    }
  };

  const getStockColor = (qty: number) => {
    if (qty < 20) return 'text-red-500';
    if (qty <= 50) return 'text-orange-500';
    return 'text-emerald-500';
  };


  const clearCache = () => {
    dataCache.categories = null;
    dataCache.subCategories = null;
    dataCache.config = null;
    dataCache.products = {};
    dataCache.lastFetch = 0;
    setRefreshKey(prev => prev + 1);
    toast.success('הזיכרון המטמון נוקה');
  };

  const filteredProducts = products
    .filter(p => {
      // Role-based filtering for partial users
      if (userRole === 'partial_user') {
        if (!allowedCategories || !allowedCategories.includes(p.categoryId)) return false;
      }

      const matchesCategory = selectedCategory === 'all' || p.categoryId === selectedCategory;
      const matchesSubCategory = selectedSubCategory === 'all' || p.subCategoryId === selectedSubCategory;
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.sku.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesPrice = (minPrice === '' || p.price >= minPrice) && (maxPrice === '' || p.price <= maxPrice);
      
      const sub = subCategories.find(s => s.id === p.subCategoryId);
      const pStart = p.startTime || sub?.startTime;
      const pEnd = p.endTime || sub?.endTime;
      
      let matchesHours = true;
      if (startTimeFilter || endTimeFilter) {
        if (!pStart || !pEnd) {
          matchesHours = false;
        } else {
          // Overlap check: product starts before filter ends AND product ends after filter starts
          const startLimit = startTimeFilter || '00:00';
          const endLimit = endTimeFilter || '23:59';
          matchesHours = pStart <= endLimit && pEnd >= startLimit;
        }
      }

      return matchesCategory && matchesSubCategory && matchesSearch && matchesPrice && matchesHours;
    })
    .sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'price') {
        comparison = a.price - b.price;
      } else if (sortBy === 'stock') {
        comparison = a.stockQuantity - b.stockQuantity;
      } else {
        comparison = a.name.localeCompare(b.name, 'he');
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });

  if (categories.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-zinc-50 p-4 text-center" dir="rtl">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full border border-zinc-100">
          <ShoppingBag size={48} className="mx-auto text-zinc-300 mb-4" />
          <h2 className="text-2xl font-bold text-zinc-800 mb-2">החנות ריקה</h2>
          <p className="text-zinc-500 mb-6">לא נמצאו קטגוריות או מוצרים במערכת. אם אתה מנהל, אנא הוסף קטגוריות ומוצרים בדף ניהול המוצרים.</p>
          {isAdmin && (
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('change-tab', { detail: 'inventory' }))}
              className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20"
            >
              עבור לניהול מוצרים
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-50 font-sans text-right" dir="rtl">
      {/* Header */}
      <header className="bg-white border-b border-zinc-200 sticky top-0 z-30">
        <div className="max-w-[1600px] mx-auto px-4 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 text-zinc-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-colors hidden md:block"
              title="תפריט קטגוריות"
            >
              {isSidebarOpen ? <PanelRightClose size={24} /> : <PanelRightOpen size={24} />}
            </button>
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <ShoppingBag size={24} />
            </div>
            <h1 className="text-xl font-bold text-zinc-900">חנות המוצרים</h1>
            {isAdmin && (
              <div className="flex items-center gap-2">
                <button
                  onClick={clearCache}
                  className="p-2 text-zinc-400 hover:text-indigo-600 transition-colors"
                  title="נקה זיכרון מטמון"
                >
                  <RefreshCcw size={18} />
                </button>
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => {
                const cacheKey = searchTerm ? `search_${searchTerm}` : `cat_${selectedCategory}`;
                if (dataCache.products[cacheKey]) dataCache.products[cacheKey].timestamp = 0;
                setRefreshKey(prev => prev + 1);
                toast.success('מרענן נתונים...');
              }}
              className="p-2 text-zinc-400 hover:text-indigo-600 transition-colors"
              title="רענן מוצרים"
            >
              <RefreshCcw size={20} />
            </button>
            {isAdmin && (
              <button
                onClick={() => setShowActiveCartsModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-amber-50 text-amber-600 rounded-xl text-sm font-bold border border-amber-100 hover:bg-amber-100 transition-all"
              >
                <ShoppingCart size={18} />
                סלים פעילים ({allActiveCarts.length})
              </button>
            )}
            {(userRole === 'user' && !isAdmin) && onNavigate && (
              <button
                onClick={() => onNavigate('orders')}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-xl text-sm font-bold border border-indigo-100 hover:bg-indigo-100 transition-all"
              >
                <ClipboardList size={18} />
                הזמנות שלי
              </button>
            )}
            <div className="relative hidden md:block w-64">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
              <input
                type="text"
                placeholder="חיפוש מוצרים..."
                className="w-full pr-10 pl-4 py-2.5 bg-zinc-100 border-transparent rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm"
                value={searchTerm || ''}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar Categories */}
            {isSidebarOpen && (
              <aside className="w-full md:w-64 space-y-8 shrink-0">
              <div>
                <h3 className="text-sm font-bold text-zinc-400 uppercase tracking-wider mb-4">קטגוריות</h3>
                <div className="space-y-1">
                  <button
                    onClick={() => { setSelectedCategory('all'); setSelectedSubCategory('all'); }}
                    className={`w-full text-right px-4 py-3 rounded-xl font-medium transition-all flex items-center justify-between ${selectedCategory === 'all' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-zinc-600 hover:bg-zinc-200'}`}
                  >
                    הכל
                    <ChevronLeft size={16} className={selectedCategory === 'all' ? 'opacity-100' : 'opacity-0'} />
                  </button>
                  {categories
                    .filter(cat => {
                      if (userRole === 'partial_user') {
                        return allowedCategories?.includes(cat.id);
                      }
                      return true;
                    })
                    .map(cat => (
                    <div key={cat.id} className="space-y-1">
                      <button
                        onClick={() => { setSelectedCategory(cat.id); setSelectedSubCategory('all'); }}
                        className={`w-full text-right px-4 py-3 rounded-xl font-medium transition-all flex items-center justify-between ${selectedCategory === cat.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-zinc-600 hover:bg-zinc-200'}`}
                      >
                        <span className="flex items-center gap-2">
                          {cat.name}
                        </span>
                        <ChevronLeft size={16} className={selectedCategory === cat.id ? 'opacity-100' : 'opacity-0'} />
                      </button>
                      
                      {/* Sub-categories */}
                      {selectedCategory === cat.id && (
                        <div className="mr-4 space-y-1 border-r-2 border-zinc-100 pr-2">
                          <button
                            onClick={() => setSelectedSubCategory('all')}
                            className={`w-full text-right px-3 py-2 rounded-lg text-sm font-medium transition-all ${selectedSubCategory === 'all' ? 'text-indigo-600 bg-indigo-50' : 'text-zinc-500 hover:bg-zinc-100'}`}
                          >
                            הכל ב{cat.name}
                          </button>
                          {subCategories.filter(sub => sub.categoryId === cat.id).map(sub => (
                            <button
                              key={sub.id}
                              onClick={() => setSelectedSubCategory(sub.id)}
                              className={`w-full text-right px-3 py-2 rounded-lg text-sm font-medium transition-all ${selectedSubCategory === sub.id ? 'text-indigo-600 bg-indigo-50' : 'text-zinc-500 hover:bg-zinc-100'}`}
                            >
                              {sub.name}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </aside>
            )}

            {/* Products Grid */}
            <div className="flex-1">
              {/* Sorting and Filtering UI */}
              <div className="mb-8 bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
                <div className="p-6 space-y-6">
                  {/* Top Row: Sorting & Results */}
                  <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-zinc-100">
                    <div className="flex items-center gap-6">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-zinc-100 rounded-lg text-zinc-500">
                          <Filter size={18} />
                        </div>
                        <div>
                          <span className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">מיון מוצרים</span>
                          <div className="flex items-center gap-2">
                            <select 
                              className="bg-transparent border-none p-0 text-sm font-bold text-zinc-900 focus:ring-0 outline-none cursor-pointer"
                              value={sortBy}
                              onChange={(e) => setSortBy(e.target.value as any)}
                            >
                              <option value="name">לפי שם</option>
                              <option value="price">לפי מחיר</option>
                              <option value="stock">לפי מלאי</option>
                            </select>
                            <button 
                              onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                              className="p-1 hover:bg-zinc-100 rounded-md transition-all text-zinc-400 hover:text-indigo-600"
                              title={sortOrder === 'asc' ? 'סדר עולה' : 'סדר יורד'}
                            >
                              {sortOrder === 'asc' ? <Plus size={14} /> : <Minus size={14} />}
                            </button>
                          </div>
                        </div>
                      </div>
                      
                      {/* View options */}
                      <div className="flex items-center gap-3 border-r border-zinc-200 pr-6">
                        <div className="p-2 bg-zinc-100 rounded-lg text-zinc-500">
                          <Grid size={18} />
                        </div>
                        <div>
                          <span className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">תצוגה</span>
                          <select 
                            className="bg-transparent border-none p-0 text-sm font-bold text-zinc-900 focus:ring-0 outline-none cursor-pointer"
                            value={gridCols}
                            onChange={(e) => {
                              const cols = parseInt(e.target.value, 10);
                              setGridCols(cols);
                              localStorage.setItem('shop_grid_cols', cols.toString());
                            }}
                          >
                            <option value={2}>2 בשורה</option>
                            <option value={3}>3 בשורה</option>
                            <option value={4}>4 בשורה</option>
                            <option value={5}>5 בשורה</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div className="px-4 py-2 bg-indigo-50 rounded-xl text-indigo-600 text-xs font-bold border border-indigo-100">
                      {filteredProducts.length} מוצרים נמצאו
                    </div>
                  </div>

                  {/* Bottom Row: Filters */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end">
                    {/* Price Filter */}
                    <div className="lg:col-span-5 space-y-3">
                      <div className="flex items-center gap-2 text-zinc-400">
                        <CreditCard size={14} />
                        <span className="text-[10px] font-bold uppercase tracking-wider">סינון לפי מחיר</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="relative flex-1">
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 text-xs">₪</span>
                          <input
                            type="number"
                            placeholder="מינימום"
                            className="w-full pr-8 pl-3 py-2.5 bg-zinc-50 border border-zinc-100 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                            value={minPrice}
                            onChange={(e) => setMinPrice(e.target.value === '' ? '' : Number(e.target.value))}
                          />
                        </div>
                        <div className="w-4 h-px bg-zinc-200" />
                        <div className="relative flex-1">
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 text-xs">₪</span>
                          <input
                            type="number"
                            placeholder="מקסימום"
                            className="w-full pr-8 pl-3 py-2.5 bg-zinc-50 border border-zinc-100 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                            value={maxPrice}
                            onChange={(e) => setMaxPrice(e.target.value === '' ? '' : Number(e.target.value))}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Time Filter */}
                    <div className="lg:col-span-5 space-y-3">
                      <div className="flex items-center gap-2 text-zinc-400">
                        <Clock size={14} />
                        <span className="text-[10px] font-bold uppercase tracking-wider">סינון לפי שעות פעילות</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex-1">
                          <input
                            type="time"
                            className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-100 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                            value={startTimeFilter}
                            onChange={(e) => setStartTimeFilter(e.target.value)}
                          />
                        </div>
                        <div className="w-4 h-px bg-zinc-200" />
                        <div className="flex-1">
                          <input
                            type="time"
                            className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-100 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                            value={endTimeFilter}
                            onChange={(e) => setEndTimeFilter(e.target.value)}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Reset Button */}
                    <div className="lg:col-span-2">
                      <button
                        onClick={() => {
                          setMinPrice('');
                          setMaxPrice('');
                          setStartTimeFilter('');
                          setEndTimeFilter('');
                          setSearchTerm('');
                          setSelectedCategory('all');
                          setSelectedSubCategory('all');
                        }}
                        className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-zinc-50 hover:bg-red-50 text-zinc-500 hover:text-red-600 rounded-xl text-xs font-bold transition-all border border-zinc-100 hover:border-red-100"
                      >
                        <X size={14} />
                        איפוס
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className={`grid gap-6 auto-rows-fr ${
                gridCols === 2 ? 'grid-cols-1 sm:grid-cols-2' :
                gridCols === 3 ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3' :
                gridCols === 4 ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' :
                'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5'
              }`}>
                {filteredProducts.slice(0, visibleCount).map(product => (
                  <motion.div
                    layout
                    key={product.id}
                    className="bg-white rounded-3xl border border-zinc-200 overflow-hidden hover:shadow-xl transition-all group flex flex-col h-full"
                  >
                    <div className="aspect-square bg-zinc-100 relative overflow-hidden">
                      {product.image ? (
                        <img 
                          src={product.image} 
                          alt={product.name} 
                          loading="lazy"
                          className="w-full h-full object-contain p-2 group-hover:scale-110 transition-transform duration-500" 
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                            const fallback = target.nextElementSibling;
                            if (fallback) fallback.classList.remove('hidden');
                          }}
                        />
                      ) : null}
                      <div className={`w-full h-full flex items-center justify-center text-zinc-300 ${product.image ? 'hidden fallback' : ''}`}>
                        {config?.logoUrl ? (
                          <img 
                            src={config.logoUrl} 
                            alt={product.name}
                            className="w-full h-full object-contain p-4 opacity-50 grayscale hover:grayscale-0 transition-all duration-300"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <ShoppingBag size={48} />
                        )}
                      </div>
                      <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-[10px] font-bold text-zinc-600 border border-zinc-200 uppercase tracking-wider">
                        {product.sku}
                      </div>
                    </div>
                    <div className="p-6 flex-1 flex flex-col">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-lg text-zinc-900">{product.name}</h3>
                        <div className="text-right">
                          <span className="text-indigo-600 font-bold text-xl block">
                            {(() => {
                              const vId = selectedVariants[product.id];
                              if (vId && product.variants?.length > 0) {
                                const v = product.variants.find(v => v.id === vId);
                                if (v) return `₪${v.price}`;
                              }
                              return `₪${product.price}`;
                            })()}
                          </span>
                          {(() => {
                              if (product.variants && product.variants.length > 0) return null;
                              const originalStock = product.stockQuantity || 0;
                              const qtyInOtherCarts = activeCarts[product.id] || 0;
                              const qtyInMyCart = cart.filter(item => item.id === product.id).reduce((sum, item) => sum + item.quantity, 0);
                              const actualStock = Math.max(0, originalStock - qtyInOtherCarts - qtyInMyCart);
                              
                              return (
                                <span className={`text-xs font-bold block mt-1 ${getStockColor(actualStock)}`}>
                                  {actualStock <= 0 ? (
                                    <span className="text-red-500">אזל מהמלאי הפנוי</span>
                                  ) : (
                                    `מלאי זמין להוספה: ${actualStock}`
                                  )}
                                  {product.reservedQuantity > 0 && (
                                    <span className="text-amber-600 mr-1">({product.reservedQuantity} משוריין)</span>
                                  )}
                                  {qtyInOtherCarts > 0 && (
                                    <span className="text-zinc-400 mr-1 text-[10px]">({qtyInOtherCarts} בסלים אחרים)</span>
                                  )}
                                  {qtyInMyCart > 0 && (
                                    <span className="text-indigo-500 mr-1 text-[10px]">({qtyInMyCart} בסל שלך)</span>
                                  )}
                                </span>
                              );
                          })()}
                        </div>
                      </div>
                      <p className="text-zinc-500 text-sm line-clamp-2 mb-4">{product.description || 'אין תיאור למוצר זה'}</p>
                      
                                            {product.variants && product.variants.length > 0 && (
                        <div className="mb-4 space-y-2">
                          <label className="block text-xs font-bold text-zinc-700 mb-2">בחר כמויות לתתי-מוצרים (אפשר לבחור כמה ביחד):</label>
                          {product.variants.map(v => {
                             const lookupId = `${product.id}-${v.id}`;
                             const qtyInOtherCarts = activeCarts[lookupId] || 0;
                             const qtyInMyCart = cart.find(item => item.id === product.id && item.variantId === v.id)?.quantity || 0;
                             const actualStock = Math.max(0, v.stockQuantity - qtyInOtherCarts - qtyInMyCart);
                             const isOutOfStock = actualStock <= 0;
                             const qtyKey = `${product.id}-${v.id}`;
                             const currentQty = qtyInMyCart;
                             
                             return (
                               <div key={v.id} className={`flex items-center justify-between p-2 rounded-lg border ${currentQty > 0 ? 'border-indigo-500 bg-indigo-50' : 'border-zinc-200 bg-zinc-50'}`}>
                                 <div className="flex-1">
                                    <div className="text-sm font-bold text-zinc-900">{v.name} - ₪{v.price}</div>
                                    <div className="text-[10px] text-zinc-500">
                                       {isOutOfStock ? <span className="text-red-500">אזל מהמלאי הפנוי</span> : `מלאי זמין להוספה: ${actualStock}`}
                                       {qtyInOtherCarts > 0 && <span className="mr-1">(${qtyInOtherCarts} בסלים אחרים)</span>}
                                       {qtyInMyCart > 0 && <span className="mr-1 text-indigo-500">({qtyInMyCart} בסל שלך)</span>}
                                    </div>
                                 </div>
                                 <div className="flex items-center gap-2 bg-white rounded-lg border border-zinc-200 p-1">
                                    <button 
                                      disabled={currentQty <= 0}
                                      onClick={() => setCartItemQuantity(product, v, Math.max(0, currentQty - 1))}
                                      className="p-1 text-zinc-400 hover:text-indigo-600 disabled:opacity-50"
                                    >
                                      <Minus size={14} />
                                    </button>
                                    <input 
                                      type="number"
                                      className="w-8 text-center bg-transparent font-bold text-zinc-900 outline-none text-sm"
                                      value={currentQty}
                                      min="0"
                                      onChange={(e) => {
                                        const val = parseInt(e.target.value);
                                        if (!isNaN(val)) {
                                          const maxAllowed = currentQty + actualStock;
                                          if (val > maxAllowed) {
                                            toast.error('הכמות המבוקשת חסרה במלאי הפנוי');
                                          }
                                          setCartItemQuantity(product, v, Math.max(0, Math.min(val, maxAllowed)));
                                        }
                                      }}
                                    />
                                    <button 
                                      disabled={actualStock <= 0}
                                      onClick={() => setCartItemQuantity(product, v, currentQty + 1)}
                                      className="p-1 text-zinc-400 hover:text-indigo-600 disabled:opacity-50"
                                    >
                                      <Plus size={14} />
                                    </button>
                                 </div>
                               </div>
                             );
                          })}
                        </div>
                      )}
                      
                      {product.subCategoryId && subCategories.find(s => s.id === product.subCategoryId) && (
                        <div className="mb-4 p-3 bg-indigo-50 rounded-xl border border-indigo-100 space-y-2">
                          {(() => {
                            const sub = subCategories.find(s => s.id === product.subCategoryId);
                            const startTime = product.startTime || sub?.startTime;
                            const endTime = product.endTime || sub?.endTime;
                            const duration = product.duration || sub?.duration;
                            const mapsUrl = sub?.googleMapsUrl;

                            return (
                              <>
                                {(startTime || endTime) && (
                                  <div className="flex items-center gap-2 text-xs text-indigo-700 font-bold">
                                    <Clock size={14} />
                                    <span>פעילות: {startTime || '--:--'} - {endTime || '--:--'}</span>
                                  </div>
                                )}
                                {duration && (
                                  <div className="flex items-center gap-2 text-xs text-indigo-700 font-bold">
                                    <Timer size={14} />
                                    <span>משך זמן: {duration}</span>
                                  </div>
                                )}
                                {mapsUrl && (
                                  <a 
                                    href={mapsUrl} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="flex items-center gap-2 text-xs text-indigo-600 hover:text-indigo-800 font-bold underline"
                                  >
                                    <MapPin size={14} />
                                    <span>פתח ב-Google Maps</span>
                                  </a>
                                )}
                              </>
                            );
                          })()}
                        </div>
                      )}

                      <div className="space-y-3 mt-auto">
                        {cart.some(item => item.id === product.id) && (
                          <div className="flex items-center gap-1 text-emerald-600 text-[10px] font-bold mb-1">
                            <Check size={12} />
                            כבר בסל שלך
                          </div>
                        )}
                        
                        {/* Only show single quantity selector if NO variants */}
                        {(!product.variants || product.variants.length === 0) && (() => {
                          const qtyInMyCart = cart.find(item => item.id === product.id)?.quantity || 0;
                          const actualStock = Math.max(0, product.stockQuantity - (activeCarts[product.id] || 0) - qtyInMyCart);
                          
                          if (qtyInMyCart > 0) {
                            return (
                              <div className="flex gap-3">
                                <div className="flex items-center gap-4 bg-zinc-50 p-2 rounded-xl border border-zinc-100 flex-1 justify-center">
                                  <button 
                                    onClick={() => setCartItemQuantity(product, null, Math.max(0, qtyInMyCart - 1))}
                                    className="p-1 text-zinc-400 hover:text-indigo-600"
                                  >
                                    <Minus size={16} />
                                  </button>
                                  <input 
                                    type="number"
                                    className="w-12 text-center bg-transparent font-bold text-zinc-900 outline-none"
                                    value={qtyInMyCart}
                                    min="0"
                                    onChange={(e) => {
                                      const val = parseInt(e.target.value);
                                      if (!isNaN(val)) {
                                        const maxAllowed = qtyInMyCart + actualStock;
                                        if (val > maxAllowed) toast.error('הכמות המבוקשת חסרה במלאי הפנוי');
                                        setCartItemQuantity(product, null, Math.max(0, Math.min(val, maxAllowed)));
                                      }
                                    }}
                                  />
                                  <button 
                                    onClick={() => {
                                      if (actualStock <= 0) toast.error('הכמות המבוקשת חסרה במלאי הפנוי');
                                      else setCartItemQuantity(product, null, qtyInMyCart + 1);
                                    }}
                                    className="p-1 text-zinc-400 hover:text-indigo-600"
                                  >
                                    <Plus size={16} />
                                  </button>
                                </div>
                                <button
                                  onClick={() => setIsCartOpen(true)}
                                  className="flex-1 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-500/20"
                                >
                                  <ShoppingBag size={18} />
                                  עבור לסל
                                </button>
                              </div>
                            );
                          }
                          
                          return null;
                        })()}

                        {(() => {
                          if (product.variants?.length > 0) {
                             const totalInCart = product.variants.reduce((sum, v) => sum + (cart.find(i => i.id === product.id && i.variantId === v.id)?.quantity || 0), 0);
                             const allOutOfStock = product.variants.every(v => {
                               const qtyInMyCart = cart.find(item => item.id === product.id && item.variantId === v.id)?.quantity || 0;
                               return Math.max(0, v.stockQuantity - (activeCarts[`${product.id}-${v.id}`] || 0) - qtyInMyCart) <= 0;
                             });
                             return (
                                <button
                                  disabled={allOutOfStock && totalInCart === 0}
                                  onClick={() => totalInCart > 0 ? setIsCartOpen(true) : null}
                                  className={`w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 ${totalInCart > 0 ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-500/20' : !allOutOfStock ? 'bg-zinc-100 text-zinc-400 cursor-default' : 'bg-zinc-100 text-zinc-400 cursor-not-allowed'}`}
                                >
                                  <ShoppingBag size={20} />
                                  {allOutOfStock && totalInCart === 0 ? 'אזל מהמלאי' : totalInCart > 0 ? `עבור לסל (${totalInCart} פריטים)` : 'בחר כמויות להוספה'}
                                </button>
                             );
                          } else {
                             const qtyInMyCart = cart.find(item => item.id === product.id)?.quantity || 0;
                             if (qtyInMyCart > 0) return null; // Handled above
                             
                             const actualStock = Math.max(0, product.stockQuantity - (activeCarts[product.id] || 0) - qtyInMyCart);
                             const isOutOfStock = actualStock <= 0;
                             return (
                                <button
                                  disabled={isOutOfStock}
                                  onClick={() => setCartItemQuantity(product, null, 1)}
                                  className={`w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 ${!isOutOfStock ? 'bg-zinc-900 text-white hover:bg-black shadow-lg shadow-black/10' : 'bg-zinc-100 text-zinc-400 cursor-not-allowed'}`}
                                >
                                  <ShoppingBag size={20} />
                                  {isOutOfStock ? 'אזל מהמלאי' : 'הוסף לסל'}
                                </button>
                             );
                          }
                        })()}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
              
              {visibleCount < filteredProducts.length && (
                <div className="mt-12 flex justify-center">
                  <button
                    onClick={() => setVisibleCount(prev => prev + 20)}
                    className="px-8 py-3 bg-white border border-zinc-200 rounded-xl text-zinc-600 font-bold hover:bg-zinc-50 transition-colors shadow-sm"
                  >
                    טען עוד מוצרים
                  </button>
                </div>
              )}
            </div>
          </div>
      </main>

      {/* Floating Cart Button */}
      <div className="fixed bottom-8 left-8 z-50">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsCartOpen(true)}
          className="relative w-16 h-16 bg-indigo-600 text-white rounded-full shadow-2xl shadow-indigo-500/40 flex items-center justify-center group overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
          <ShoppingCart size={28} />
          {cart.length > 0 && (
            <span className="absolute top-3 right-3 bg-red-500 text-white text-[10px] font-bold w-6 h-6 rounded-full flex items-center justify-center border-2 border-indigo-600 animate-bounce">
              {cart.length}
            </span>
          )}
        </motion.button>
      </div>

      {/* Cart Drawer */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="absolute top-0 right-0 h-full w-full max-w-md bg-white shadow-2xl flex flex-col"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                <div className="flex items-center gap-3">
                  <ShoppingCart size={24} className="text-indigo-600" />
                  <h2 className="text-xl font-bold text-zinc-900">סל הקניות</h2>
                </div>
                <button onClick={() => setIsCartOpen(false)} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-zinc-400 gap-4">
                    <ShoppingBag size={64} strokeWidth={1} />
                    <p className="text-lg font-medium">הסל שלך ריק</p>
                  </div>
                ) : (
                  cart.map(item => (
                    <div key={item.cartItemId || item.id} className="flex gap-4 group">
                      <div className="w-20 h-20 bg-zinc-100 rounded-2xl overflow-hidden flex-shrink-0 border border-zinc-200">
                        {item.image ? <img src={item.image} loading="lazy" className="w-full h-full object-contain p-1" referrerPolicy="no-referrer" /> : <div className="w-full h-full flex items-center justify-center text-zinc-300"><ShoppingBag size={24} /></div>}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start mb-1">
                          <h4 className="font-bold text-zinc-900 truncate">{item.name}{item.variantName ? ` - ${item.variantName}` : ""}</h4>
                          <button onClick={() => removeFromCart(item.cartItemId || item.id)} className="text-zinc-300 hover:text-red-500 transition-colors"><X size={18} /></button>
                        </div>
                        <p className="text-xs text-zinc-400 mb-1">מק"ט: {item.sku}</p>
                        <p className="text-[10px] text-zinc-500 mb-1">
                          {categories.find(c => c.id === item.categoryId)?.name || 'ללא קטגוריה'} 
                          {item.subCategoryId && ` > ${subCategories.find(s => s.id === item.subCategoryId)?.name || ''}`}
                        </p>
                        {(() => {
  const originalStock = item.variantId ? (item.variants?.find(v=>v.id===item.variantId)?.stockQuantity || 0) : item.stockQuantity;
  const lookupId = item.variantId ? `${item.id}-${item.variantId}` : item.id;
  const qtyInOtherCarts = activeCarts[lookupId] || 0;
  const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
  return (
    <p className={`text-xs font-bold mb-2 ${getStockColor(actualStock)}`}>
      מלאי פנוי: {actualStock} 
      {qtyInOtherCarts > 0 && <span className="text-zinc-400 font-normal mr-1 text-[10px]">({qtyInOtherCarts} בסלים אחרים)</span>}
    </p>
  );
})()}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center bg-zinc-100 rounded-lg p-1">
                            <button onClick={() => updateQuantity(item.cartItemId || item.id, -1)} className="p-1 hover:bg-white rounded-md transition-colors"><Minus size={14} /></button>
                            <input 
                              type="number"
                              className="w-10 text-center bg-transparent text-sm font-bold outline-none"
                              value={item.quantity || 1}
                              min="1"
                              onChange={(e) => {
                                const val = parseInt(e.target.value);
                                if (!isNaN(val)) {
                                  const originalStock = item.variantId ? (item.variants?.find(v => v.id === item.variantId)?.stockQuantity || 0) : item.stockQuantity;
                                  const lookupId = item.variantId ? `${item.id}-${item.variantId}` : item.id;
                                  const qtyInOtherCarts = activeCarts[lookupId] || 0;
                                  const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
                                  
                                  if (val > actualStock) {
                                    toast.error('הכמות המבוקשת חסרה במלאי הפנוי (יתכן ומוצרים תפוסים בסלים אחרים)');
                                  }
                                  const newQty = Math.max(1, Math.min(val, actualStock));
                                  setCart(prev => prev.map(p => (p.cartItemId || p.id) === (item.cartItemId || item.id) ? { ...p, quantity: newQty } : p));
                                }
                              }}
                            />
                            <button onClick={() => updateQuantity(item.cartItemId || item.id, 1)} className="p-1 hover:bg-white rounded-md transition-colors"><Plus size={14} /></button>
                          </div>
                          <span className="font-bold text-indigo-600">₪{(item.variantPrice !== undefined ? item.variantPrice : item.price) * item.quantity}</span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {cart.length > 0 && (
                <div className="p-6 border-t border-zinc-100 bg-zinc-50 space-y-4">
                  <div className="flex justify-between items-center text-lg">
                    <span className="text-zinc-500">סה"כ לתשלום:</span>
                    <span className="text-2xl font-bold text-zinc-900">₪{totalAmount}</span>
                  </div>
                  <button
                    onClick={() => { setIsCartOpen(false); setIsCheckoutOpen(true); }}
                    className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
                  >
                    <CreditCard size={20} />
                    המשך לתשלום
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Checkout Modal */}
      <AnimatePresence>
        {isCheckoutOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCheckoutOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50 shrink-0">
                <h3 className="text-xl font-bold text-zinc-900">{config.customerFormTitle}</h3>
                <button onClick={() => setIsCheckoutOpen(false)} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
              </div>
              <div className="overflow-y-auto overflow-x-hidden flex-1">
                <form onSubmit={handleCheckout} className="p-8">
                {/* Customer Search */}
                <div className="mb-8 relative">
                  <label className="block text-sm font-semibold text-zinc-700 mb-2">חיפוש לקוח קיים</label>
                  <div className="relative">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                    <input
                      type="text"
                      placeholder="חפש לפי שם או טלפון..."
                      className="w-full pr-10 pl-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                      value={customerSearch || ''}
                      onChange={(e) => {
                        setCustomerSearch(e.target.value);
                        setShowCustomerResults(true);
                      }}
                      onFocus={() => setShowCustomerResults(true)}
                    />
                  </div>
                  
                  {showCustomerResults && customerSearch && (
                    <div className="absolute z-10 w-full mt-2 bg-white border border-zinc-200 rounded-2xl shadow-xl overflow-hidden max-h-48 overflow-y-auto">
                      {customers
                        .filter(c => c.name.includes(customerSearch) || c.phone?.includes(customerSearch))
                        .map(c => (
                          <button
                            key={c.id}
                            type="button"
                            className="w-full text-right px-4 py-3 hover:bg-zinc-50 transition-colors border-b border-zinc-100 last:border-0"
                            onClick={() => {
                              setCustomer({
                                name: c.name,
                                associationName: c.associationName || '',
                                contactPerson: c.contactPerson || '',
                                phone: c.phone || '',
                                email: c.email || '',
                                address: c.address || ''
                              });
                              setCustomerSearch(c.name);
                              setShowCustomerResults(false);
                            }}
                          >
                            <p className="font-bold text-zinc-900">{c.name}</p>
                            <p className="text-xs text-zinc-500">{c.phone}</p>
                          </button>
                        ))}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  {config.customerFormFields.map(field => (
                    <div key={field.id} className="space-y-1">
                      <label className="block text-sm font-semibold text-zinc-700">
                        {field.label} {field.required && <span className="text-red-500">*</span>}
                      </label>
                      {field.type === 'select' ? (
                        <select
                          required={field.required}
                          className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                          value={customer[field.id] || ''}
                          onChange={e => setCustomer({...customer, [field.id]: e.target.value})}
                        >
                          <option value="">בחר {field.label}</option>
                          {field.options?.map(opt => (
                            <option key={opt} value={opt}>{opt}</option>
                          ))}
                        </select>
                      ) : (
                        <input
                          required={field.required}
                          type={field.type}
                          className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                          value={customer[field.id] || ''}
                          onChange={e => setCustomer({...customer, [field.id]: e.target.value})}
                        />
                      )}
                    </div>
                  ))}
                </div>

                <div className="bg-zinc-50 p-6 rounded-2xl border border-zinc-100 mb-8">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-zinc-500">מספר פריטים:</span>
                    <span className="font-bold">{cart.reduce((s, i) => s + i.quantity, 0)}</span>
                  </div>
                  <div className="flex justify-between items-center text-xl font-bold text-zinc-900">
                    <span>סה"כ לתשלום:</span>
                    <span className="text-indigo-600">₪{totalAmount}</span>
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className={`w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 shadow-lg ${isSubmitting ? 'bg-zinc-400 cursor-not-allowed' : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-500/20'}`}
                >
                  {isSubmitting ? <Loader2 className="animate-spin" size={20} /> : <CheckCircle2 size={20} />}
                  {isSubmitting ? 'מעבד הזמנה...' : 'אשר הזמנה'}
                </button>
              </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Success Modal */}
      <AnimatePresence>
        {orderComplete && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative bg-white rounded-3xl shadow-2xl p-10 max-w-md w-full text-center"
            >
              <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 size={48} />
              </div>
              <h3 className="text-2xl font-bold text-zinc-900 mb-2">ההזמנה התקבלה!</h3>
              <p className="text-zinc-500 mb-4">תודה רבה על רכישתך. ניצור איתך קשר בהקדם לתיאום המשלוח.</p>
              
              {lastCustomer?.email && !config.emailSettings?.disableAllEmails && (
                <div className="bg-green-50 text-green-700 p-4 rounded-2xl border border-green-100 mb-6 flex items-center gap-3 text-sm font-bold text-right" dir="rtl">
                  <Mail size={20} className="shrink-0 text-green-600" />
                  <p>ההזמנה נשלחה לדוא"ל שרשמתם בטופס ההזמנה: <span className="font-mono">{lastCustomer.email}</span></p>
                </div>
              )}

              <div className="space-y-3">
                <button
                  onClick={() => {
                    setOrderComplete(false);
                    setShowExtraEmailInput(false);
                    setExtraEmail('');
                  }}
                  className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold hover:bg-black transition-all flex items-center justify-center gap-2"
                >
                  <Check size={20} />
                  אישור
                </button>
                
                {!config.emailSettings?.disableAllEmails && (
                  !showExtraEmailInput ? (
                    <button
                      onClick={() => setShowExtraEmailInput(true)}
                      className="w-full bg-white text-zinc-600 py-3 rounded-2xl font-bold hover:bg-zinc-50 transition-all border border-zinc-200 flex items-center justify-center gap-2"
                    >
                      <Send size={18} />
                      שליחה למייל נוסף
                    </button>
                  ) : (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-2"
                    >
                      <input 
                        type="email"
                        placeholder="הכנס כתובת מייל נוספת..."
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-left"
                        dir="ltr"
                        value={extraEmail}
                        onChange={(e) => setExtraEmail(e.target.value)}
                      />
                      <div className="flex gap-2">
                        <button
                          disabled={sendingEmail || !extraEmail}
                          onClick={async () => {
                            if (!extraEmail) return;
                            setSendingEmail(true);
                            try {
                              const emailContent = formatOrderEmail(lastOrder, config, lastCustomer);
                              
                              // Determine reply-to
                              let replyTo: string | undefined;
                              if (config.emailSettings?.replyToType === 'fixed') {
                                replyTo = config.emailSettings.fixedReplyToEmail;
                              }

                              // Determine sender info for reply-to if not fixed
                              const userEmail = config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.email : config.emailSettings?.mainEmail;
                              const userName = config.emailSettings?.senderChoice === 'user' ? auth.currentUser?.displayName : config.siteName;

                              await sendEmail({
                                to: extraEmail,
                                subject: emailContent.subject,
                                html: emailContent.html,
                                userEmail: userEmail || undefined,
                                userName: userName || undefined,
                                replyTo: replyTo || undefined
                              });
                              toast.success('ההזמנה נשלחה בהצלחה למייל הנוסף');
                              setExtraEmail('');
                              setShowExtraEmailInput(false);
                            } catch (err) {
                              toast.error('שגיאה בשליחת המייל');
                            } finally {
                              setSendingEmail(false);
                            }
                          }}
                          className="flex-1 bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                        >
                          {sendingEmail ? <Loader2 className="animate-spin" size={18} /> : <Send size={18} />}
                          שלח
                        </button>
                        <button
                          onClick={() => setShowExtraEmailInput(false)}
                          className="px-4 py-3 bg-zinc-100 text-zinc-600 rounded-xl font-bold hover:bg-zinc-200 transition-all"
                        >
                          ביטול
                        </button>
                      </div>
                    </motion.div>
                  )
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Active Carts Modal */}
      <AnimatePresence>
        {showActiveCartsModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowActiveCartsModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-3xl shadow-2xl max-w-4xl w-full overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                <div className="flex items-center gap-3">
                  <ShoppingCart size={24} className="text-amber-600" />
                  <h3 className="text-xl font-bold text-zinc-900">סלים פעילים כרגע</h3>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-zinc-400 flex items-center gap-1 bg-zinc-100 px-2 py-1 rounded-md">
                    <Timer size={14} /> מתעדכן בזמן אמת
                  </span>
                  <button
                    onClick={clearAllCarts}
                    className="px-4 py-2 bg-red-600 text-white rounded-xl text-sm font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-500/20"
                  >
                    רוקן את כל הסלים
                  </button>
                  <button onClick={() => setShowActiveCartsModal(false)} className="text-zinc-400 hover:text-zinc-600">
                    <X size={24} />
                  </button>
                </div>
              </div>
              
              <div className="p-6 overflow-y-auto max-h-[70vh]">
                {allActiveCarts.length === 0 ? (
                  <div className="text-center py-12 text-zinc-400">
                    <ShoppingCart size={48} className="mx-auto mb-4 opacity-20" />
                    <p>אין סלים פעילים כרגע</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {allActiveCarts.map(cart => (
                      <div key={cart.id} className="bg-zinc-50 rounded-2xl p-4 border border-zinc-100 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <p className="font-bold text-zinc-900">{cart.userName || 'אורח'}</p>
                              <p className="text-xs text-zinc-500">{cart.userEmail || 'ללא אימייל'}</p>
                            </div>
                            <button
                              onClick={() => deleteSpecificCart(cart.id)}
                              className="p-2 text-zinc-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                              title="מחק סל זה"
                            >
                              <X size={18} />
                            </button>
                          </div>
                          <div className="space-y-1 mb-4">
                            <div className="flex justify-between text-sm">
                              <span className="text-zinc-500">פריטים:</span>
                              <span className="font-medium text-zinc-900">{cart.totalItems || 0}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-zinc-500">סה"כ:</span>
                              <span className="font-bold text-indigo-600">₪{cart.totalAmount || 0}</span>
                            </div>
                            <div className="flex justify-between text-[10px] text-zinc-400">
                              <span>עודכן לאחרונה:</span>
                              <span>{cart.updatedAt?.toDate ? cart.updatedAt.toDate().toLocaleString('he-IL') : 'זה עתה'}</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="pt-3 border-t border-zinc-200">
                          <p className="text-[10px] font-bold text-zinc-400 uppercase mb-2">פירוט מוצרים:</p>
                          <div className="flex flex-wrap gap-2">
                            {cart.detailedItems ? cart.detailedItems.map(item => {
                              const product = products.find(p => p.id === item.id);
                              return (
                                <span key={item.cartItemId || item.id} className="px-2 py-1 bg-white border border-zinc-200 rounded-lg text-[10px] text-zinc-600">
                                  {product?.name || 'מוצר לא ידוע'} {item.variantName ? `- ${item.variantName}` : ''} x{item.quantity}
                                </span>
                              );
                            }) : Object.entries(cart.items || {}).map(([prodId, qty]) => {
                              const product = products.find(p => p.id === prodId);
                              return (
                                <span key={prodId} className="px-2 py-1 bg-white border border-zinc-200 rounded-lg text-[10px] text-zinc-600">
                                  {product?.name || 'מוצר לא ידוע'} x{qty as number}
                                </span>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
