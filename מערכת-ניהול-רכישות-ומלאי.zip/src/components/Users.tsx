import React, { useState, useEffect } from 'react';
import { db, collection, getDocs, updateDoc, doc, handleFirestoreError, OperationType, deleteDoc, setDoc, query, limit, onSnapshot, orderBy } from '../firebase';
import { Users as UsersIcon, Shield, User, Trash2, Search, Mail, ShieldCheck, ShieldAlert, Plus, X, Settings as SettingsIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';

interface UserProfile {
  id: string;
  uid?: string;
  name?: string;
  email: string;
  role: 'owner' | 'admin' | 'main_user' | 'partial_user' | 'user';
  allowedCategories?: string[];
  isPending?: boolean;
}

interface Category {
  id: string;
  name: string;
}

export function Users({ userRole }: { userRole: string }) {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserRole, setNewUserRole] = useState<'admin' | 'main_user' | 'partial_user' | 'user'>('user');
  const [newUserAllowedCategories, setNewUserAllowedCategories] = useState<string[]>([]);
  const [userToDelete, setUserToDelete] = useState<UserProfile | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [editingUserCategories, setEditingUserCategories] = useState<UserProfile | null>(null);

  const isOwner = userRole === 'owner';

  useEffect(() => {
    setLoading(true);
    
    // Listen to users in real-time
    const usersQuery = query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(100));
    const unsubscribeUsers = onSnapshot(usersQuery, (snapshot) => {
      const usersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as UserProfile));
      setUsers(usersData);
      setLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'users');
      setLoading(false);
    });

    // Listen to categories in real-time
    const unsubscribeCategories = onSnapshot(collection(db, 'categories'), (snapshot) => {
      setCategories(snapshot.docs.map(doc => ({ 
        id: doc.id, 
        name: doc.data().name
      })));
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'categories');
    });

    return () => {
      unsubscribeUsers();
      unsubscribeCategories();
    };
  }, []);

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserEmail) return;

    const email = newUserEmail.toLowerCase().trim();
    
    // Check if user already exists
    if (users.find(u => u.email.toLowerCase() === email)) {
      toast.error('משתמש עם אימייל זה כבר קיים במערכת');
      return;
    }

    try {
      const docId = email;
      await setDoc(doc(db, 'users', docId), {
        email,
        role: newUserRole,
        allowedCategories: newUserRole === 'partial_user' ? newUserAllowedCategories : [],
        isPending: true,
        createdAt: new Date().toISOString()
      });
      
      toast.success('המשתמש נוסף בהצלחה. ההרשאות יופעלו כשהוא יתחבר לראשונה.');
      setNewUserEmail('');
      setNewUserAllowedCategories([]);
      setIsAddingUser(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'users');
    }
  };

  const updateUserRole = async (user: UserProfile, newRole: UserProfile['role']) => {
    if (user.role === 'owner' && !isOwner) {
      toast.error('אין לך הרשאה לשנות תפקיד של בעל מערכת');
      return;
    }
    try {
      await updateDoc(doc(db, 'users', user.id), { 
        role: newRole,
        allowedCategories: newRole === 'partial_user' ? (user.allowedCategories || []) : []
      });
      toast.success(`התפקיד של ${user.name || user.email} עודכן`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.id}`);
    }
  };

  const toggleCategory = async (userId: string, categoryId: string) => {
    const user = users.find(u => u.id === userId);
    if (!user) return;
    
    const currentAllowed = user.allowedCategories || [];
    const newAllowed = currentAllowed.includes(categoryId)
      ? currentAllowed.filter(id => id !== categoryId)
      : [...currentAllowed, categoryId];
    
    try {
      await updateDoc(doc(db, 'users', userId), { allowedCategories: newAllowed });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
    }
  };

  const deleteUser = async () => {
    if (!userToDelete) return;
    if (userToDelete.role === 'owner' && !isOwner) {
      toast.error('אין לך הרשאה למחוק בעל מערכת');
      setUserToDelete(null);
      return;
    }
    setIsDeleting(true);
    try {
      await deleteDoc(doc(db, 'users', userToDelete.id));
      toast.success('המשתמש נמחק בהצלחה');
      setUserToDelete(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `users/${userToDelete.id}`);
    } finally {
      setIsDeleting(false);
    }
  };

    const activeEditingUser = editingUserCategories ? users.find(u => u.id === editingUserCategories.id) : null;

    const filteredUsers = users.filter(u => 
      u.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
      u.email?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <UsersIcon className="w-6 h-6 text-indigo-500" />
            ניהול משתמשים והרשאות
          </h2>
          <p className="text-gray-400 text-sm mt-1">נהל את צוות המנהלים והמשתמשים במערכת</p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsAddingUser(true)}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl font-bold transition-all shadow-lg shadow-indigo-500/20"
          >
            <Plus className="w-5 h-5" />
            הוסף משתמש מראש
          </button>
          
          <div className="relative max-w-xs w-full">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder="חיפוש..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#1a1a1a] border border-white/10 rounded-xl py-2 pr-10 pl-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
            />
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isAddingUser && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <form onSubmit={handleAddUser} className="bg-[#1a1a1a] p-6 rounded-2xl border border-indigo-500/30 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-white">הוספת משתמש חדש (לפני התחברות)</h3>
                <button type="button" onClick={() => setIsAddingUser(false)} className="text-gray-500 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-400 block">אימייל המשתמש</label>
                  <input
                    type="email"
                    required
                    value={newUserEmail}
                    onChange={(e) => setNewUserEmail(e.target.value)}
                    placeholder="example@gmail.com"
                    className="w-full bg-[#0a0a0a] border border-white/10 rounded-xl py-2 px-4 text-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm text-gray-400 block">תפקיד</label>
                  <select
                    value={newUserRole}
                    onChange={(e) => setNewUserRole(e.target.value as any)}
                    className="w-full bg-[#0a0a0a] border border-white/10 rounded-xl py-2 px-4 text-white focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="user">משתמש רגיל</option>
                    <option value="main_user">משתמש ראשי</option>
                    <option value="partial_user">משתמש חלקי</option>
                    <option value="admin">מנהל מערכת</option>
                  </select>
                </div>
              </div>

              {newUserRole === 'partial_user' && (
                <div className="space-y-2">
                  <label className="text-sm text-gray-400 block">קטגוריות מורשות</label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {categories.map(cat => (
                      <label key={cat.id} className="flex items-center gap-2 p-2 rounded-lg border border-white/5 hover:bg-white/10 cursor-pointer relative">
                        <input
                          type="checkbox"
                          checked={newUserAllowedCategories.includes(cat.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNewUserAllowedCategories([...newUserAllowedCategories, cat.id]);
                            } else {
                              setNewUserAllowedCategories(newUserAllowedCategories.filter(id => id !== cat.id));
                            }
                          }}
                          className="rounded text-indigo-600"
                        />
                        <span className="text-xs text-gray-300">{cat.name}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="flex items-end pt-2">
                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-bold transition-all shadow-lg shadow-indigo-500/20"
                >
                  הוסף לרשימת ההרשאות
                </button>
              </div>
              <p className="text-xs text-gray-500">
                * המשתמש יקבל את ההרשאות באופן אוטומטי ברגע שיתחבר לאתר עם האימייל הזה.
              </p>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid gap-4">
        {/* Delete Confirmation Modal */}
        <AnimatePresence>
          {userToDelete && (
            <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => !isDeleting && setUserToDelete(null)}
                className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="relative bg-[#1a1a1a] rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border border-white/10"
              >
                <div className="p-8 text-center space-y-6">
                  <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mx-auto text-red-500">
                    <Trash2 size={40} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold text-white">מחיקת משתמש</h3>
                    <p className="text-gray-400">
                      האם אתה בטוח שברצונך למחוק את המשתמש <span className="text-white font-bold">{userToDelete.name || userToDelete.email}</span>?
                      פעולה זו אינה ניתנת לביטול.
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setUserToDelete(null)}
                      disabled={isDeleting}
                      className="flex-1 px-6 py-4 bg-white/5 text-white rounded-2xl font-bold hover:bg-white/10 transition-all disabled:opacity-50"
                    >
                      ביטול
                    </button>
                    <button
                      onClick={deleteUser}
                      disabled={isDeleting}
                      className="flex-1 px-6 py-4 bg-red-600 text-white rounded-2xl font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {isDeleting ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <Trash2 size={20} />
                      )}
                      כן, מחק משתמש
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="text-center py-12 bg-[#1a1a1a] rounded-2xl border border-white/5">
            <User className="w-12 h-12 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400">לא נמצאו משתמשים</p>
          </div>
        ) : (
          <div className="bg-[#1a1a1a] rounded-2xl border border-white/5 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right">
                <thead>
                  <tr className="border-b border-white/5 bg-white/5">
                    <th className="px-6 py-4 text-sm font-medium text-gray-400">משתמש</th>
                    <th className="px-6 py-4 text-sm font-medium text-gray-400">אימייל</th>
                    <th className="px-6 py-4 text-sm font-medium text-gray-400">תפקיד</th>
                    <th className="px-6 py-4 text-sm font-medium text-gray-400 text-left">פעולות</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  <AnimatePresence mode="popLayout" initial={false}>
                    {filteredUsers.map((user) => (
                      <motion.tr
                        key={user.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.98 }}
                        transition={{ duration: 0.2 }}
                        className="hover:bg-white/5 transition-colors"
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${user.isPending ? 'bg-orange-500/10' : 'bg-indigo-500/10'}`}>
                              <User className={`w-5 h-5 ${user.isPending ? 'text-orange-400' : 'text-indigo-400'}`} />
                            </div>
                            <div className="flex flex-col">
                              <span className="font-medium text-white">{user.name || (user.isPending ? 'ממתין להתחברות' : 'ללא שם')}</span>
                              {user.isPending && <span className="text-[10px] text-orange-400 font-bold">הוספה מראש</span>}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2 text-gray-400">
                            <Mail className="w-4 h-4" />
                            {user.email}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <select
                              value={user.role}
                              onChange={(e) => updateUserRole(user, e.target.value as any)}
                              disabled={user.role === 'owner' && !isOwner}
                              className="bg-transparent text-white border-none focus:ring-0 text-sm font-bold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              {isOwner && <option value="owner" className="bg-[#1a1a1a]">בעל מערכת</option>}
                              <option value="admin" className="bg-[#1a1a1a]">מנהל מערכת</option>
                              <option value="main_user" className="bg-[#1a1a1a]">משתמש ראשי</option>
                              <option value="partial_user" className="bg-[#1a1a1a]">משתמש חלקי</option>
                              <option value="user" className="bg-[#1a1a1a]">משתמש</option>
                            </select>
                            {user.role === 'partial_user' && (
                              <button
                                onClick={() => setEditingUserCategories(user)}
                                className="p-1 text-indigo-400 hover:bg-indigo-500/10 rounded transition-colors"
                                title="נהל קטגוריות"
                              >
                                <SettingsIcon size={14} />
                              </button>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => setUserToDelete(user)}
                              disabled={user.role === 'owner' && !isOwner}
                              className="p-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                              title="מחק משתמש"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          </div>
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Category Selection Modal */}
      <AnimatePresence>
        {activeEditingUser && (
          <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setEditingUserCategories(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-[#1a1a1a] rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border border-white/10"
            >
              <div className="p-8">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white">קטגוריות מורשות</h3>
                    <p className="text-gray-400 text-sm mt-1">עבור: {activeEditingUser.name || activeEditingUser.email}</p>
                  </div>
                  <button onClick={() => setEditingUserCategories(null)} className="text-gray-500 hover:text-white">
                    <X size={24} />
                  </button>
                </div>
                
                <div className="grid grid-cols-2 gap-3 mb-8 max-h-[40vh] overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-white/10">
                  {categories.map(cat => (
                    <label 
                      key={cat.id} 
                      className={`flex items-center gap-3 p-4 rounded-2xl border-2 transition-all cursor-pointer relative ${
                        activeEditingUser.allowedCategories?.includes(cat.id)
                          ? 'border-indigo-600 bg-indigo-600/10'
                          : 'border-white/5 hover:border-white/10 bg-white/5'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={activeEditingUser.allowedCategories?.includes(cat.id)}
                        onChange={() => toggleCategory(activeEditingUser.id, cat.id)}
                        className="hidden"
                      />
                      <span className={`font-bold text-sm ${
                        activeEditingUser.allowedCategories?.includes(cat.id) ? 'text-indigo-400' : 'text-gray-400'
                      }`}>
                        {cat.name}
                      </span>
                    </label>
                  ))}
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={() => setEditingUserCategories(null)}
                    className="px-8 py-3 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20"
                  >
                    סיום
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
