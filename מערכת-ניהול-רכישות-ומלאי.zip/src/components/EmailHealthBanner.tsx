import React, { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle2, RefreshCw, Send, ArrowLeft, KeyRound, Clock, X } from 'lucide-react';
import { getEmailStatus, checkEmailHealth, retryFailedEmails, EmailHealthStatus } from '../services/emailService';
import toast from 'react-hot-toast';

interface EmailHealthBannerProps {
  onNavigate: (tab: any) => void;
}

export function EmailHealthBanner({ onNavigate }: EmailHealthBannerProps) {
  const [status, setStatus] = useState<EmailHealthStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [retrying, setRetrying] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  const fetchStatus = async () => {
    try {
      const data = await getEmailStatus();
      setStatus(data);
    } catch (e) {
      console.error('Failed to get email status in banner:', e);
    }
  };

  useEffect(() => {
    fetchStatus();

    // Check periodically every 45 seconds
    const interval = setInterval(fetchStatus, 45000);

    const handleCustomUpdate = () => fetchStatus();
    window.addEventListener('email-status-updated', handleCustomUpdate);

    return () => {
      clearInterval(interval);
      window.removeEventListener('email-status-updated', handleCustomUpdate);
    };
  }, []);

  if (!status) return null;

  // Nothing to alert if healthy and no pending emails
  if (status.healthy && (!status.pendingCount || status.pendingCount === 0)) {
    return null;
  }

  // If dismissed by admin during this session and healthy with pending, or unhealthy
  if (isDismissed) {
    return (
      <div className="no-print bg-rose-900 text-white px-4 py-1 text-xs flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AlertTriangle size={14} className="text-amber-400" />
          <span>שירות המיילים דורש תשומת לב ({status.pendingCount} מיילים בתור)</span>
        </div>
        <button
          onClick={() => setIsDismissed(false)}
          className="underline hover:text-amber-200 font-bold"
        >
          הצג פירוט
        </button>
      </div>
    );
  }

  const handleCheckNow = async () => {
    setLoading(true);
    const toastId = toast.loading('בודק חיבור מול Google...');
    try {
      const res = await checkEmailHealth();
      setStatus(res);
      if (res.healthy) {
        toast.success('חיבור ה-Gmail תקין ומאומת!', { id: toastId });
      } else {
        toast.error('האימות נכשל: ' + (res.error || 'בדוק את הסיסמה'), { id: toastId });
      }
    } catch (e) {
      toast.error('שגיאה בבדיקת החיבור', { id: toastId });
    } finally {
      setLoading(false);
    }
  };

  const handleRetryEmails = async () => {
    setRetrying(true);
    const toastId = toast.loading('שולח מחדש מיילים שנשמרו בתור...');
    try {
      const res = await retryFailedEmails();
      if (res.success) {
        toast.success(`נשלחו בהצלחה ${res.sent} מיילים!`, { id: toastId });
        await fetchStatus();
      } else {
        toast.error(`שליחה נכשלה: ${res.error || 'ודאו שהסיסמה תקפה'}`, { id: toastId });
      }
    } catch (e) {
      toast.error('שגיאה בשליחה חוזרת', { id: toastId });
    } finally {
      setRetrying(false);
    }
  };

  const goToSettings = () => {
    onNavigate('settings');
    setTimeout(() => {
      const elem = document.getElementById('smtp-settings-card');
      if (elem) {
        elem.scrollIntoView({ behavior: 'smooth' });
      }
    }, 200);
  };

  // Case 1: Unhealthy (Password invalid or connection failed)
  if (!status.healthy) {
    const isUnconfigured = !status.configured;
    return (
      <div 
        id="email-health-alert"
        className="no-print bg-gradient-to-r from-rose-700 via-rose-800 to-rose-900 text-white p-4 shadow-lg border-b border-rose-950/40 relative z-30 transition-all"
        dir="rtl"
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 bg-white/15 rounded-xl text-amber-300 shrink-0 mt-0.5 shadow-inner">
              <AlertTriangle size={24} />
            </div>
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-extrabold text-base tracking-wide text-white">
                  {isUnconfigured 
                    ? 'שירות המיילים: טרם הוגדרו פרטי Gmail לשליחה' 
                    : 'התראת מערכת: שירות המיילים מנותק / נדרש עדכון סיסמת Gmail'}
                </span>
                {status.pendingCount > 0 && (
                  <span className="bg-amber-400 text-rose-950 font-bold px-2 py-0.5 rounded-full text-xs animate-pulse">
                    {status.pendingCount} מיילים ממתינים בתור
                  </span>
                )}
              </div>
              <p className="text-rose-100 text-sm leading-relaxed max-w-3xl">
                {status.pendingCount > 0 
                  ? `ההזמנות ממשיכות להתקבל כרגיל, אך המערכת לא מצליחה לשלוח הודעות לרוכשים. כל המיילים שלא נשלחו נשמרים בבטחה בתור וישלחו אוטומטית ברגע שתזינו סיסמת אפליקציה חדשה.`
                  : isUnconfigured
                    ? 'כדי שהמערכת תוכל לשלוח אישורי הזמנה ודוחות ללקוחות, יש להזין כתובת Gmail וסיסמת אפליקציה (16 אותיות) בהגדרות.'
                    : 'שרת הדואר של Google דחה את פרטי ההתחברות (קוד 535). כל עוד החיבור לא יעודכן, מיילים של הזמנות ודוחות יישמרו בבטחה בתור ולא ישלחו.'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-end">
            <button
              onClick={goToSettings}
              className="px-4 py-2 bg-white hover:bg-rose-50 text-rose-900 font-bold rounded-xl text-sm transition-all shadow-md flex items-center gap-1.5 whitespace-nowrap"
            >
              <KeyRound size={16} className="text-rose-700" />
              <span>{isUnconfigured ? 'הגדר פרטי Gmail בהגדרות' : 'עדכן סיסמת Gmail בהגדרות'}</span>
              <ArrowLeft size={16} />
            </button>

            <button
              onClick={handleCheckNow}
              disabled={loading}
              className="px-3 py-2 bg-black/25 hover:bg-black/40 text-rose-100 font-medium rounded-xl text-xs transition-all flex items-center gap-1.5 whitespace-nowrap border border-white/10"
              title="בדוק חיבור עכשיו מול Google"
            >
              <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
              <span>בדוק שוב</span>
            </button>

            <button
              onClick={() => setIsDismissed(true)}
              className="p-2 text-rose-200 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
              title="סגור התראה זמנית"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Case 2: Healthy, but there are pending queued emails waiting to be flushed
  if (status.pendingCount > 0) {
    return (
      <div 
        id="email-health-alert"
        className="no-print bg-gradient-to-r from-indigo-800 to-indigo-900 text-white p-3.5 shadow-md border-b border-indigo-950/40 relative z-30 transition-all"
        dir="rtl"
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/15 rounded-lg text-emerald-400 shrink-0">
              <CheckCircle2 size={20} />
            </div>
            <div>
              <p className="font-bold text-sm">
                חיבור ה-Gmail תקין, אך ישנם <span className="underline font-extrabold text-amber-300">{status.pendingCount} מיילים</span> שנשמרו בתור בעת שהסיסמה הייתה מנותקת.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRetryEmails}
              disabled={retrying}
              className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl text-xs transition-all shadow flex items-center gap-1.5"
            >
              <Send size={14} className={retrying ? 'animate-pulse' : ''} />
              <span>{retrying ? 'שולח...' : 'שלח עכשיו את כל המיילים שבתור'}</span>
            </button>
            <button
              onClick={() => setIsDismissed(true)}
              className="p-1.5 text-indigo-200 hover:text-white rounded-lg hover:bg-white/10"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
