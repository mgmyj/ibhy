import React, { useState, useEffect } from 'react';
import { db, collection, getDocs, doc, writeBatch, query, where } from '../firebase';
import { Archive as ArchiveIcon, RefreshCw, AlertTriangle, Check, Loader2, Package, Users, ShoppingCart, List, Undo2, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'react-hot-toast';

export function Archive() {
  const [isArchiving, setIsArchiving] = useState(false);
  const [activeTab, setActiveTab] = useState<'products' | 'categories' | 'customers' | 'orders'>('products');
  const [items, setItems] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchArchivedItems();
  }, [activeTab]);

  const fetchArchivedItems = async () => {
    setIsLoading(true);
    try {
      let colName = '';
      if (activeTab === 'products') colName = 'archived_products';
      if (activeTab === 'categories') colName = 'archived_categories';
      if (activeTab === 'customers') colName = 'archived_customers';
      if (activeTab === 'orders') colName = 'archived_orders';
      
      const snap = await getDocs(collection(db, colName));
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setItems(data);
    } catch (err) {
      console.error(err);
      toast.error('שגיאה בטעינת נתונים מהארכיון');
    } finally {
      setIsLoading(false);
    }
  };

  const chunkArray = (array: any[], size: number) => {
    const chunked = [];
    for (let i = 0; i < array.length; i += size) {
      chunked.push(array.slice(i, i + size));
    }
    return chunked;
  };

  const moveCollection = async (sourceCol: string, destCol: string) => {
    const snapshot = await getDocs(collection(db, sourceCol));
    if (snapshot.empty) return;

    const chunks = chunkArray(snapshot.docs, 250);
    const archiveDate = new Date().toISOString();
    
    for (const chunk of chunks) {
      const batch = writeBatch(db);
      chunk.forEach(d => {
        const data = d.data();
        const newRef = doc(db, destCol, d.id);
        batch.set(newRef, { ...data, archivedAt: archiveDate });
        batch.delete(d.ref);
      });
      await batch.commit();
    }
  };

  const handleCreateNewSale = async () => {
    if (!window.confirm('האם אתה בטוח שברצונך לפתוח מכירה חדשה? פעולה זו תעביר את כל המוצרים, הקטגוריות, הלקוחות וההזמנות הנוכחיים לארכיון.')) return;
    
    setIsArchiving(true);
    try {
      await moveCollection('products', 'archived_products');
      await moveCollection('categories', 'archived_categories');
      await moveCollection('subCategories', 'archived_subCategories');
      await moveCollection('customers', 'archived_customers');
      await moveCollection('orders', 'archived_orders');
      
      // Delete active carts
      const cartsSnap = await getDocs(collection(db, 'active_carts'));
      if (!cartsSnap.empty) {
        const chunks = chunkArray(cartsSnap.docs, 500);
        for (const chunk of chunks) {
          const batch = writeBatch(db);
          chunk.forEach(d => batch.delete(d.ref));
          await batch.commit();
        }
      }
      
      toast.success('מכירה חדשה נוצרה בהצלחה! כל הנתונים הועברו לארכיון.');
      fetchArchivedItems();
    } catch (err) {
      console.error(err);
      toast.error('שגיאה ביצירת מכירה חדשה');
    } finally {
      setIsArchiving(false);
    }
  };

  const handleRestore = async (item: any) => {
    if (!window.confirm('האם לשחזר פריט זה למכירה הפעילה?')) return;
    
    try {
      let sourceCol = '';
      let destCol = '';
      
      if (activeTab === 'products') { sourceCol = 'archived_products'; destCol = 'products'; }
      if (activeTab === 'categories') { sourceCol = 'archived_categories'; destCol = 'categories'; }
      if (activeTab === 'customers') { sourceCol = 'archived_customers'; destCol = 'customers'; }
      if (activeTab === 'orders') { sourceCol = 'archived_orders'; destCol = 'orders'; }

      const batch = writeBatch(db);
      
      // Remove archivedAt field when restoring
      const { archivedAt, id, ...restData } = item;
      
      const newRef = doc(db, destCol, id);
      batch.set(newRef, restData);
      
      const oldRef = doc(db, sourceCol, id);
      batch.delete(oldRef);

      // Restore subcategories if restoring a category
      if (activeTab === 'categories') {
        const subSnap = await getDocs(query(collection(db, 'archived_subCategories'), where('categoryId', '==', id)));
        subSnap.docs.forEach(d => {
           const subData = d.data();
           const { archivedAt: subArchivedAt, ...restSubData } = subData;
           batch.set(doc(db, 'subCategories', d.id), restSubData);
           batch.delete(doc(db, 'archived_subCategories', d.id));
        });
      }
      
      await batch.commit();
      
      toast.success('הפריט שוחזר בהצלחה');
      setItems(items.filter(i => i.id !== id));
    } catch (err) {
      console.error(err);
      toast.error('שגיאה בשחזור הפריט');
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6" dir="rtl">
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-zinc-200">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-2xl font-bold text-zinc-800 flex items-center gap-2">
              <ArchiveIcon className="text-indigo-600" />
              ניהול מכירות וארכיון
            </h2>
            <p className="text-zinc-500 mt-1">
              פתח מכירה חדשה על ידי העברת כל הנתונים הנוכחיים לארכיון. תוכל לשחזר פריטים ספציפיים בעת הצורך.
            </p>
          </div>
          
          <button
            onClick={handleCreateNewSale}
            disabled={isArchiving}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-medium transition-all flex items-center gap-2 disabled:opacity-50"
          >
            {isArchiving ? <Loader2 size={20} className="animate-spin" /> : <RefreshCw size={20} />}
            יצירת מכירה חדשה (העברה לארכיון)
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-zinc-200 overflow-hidden">
        <div className="flex border-b border-zinc-200 overflow-x-auto">
          <button
            onClick={() => setActiveTab('products')}
            className={`flex-1 flex items-center justify-center gap-2 py-4 px-6 font-medium transition-colors whitespace-nowrap ${
              activeTab === 'products' ? 'bg-indigo-50 text-indigo-700 border-b-2 border-indigo-600' : 'text-zinc-500 hover:bg-zinc-50'
            }`}
          >
            <Package size={20} /> מוצרים
          </button>
          <button
            onClick={() => setActiveTab('categories')}
            className={`flex-1 flex items-center justify-center gap-2 py-4 px-6 font-medium transition-colors whitespace-nowrap ${
              activeTab === 'categories' ? 'bg-indigo-50 text-indigo-700 border-b-2 border-indigo-600' : 'text-zinc-500 hover:bg-zinc-50'
            }`}
          >
            <List size={20} /> קטגוריות
          </button>
          <button
            onClick={() => setActiveTab('customers')}
            className={`flex-1 flex items-center justify-center gap-2 py-4 px-6 font-medium transition-colors whitespace-nowrap ${
              activeTab === 'customers' ? 'bg-indigo-50 text-indigo-700 border-b-2 border-indigo-600' : 'text-zinc-500 hover:bg-zinc-50'
            }`}
          >
            <Users size={20} /> לקוחות
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`flex-1 flex items-center justify-center gap-2 py-4 px-6 font-medium transition-colors whitespace-nowrap ${
              activeTab === 'orders' ? 'bg-indigo-50 text-indigo-700 border-b-2 border-indigo-600' : 'text-zinc-500 hover:bg-zinc-50'
            }`}
          >
            <ShoppingCart size={20} /> הזמנות
          </button>
        </div>

        <div className="p-6">
          {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 size={32} className="animate-spin text-indigo-600" />
            </div>
          ) : items.length === 0 ? (
            <div className="text-center py-12 text-zinc-500">
              <ArchiveIcon size={48} className="mx-auto text-zinc-300 mb-4" />
              <p>אין נתונים בארכיון בקטגוריה זו</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <AnimatePresence>
                {items.map((item) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-zinc-50 border border-zinc-200 rounded-xl p-4 flex flex-col justify-between"
                  >
                    <div>
                      <h3 className="font-bold text-zinc-800">
                        {activeTab === 'products' ? item.name : ''}
                        {activeTab === 'categories' ? item.name : ''}
                        {activeTab === 'customers' ? item.name : ''}
                        {activeTab === 'orders' ? `הזמנה #${item.orderNumber}` : ''}
                      </h3>
                      <div className="text-sm text-zinc-500 mt-2 space-y-1">
                        {activeTab === 'products' && (
                          <>
                            <p>מחיר: ₪{item.price}</p>
                            <p>מלאי: {item.stock}</p>
                          </>
                        )}
                        {activeTab === 'customers' && (
                          <>
                            <p>טלפון: {item.phone}</p>
                            <p>דוא"ל: {item.email}</p>
                          </>
                        )}
                        {activeTab === 'orders' && (
                          <>
                            <p>לקוח: {item.customerName || item.customer?.name}</p>
                            <p>סכום: ₪{item.totalAmount}</p>
                            <p>תאריך: {item.createdAt ? new Date(item.createdAt?.toDate ? item.createdAt.toDate() : item.createdAt).toLocaleDateString('he-IL') : ''}</p>
                          </>
                        )}
                        {item.archivedAt && (
                          <p className="text-xs text-indigo-500 mt-2">
                            הועבר לארכיון: {new Date(item.archivedAt).toLocaleDateString('he-IL')}
                          </p>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => handleRestore(item)}
                      className="mt-4 flex items-center justify-center gap-2 w-full py-2 bg-white border border-zinc-300 hover:border-indigo-600 hover:text-indigo-600 rounded-lg text-sm font-medium transition-colors"
                    >
                      <Undo2 size={16} />
                      שחזר למכירה פעילה
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
