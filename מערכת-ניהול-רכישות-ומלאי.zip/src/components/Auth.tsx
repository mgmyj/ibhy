import React, { useState } from 'react';
import { auth, googleProvider, googleSignIn, logout } from '../firebase';
import { LogIn, User as UserIcon, LogOut, ShieldCheck, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AuthProps {
  user: any;
  loading: boolean;
  onGuestLogin: () => void;
}

export function Auth({ user, loading, onGuestLogin }: AuthProps) {
  const [error, setError] = useState<string | null>(null);

  const handleGoogleLogin = async () => {
    setError(null);
    try {
      await googleSignIn();
    } catch (err: any) {
      if (err.code === 'auth/cancelled-popup-request' || err.code === 'auth/popup-closed-by-user') {
        // User intentionally closed the popup, no need to show an error
        console.log('Login cancelled by user.');
        return;
      }
      setError('אירעה שגיאה בעת ההתחברות. אנא נסה שוב מאוחר יותר.');
      console.error('Auth error:', err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (user) {
    return (
      <div className="flex items-center gap-4 bg-white/10 p-2 rounded-full backdrop-blur-sm border border-white/20">
        <div className="flex items-center gap-3 px-3">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-medium text-white">{user.displayName || 'משתמש'}</p>
            <p className="text-[10px] text-white/60 uppercase tracking-wider">{user.email}</p>
          </div>
          {user.photoURL ? (
            <img src={user.photoURL} alt={user.displayName} className="w-8 h-8 rounded-full border border-white/20" />
          ) : (
            <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-white">
              <UserIcon size={16} />
            </div>
          )}
        </div>
        <button
          onClick={() => logout()}
          className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/80 hover:text-white"
          title="התנתק"
        >
          <LogOut size={18} />
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] p-4 font-sans" dir="rtl">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-zinc-900 p-8 rounded-3xl shadow-2xl max-w-md w-full border border-zinc-800"
      >
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-indigo-600 rounded-2xl mx-auto mb-6 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <ShieldCheck size={40} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2 tracking-tight">מערכת ניהול רכישות</h1>
          <p className="text-zinc-400">התחבר למערכת כדי להתחיל לנהל את העסק שלך</p>
        </div>

        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center gap-3 text-red-400 text-sm"
            >
              <AlertCircle size={18} className="shrink-0" />
              <p>{error}</p>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="space-y-4">
          <button
            onClick={handleGoogleLogin}
            className="w-full bg-white text-black py-4 rounded-2xl font-semibold flex items-center justify-center gap-3 hover:bg-zinc-200 transition-all active:scale-[0.98]"
          >
            <LogIn size={20} />
            התחברות עם Google
          </button>
          
          <div className="relative py-4">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-zinc-800"></div></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-zinc-900 px-2 text-zinc-500">או</span></div>
          </div>

          <button
            onClick={onGuestLogin}
            className="w-full bg-zinc-800 text-white py-4 rounded-2xl font-semibold flex items-center justify-center gap-3 hover:bg-zinc-700 transition-all border border-zinc-700 active:scale-[0.98]"
          >
            <UserIcon size={20} />
            כניסה כאורח
          </button>
        </div>

        <p className="mt-8 text-center text-xs text-zinc-500">
          בכניסה למערכת הנך מסכים לתנאי השימוש
        </p>
      </motion.div>
    </div>
  );
}

