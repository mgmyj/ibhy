import React, { useState, useEffect } from 'react';
import { db, collection, getDocs, query, orderBy, handleFirestoreError, OperationType, limit, doc, getDoc, updateDoc, setDoc, auth, where } from '../firebase';
import { LayoutDashboard, FileDown, FileText, Search, Filter, Package, ShoppingCart, Users, ChevronLeft, ExternalLink, TrendingUp, AlertTriangle, Mail, Bell, Send, Settings as SettingsIcon, Loader2, Save, X, Calendar, Eye } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import * as XLSX from 'xlsx';
import { toast } from 'react-hot-toast';
import { sendEmail, formatReservationEmail } from '../services/emailService';

interface OrderItem { productId: string; sku: string; name: string; quantity: number; price: number; variantId?: string; variantName?: string; }
interface Order { 
  id: string; 
  customerId: string; 
  customer?: Record<string, any>; 
  customerName?: string;
  items: OrderItem[]; 
  totalAmount: number; 
  status: string; 
  createdAt: any; 
  orderNumber?: number;
}

interface Product { 
  id: string; 
  sku: string; 
  name: string; 
  price: number; 
  categoryId: string; 
  subCategoryId?: string; 
  stockQuantity: number; 
  totalStock?: number;
  variants?: any[];
  description?: string;
}

interface Category { id: string; name: string; }
interface SubCategory { id: string; name: string; categoryId: string; }

interface EmailSettings {
  mainEmail: string;
  reportEmail: string;
  replyToType: 'sender' | 'fixed';
  fixedReplyToEmail?: string;
  senderChoice: 'user' | 'system';
  notifyNewOrder: boolean;
  notifyEditOrder: boolean;
  notifyDeleteOrder: boolean;
  notifyReservation: boolean;
  notifyReservationDelete: boolean;
  notifyReservationToOrder: boolean;
  notifyLowStock: boolean;
  autoDailyReport: boolean;
  autoWeeklyReport: boolean;
  autoMonthlyReport: boolean;
  disableAllEmails: boolean;
}

interface SystemConfig {
  customerFormTitle: string;
  customerFormFields: any[];
  siteName: string;
  orgName: string;
  logoUrl: string;
  faviconUrl: string;
  emailSettings?: EmailSettings;
}

export function Reports() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [subCategories, setSubCategories] = useState<SubCategory[]>([]);
  const [config, setConfig] = useState<SystemConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeReport, setActiveReport] = useState<'sales' | 'inventory' | 'purchasers' | 'emails'>('sales');
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isSavingConfig, setIsSavingConfig] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportType, setReportType] = useState<'daily' | 'monthly' | 'range' | 'buyers'>('daily');
  const [reportDateRange, setReportDateRange] = useState({ start: '', end: '' });
  const [selectedProductId, setSelectedProductId] = useState('all');
  const [generatingReport, setGeneratingReport] = useState(false);
  const [reportOutput, setReportOutput] = useState<'email' | 'pdf' | 'excel' | 'view'>('view');
  const [visibleOrdersCount, setVisibleOrdersCount] = useState(20);
  const [visibleProductsCount, setVisibleProductsCount] = useState(20);

  useEffect(() => {
    setVisibleOrdersCount(20);
    setVisibleProductsCount(20);
  }, [activeReport]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [ordersSnap, catsSnap, subsSnap, configSnap] = await Promise.all([
        getDocs(query(collection(db, 'orders'), orderBy('createdAt', 'desc'))),
        getDocs(collection(db, 'categories')),
        getDocs(collection(db, 'subCategories')),
        getDoc(doc(db, 'config', 'system'))
      ]);

      setOrders(ordersSnap.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) } as Order)));
      setCategories(catsSnap.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) } as Category)));
      setSubCategories(subsSnap.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) } as SubCategory)));
      if (configSnap.exists()) setConfig(configSnap.data() as SystemConfig);
      
      // Only fetch products if needed for inventory report or if specifically requested
      // Fetch products for all report types to ensure category/subcategory names are available
      const prodsSnap = await getDocs(query(collection(db, 'products'), limit(1000)));
      setProducts(prodsSnap.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) } as Product)));
      
      setLoading(false);
    } catch (err) {
      console.error('Error fetching report data:', err);
      handleFirestoreError(err, OperationType.LIST, 'reports');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const getCategoryName = (id: string) => categories.find(c => c.id === id)?.name || 'ללא קטגוריה';
  const getSubCategoryName = (id?: string) => subCategories.find(s => s.id === id)?.name || 'ללא תת-קטגוריה';
  const getFieldLabel = (fieldId: string) => {
    const field = config?.customerFormFields?.find(f => f.id === fieldId);
    return field?.label || fieldId;
  };

  const exportInventoryToExcel = async () => {
    const sortedProducts = [...products].sort((a, b) => (a.sku || '').localeCompare(b.sku || '', undefined, { numeric: true }));
    const data: any[] = [];
    
    sortedProducts.forEach(p => {
      if (p.variants && p.variants.length > 0) {
        p.variants.forEach(v => {
          data.push({
            'מק"ט': p.sku,
            'שם מוצר': `${p.name} - ${v.name}`,
            'קטגוריה': getCategoryName(p.categoryId),
            'תת קטגוריה': getSubCategoryName(p.subCategoryId),
            'מלאי נוכחי': v.stockQuantity,
            'מלאי כללי': v.totalStock || v.stockQuantity,
            'מחיר': v.price !== undefined ? v.price : p.price,
            'שווי מלאי': (v.price !== undefined ? v.price : p.price) * (v.stockQuantity || 0)
          });
        });
      } else {
        data.push({
          'מק"ט': p.sku,
          'שם מוצר': p.name,
          'קטגוריה': getCategoryName(p.categoryId),
          'תת קטגוריה': getSubCategoryName(p.subCategoryId),
          'מלאי נוכחי': p.stockQuantity,
          'מלאי כללי': p.totalStock || p.stockQuantity,
          'מחיר': p.price,
          'שווי מלאי': p.price * p.stockQuantity
        });
      }
    });

    if (data.length === 0) {
      data.push({ 'הודעה': 'אין נתונים להצגה' });
    }
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Inventory');
    XLSX.writeFile(wb, `דוח_מלאי_${new Date().toLocaleDateString('he-IL').replace(/\//g, '-')}.xlsx`);

    // Send copy by email if configured
    try {
      const configDoc = await getDoc(doc(db, 'config', 'system'));
      const config = configDoc.data();
      if (!config?.emailSettings?.disableAllEmails && config?.emailReports?.copyOnExport && config?.emailReports?.recipientEmail) {
        const base64 = XLSX.write(wb, { bookType: 'xlsx', type: 'base64' });
        await sendEmail({
          to: config.emailReports.recipientEmail,
          subject: `דוח מלאי - ${config.siteName || 'מערכת רכש'}`,
          html: `
            <div dir="rtl" style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
              <h2 style="color: #2563eb;">דוח מלאי</h2>
              <p>שלום רב,</p>
              <p>מצורף בזאת דוח מלאי עדכני שהופק ממערכת <strong>${config.siteName || 'מערכת רכש'}</strong>.</p>
              <p><strong>תאריך הפקה:</strong> ${new Date().toLocaleDateString('he-IL')} בשעה ${new Date().toLocaleTimeString('he-IL')}</p>
              <p>הדוח מצורף כקובץ אקסל (Excel) וכולל את כל נתוני המלאי הנוכחיים.</p>
              <br/>
              <p>בברכה,<br/>צוות המערכת</p>
            </div>
          `,
          attachments: [{
            filename: `דוח_מלאי_${new Date().toLocaleDateString('he-IL').replace(/\//g, '-')}.xlsx`,
            content: base64,
            contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
          }]
        });
        toast.success('עותק מהדוח נשלח לאימייל');
      }
    } catch (err) {
      console.error('Failed to send report email:', err);
    }
  };

  const exportSalesToExcel = async () => {
    const data: any[] = orders.map(o => ({
      'מספר הזמנה': o.id,
      'לקוח': o.customerName || Object.values(o.customer || {}).join(', '),
      'תאריך': o.createdAt?.toDate()?.toLocaleDateString('he-IL') || '',
      'סה"כ': o.totalAmount,
      'סטטוס': o.status === 'pending' ? 'ממתין' : o.status === 'completed' ? 'הושלם' : 'בוטל'
    }));
    if (data.length === 0) {
      data.push({ 'הודעה': 'אין נתונים להצגה' });
    }
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sales');
    XLSX.writeFile(wb, `דוח_מכירות_${new Date().toLocaleDateString('he-IL').replace(/\//g, '-')}.xlsx`);

    // Send copy by email if configured
    try {
      const configDoc = await getDoc(doc(db, 'config', 'system'));
      const config = configDoc.data();
      if (!config?.emailSettings?.disableAllEmails && config?.emailReports?.copyOnExport && config?.emailReports?.recipientEmail) {
        const base64 = XLSX.write(wb, { bookType: 'xlsx', type: 'base64' });
        await sendEmail({
          to: config.emailReports.recipientEmail,
          subject: `דוח מכירות - ${config.siteName || 'מערכת רכש'}`,
          html: `
            <div dir="rtl" style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
              <h2 style="color: #2563eb;">דוח מכירות</h2>
              <p>שלום רב,</p>
              <p>מצורף בזאת דוח מכירות עדכני שהופק ממערכת <strong>${config.siteName || 'מערכת רכש'}</strong>.</p>
              <p><strong>תאריך הפקה:</strong> ${new Date().toLocaleDateString('he-IL')} בשעה ${new Date().toLocaleTimeString('he-IL')}</p>
              <p>הדוח מצורף כקובץ אקסל (Excel) וכולל את כל נתוני המכירות שיוצאו.</p>
              <br/>
              <p>בברכה,<br/>צוות המערכת</p>
            </div>
          `,
          attachments: [{
            filename: `דוח_מכירות_${new Date().toLocaleDateString('he-IL').replace(/\//g, '-')}.xlsx`,
            content: base64,
            contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
          }]
        });
        toast.success('עותק מהדוח נשלח לאימייל');
      }
    } catch (err) {
      console.error('Failed to send report email:', err);
    }
  };

  const [selectedOrderDetails, setSelectedOrderDetails] = useState<Order | null>(null);

  const getProductPurchasers = (productId: string | null, categoryId: string = 'all', subCategoryId: string = 'all') => {
    const purchasers: Record<string, { name: string, quantity: number, orders: string[] }> = {};
    orders.forEach(order => {
      order.items.forEach(item => {
        const product = products.find(p => p.id === item.productId);
        if (!product) return;

        const matchesProduct = productId ? item.productId === productId : true;
        const matchesCategory = categoryId === 'all' || product.categoryId === categoryId;
        const matchesSubCategory = subCategoryId === 'all' || product.subCategoryId === subCategoryId;

        if (matchesProduct && matchesCategory && matchesSubCategory) {
          const customerName = order.customerName || order.customer?.name || 'אורח';
          const key = order.customerId || customerName;
          if (!purchasers[key]) {
            purchasers[key] = { name: customerName, quantity: 0, orders: [] };
          }
          purchasers[key].quantity += item.quantity;
          if (!purchasers[key].orders.includes(order.id)) {
            purchasers[key].orders.push(order.id);
          }
        }
      });
    });
    return Object.values(purchasers);
  };

  const currentPurchasers = React.useMemo(() => {
    if (activeReport !== 'purchasers') return [];
    return getProductPurchasers(selectedProduct, selectedCategory, selectedSubCategory);
  }, [activeReport, selectedProduct, selectedCategory, selectedSubCategory, orders, products]);

  const exportPurchasersToExcel = () => {
    const data: any[] = [];
    orders.forEach(order => {
      order.items.forEach(item => {
        const product = products.find(p => p.id === item.productId);
        if (product) {
          const itemName = item.variantName ? `${product.name} - ${item.variantName}` : product.name;
          data.push({
            'תאריך': order.createdAt?.toDate()?.toLocaleDateString('he-IL') || '',
            'מספר הזמנה': order.id.slice(0, 8),
            'שם מוצר': itemName,
            'מק"ט': product.sku,
            'שם לקוח': order.customerName || order.customer?.name || 'אורח',
            'כמות שנרכשה': item.quantity,
            'מחיר יחידה': item.price,
            'סה"כ': item.price * item.quantity,
            _sku: product.sku // Hidden field for sorting
          });
        }
      });
    });

    if (data.length === 0) {
      toast.error('אין נתוני רכישות לייצוא');
      return;
    }

    // Sort by SKU ascending
    data.sort((a, b) => (a._sku || '').localeCompare(b._sku || '', undefined, { numeric: true }));

    // Remove hidden field
    const finalData = data.map(({ _sku, ...rest }) => rest);

    const ws = XLSX.utils.json_to_sheet(finalData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'רוכשים');
    XLSX.writeFile(wb, `דוח_רוכשים_${new Date().toLocaleDateString('he-IL').replace(/\//g, '-')}.xlsx`);
  };

  const handlePrintPurchasers = () => {
    const detailedPurchases: any[] = [];
    orders.forEach(order => {
      order.items.forEach(item => {
        const product = products.find(p => p.id === item.productId);
        if (!product) return;

        const matchesProduct = selectedProduct ? item.productId === selectedProduct : true;
        const matchesCategory = selectedCategory === 'all' || product.categoryId === selectedCategory;
        const matchesSubCategory = selectedSubCategory === 'all' || product.subCategoryId === selectedSubCategory;

        if (matchesProduct && matchesCategory && matchesSubCategory) {
          const itemName = item.variantName ? `${product.name} - ${item.variantName}` : product.name;
          detailedPurchases.push({
            date: order.createdAt?.toDate()?.toLocaleDateString('he-IL') || '',
            orderId: order.id.slice(0, 8),
            productName: itemName,
            sku: product.sku,
            customerName: order.customerName || order.customer?.name || 'אורח',
            category: getCategoryName(product.categoryId),
            subCategory: getSubCategoryName(product.subCategoryId),
            quantity: item.quantity,
            price: item.price,
            total: item.price * item.quantity
          });
        }
      });
    });

    // Sort by SKU ascending
    detailedPurchases.sort((a, b) => (a.sku || '').localeCompare(b.sku || '', undefined, { numeric: true }));

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const productName = selectedProduct ? products.find(p => p.id === selectedProduct)?.name : 'כל המוצרים';
    const categoryName = selectedCategory !== 'all' ? categories.find(c => c.id === selectedCategory)?.name : 'כל הקטגוריות';
    const subCategoryName = selectedSubCategory !== 'all' ? subCategories.find(s => s.id === selectedSubCategory)?.name : 'כל התת-קטגוריות';

    printWindow.document.write(`
      <html dir="rtl">
        <head>
          <title>דוח רוכשי מוצרים - ${productName}</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; margin: 0; }
            table { width: 100%; border-collapse: collapse; margin-top: 30px; }
            th, td { border: 1px solid #e5e7eb; padding: 12px; text-align: right; font-size: 12px; }
            th { background-color: #f9fafb; font-weight: bold; color: #374151; }
            h1 { text-align: center; color: #111827; margin-bottom: 5px; }
            .meta { text-align: center; margin-bottom: 40px; color: #6b7280; font-size: 12px; }
            .header { border-bottom: 2px solid #111827; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
            .branding { text-align: right; }
            .logo { max-height: 60px; margin-bottom: 10px; }
            @media print {
              body { padding: 0; }
              @page { margin: 1cm; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="branding">
              ${config?.logoUrl ? `<img src="${config.logoUrl}" class="logo" alt="Logo" />` : ''}
              <p style="font-size: 18px; font-weight: bold; color: #111827; margin-bottom: 4px;">${config?.orgName || config?.siteName || 'מערכת רכש'}</p>
              <p style="font-size: 14px; color: #6b7280;">${config?.siteName}</p>
            </div>
            <div style="text-align: left;">
              <h1>דוח רוכשי מוצרים</h1>
              <p class="meta">תאריך הפקה: ${new Date().toLocaleString('he-IL')}</p>
            </div>
          </div>
          <div class="meta" style="text-align: right; margin-bottom: 20px;">
            <p>מוצר: <strong>${productName}</strong></p>
            <p>קטגוריה: <strong>${categoryName}</strong> | תת-קטגוריה: <strong>${subCategoryName}</strong></p>
          </div>
          <table>
            <thead>
              <tr>
                <th>תאריך</th>
                <th>מוצר</th>
                <th>קטגוריה / תת-קטגוריה</th>
                <th>מק"ט</th>
                <th>שם הלקוח</th>
                <th>כמות</th>
                <th>סה"כ</th>
              </tr>
            </thead>
            <tbody>
              ${detailedPurchases.map(p => `
                <tr>
                  <td>${p.date}</td>
                  <td style="font-weight: bold;">
                    ${p.productName}
                    <div style="font-size: 10px; color: #6b7280; font-weight: normal; margin-top: 2px;">
                      ${p.category} > ${p.subCategory}
                    </div>
                  </td>
                  <td>${p.sku}</td>
                  <td>${p.customerName}</td>
                  <td>${p.quantity} יח'</td>
                  <td style="font-weight: bold;">₪${p.total.toLocaleString()}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div style="margin-top: 20px; text-align: left; font-weight: bold;">
            סה"כ פריטים: ${detailedPurchases.reduce((sum, p) => sum + p.quantity, 0)} | סה"כ הכנסות: ₪${detailedPurchases.reduce((sum, p) => sum + p.total, 0).toLocaleString()}
          </div>
          <script>
            window.onload = () => {
              window.print();
              window.onafterprint = () => window.close();
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const saveConfig = async () => {
    if (!config) return;
    setIsSavingConfig(true);
    try {
      await setDoc(doc(db, 'config', 'system'), config);
      toast.success('הגדרות המייל נשמרו בהצלחה');
    } catch (err) {
      console.error('Error saving config:', err);
      toast.error('שגיאה בשמירת ההגדרות');
    } finally {
      setIsSavingConfig(false);
    }
  };

  const handleGenerateReport = async () => {
    if (reportOutput === 'email' && config?.emailSettings?.disableAllEmails) {
      toast.error('מערכת המיילים מושהית. לא ניתן לשלוח דוחות במייל.');
      return;
    }

    if (reportOutput === 'email' && !config?.emailSettings?.reportEmail) {
      toast.error('נא להגדיר אימייל לדיווחים בהגדרות');
      return;
    }

    setGeneratingReport(true);
    const toastId = toast.loading(
      reportOutput === 'email' ? 'מפיק דוח ושולח למייל...' : 
      reportOutput === 'pdf' ? 'מפיק דוח להדפסה...' : 
      reportOutput === 'view' ? 'מפיק דוח לצפייה...' : 'מפיק דוח אקסל...', 
      { id: 'report-gen' }
    );

    try {
      let subject = '';
      if (reportType === 'daily') {
        subject = `דוח יומי - ${new Date().toLocaleDateString('he-IL').replace(/\//g, '-')}`;
      } else if (reportType === 'monthly') {
        subject = `דוח חודשי - ${new Date().toLocaleString('he-IL', { month: 'long', year: 'numeric' })}`;
      } else if (reportType === 'buyers') {
        subject = `דוח רוכשי מוצרים - ${new Date().toLocaleDateString('he-IL').replace(/\//g, '-')}`;
      } else if (reportType === 'range') {
        subject = `דוח לתקופה ${reportDateRange.start} עד ${reportDateRange.end}`;
      }
      
      // Sanitize subject for filename
      const safeFilename = subject.replace(/[*?:"<>|\\\/]/g, '_');

      let q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
      
      if (reportType === 'daily') {
        const today = new Date();
        today.setHours(0,0,0,0);
        q = query(collection(db, 'orders'), where('createdAt', '>=', today), orderBy('createdAt', 'desc'));
      } else if (reportType === 'monthly') {
        const firstDay = new Date();
        firstDay.setDate(1);
        firstDay.setHours(0,0,0,0);
        q = query(collection(db, 'orders'), where('createdAt', '>=', firstDay), orderBy('createdAt', 'desc'));
      } else if (reportType === 'range' && (reportDateRange.start || reportDateRange.end)) {
        const start = reportDateRange.start ? new Date(reportDateRange.start) : new Date(0);
        const end = reportDateRange.end ? new Date(reportDateRange.end) : new Date();
        end.setHours(23,59,59,999);
        q = query(collection(db, 'orders'), where('createdAt', '>=', start), where('createdAt', '<=', end), orderBy('createdAt', 'desc'));
      }

      const ordersSnap = await getDocs(q);
      let reportOrders = ordersSnap.docs.map(d => ({ id: d.id, ...d.data() } as any));

      if (reportType === 'buyers') {
        if (selectedProductId !== 'all') {
          reportOrders = reportOrders.filter((o: any) => o.items?.some((i: any) => i.productId === selectedProductId));
        } else if (selectedCategory !== 'all' || selectedSubCategory !== 'all') {
          const filteredProducts = products.filter(p => 
            (selectedCategory === 'all' || p.categoryId === selectedCategory) && 
            (selectedSubCategory === 'all' || p.subCategoryId === selectedSubCategory)
          ).map(p => p.id);
          reportOrders = reportOrders.filter((o: any) => o.items?.some((i: any) => filteredProducts.includes(i.productId)));
        }
      }

      // Sort items within each order by SKU
      reportOrders = reportOrders.map((o: any) => ({
        ...o,
        items: [...(o.items || [])].sort((a, b) => (a.sku || '').localeCompare(b.sku || '', undefined, { numeric: true }))
      }));

      let detailedPurchases: any[] = [];
      if (reportType === 'buyers') {
        reportOrders.forEach(order => {
          order.items?.forEach((item: any) => {
            const product = products.find(p => p.id === item.productId);
            if (!product) return;

            const matchesProduct = selectedProductId !== 'all' ? item.productId === selectedProductId : true;
            const matchesCategory = selectedCategory === 'all' || product.categoryId === selectedCategory;
            const matchesSubCategory = selectedSubCategory === 'all' || product.subCategoryId === selectedSubCategory;

            if (matchesProduct && matchesCategory && matchesSubCategory) {
              const itemName = item.variantName ? `${product.name} - ${item.variantName}` : product.name;
              detailedPurchases.push({
                date: order.createdAt?.toDate()?.toLocaleDateString('he-IL') || '',
                orderId: order.orderNumber || order.id.slice(-6),
                productName: itemName,
                sku: product.sku,
                customerName: order.customerName || order.customer?.name || 'אורח',
                category: getCategoryName(product.categoryId),
                subCategory: getSubCategoryName(product.subCategoryId),
                quantity: item.quantity,
                price: item.price,
                total: item.price * item.quantity
              });
            }
          });
        });

        // Sort by SKU ascending
        detailedPurchases.sort((a, b) => (a.sku || '').localeCompare(b.sku || '', undefined, { numeric: true }));
      }

      if (reportOutput === 'email') {
        let emailTableHtml = '';
        if (reportType === 'buyers') {
          emailTableHtml = `
            <table style="width: 100%; border-collapse: collapse; margin-top: 20px; direction: rtl;">
              <thead>
                <tr style="background-color: #f3f4f6;">
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">תאריך</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">מוצר</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">מק"ט</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">לקוח</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">כמות</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">סה"כ</th>
                </tr>
              </thead>
              <tbody>
                ${detailedPurchases.map(p => `
                  <tr>
                    <td style="border: 1px solid #ddd; padding: 10px;">${p.date}</td>
                    <td style="border: 1px solid #ddd; padding: 10px; font-weight: bold;">
                      ${p.productName}
                      <div style="font-size: 10px; color: #666; font-weight: normal;">
                        ${p.category} > ${p.subCategory}
                      </div>
                    </td>
                    <td style="border: 1px solid #ddd; padding: 10px;">${p.sku}</td>
                    <td style="border: 1px solid #ddd; padding: 10px;">${p.customerName}</td>
                    <td style="border: 1px solid #ddd; padding: 10px;">${p.quantity} יח'</td>
                    <td style="border: 1px solid #ddd; padding: 10px; font-weight: bold;">₪${p.total.toLocaleString()}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
            <div style="margin-top: 20px; font-weight: bold;">
              סה"כ פריטים: ${detailedPurchases.reduce((sum, p) => sum + p.quantity, 0)} | סה"כ הכנסות: ₪${detailedPurchases.reduce((sum, p) => sum + p.total, 0).toLocaleString()}
            </div>
          `;
        } else {
          emailTableHtml = `
            <table style="width: 100%; border-collapse: collapse; margin-top: 20px; direction: rtl;">
              <thead>
                <tr style="background-color: #f3f4f6;">
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">מספר הזמנה</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">לקוח</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">פריטים</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">סה"כ</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">תאריך</th>
                </tr>
              </thead>
              <tbody>
                ${reportOrders.map((o: any) => {
                  const customerDisplay = o.customerName || o.customer?.name || '-';
                  const customerDetails = (config?.customerFormFields || [])
                    .filter((f: any) => !f.hideInReports)
                    .map((field: any) => {
                    const val = o.customer?.[field.id] || o.customer?.[field.label];
                    if (!val) return '';
                    return `<div style="font-size: 11px; color: #666;">${field.label}: ${val}</div>`;
                  }).join('') + Object.entries(o.customer || {}).map(([key, val]) => {
                    const label = getFieldLabel(key);
                    const formField = config?.customerFormFields?.find((f: any) => f.id === key || f.label === label);
                    if (formField?.hideInReports || key === 'name') return '';
                    const alreadyShown = config?.customerFormFields?.some((f: any) => !f.hideInReports && (f.id === key || f.label === label));
                    if (alreadyShown) return '';
                    return `<div style="font-size: 11px; color: #666;">${label}: ${val}</div>`;
                  }).join('');

                  return `
                    <tr>
                      <td style="border: 1px solid #ddd; padding: 10px;">${o.orderNumber || o.id.slice(-6)}</td>
                      <td style="border: 1px solid #ddd; padding: 10px;">
                        <div style="font-weight: bold;">${customerDisplay}</div>
                        ${customerDetails}
                      </td>
                      <td style="border: 1px solid #ddd; padding: 10px;">
                        ${o.items?.map((i: any) => {
                          const p = products.find(prod => prod.id === i.productId);
                          let itemText = `<strong>${i.name}</strong> (${i.quantity})`;
                          if (p) {
                            const cat = getCategoryName(p.categoryId);
                            const subCat = getSubCategoryName(p.subCategoryId);
                            itemText += `<br/><span style="font-size: 10px; color: #666;">${cat} > ${subCat}</span>`;
                          }
                          if (p?.sku) itemText += `<br/><span style="font-size: 11px; color: #888;">מק"ט: ${p.sku}</span>`;
                          if (p?.description) itemText += `<br/><span style="font-size: 11px; font-style: italic;">${p.description}</span>`;
                          return `<div style="margin-bottom: 8px;">${itemText}</div>`;
                        }).join('')}
                      </td>
                      <td style="border: 1px solid #ddd; padding: 10px;">${o.totalAmount?.toLocaleString()} ₪</td>
                      <td style="border: 1px solid #ddd; padding: 10px;">${o.createdAt?.toDate()?.toLocaleString('he-IL')}</td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
            <div style="margin-top: 20px; font-weight: bold;">
              סה"כ הזמנות: ${reportOrders.length} | סה"כ הכנסות: ${reportOrders.reduce((sum: number, o: any) => sum + (o.totalAmount || 0), 0).toLocaleString()} ₪
            </div>
          `;
        }

        const html = `
          <div dir="rtl" style="font-family: Arial, sans-serif; color: #333; text-align: right;">
            <h2 style="color: #4f46e5;">${subject} - ${config?.orgName || config?.siteName}</h2>
            <hr />
            ${emailTableHtml}
          </div>
        `;

        await sendEmail({
          to: config?.emailSettings?.reportEmail || '',
          subject: `${subject} - ${config?.orgName || config?.siteName}`,
          html
        });

        toast.success('הדוח הונפק ונשלח למייל', { id: toastId });
      } else if (reportOutput === 'pdf' || reportOutput === 'view') {
        const printWindow = window.open('', '_blank');
        if (!printWindow) {
          toast.error('נא לאפשר חלונות קופצים בדפדפן', { id: toastId });
          return;
        }

        let tableHtml = '';
        if (reportType === 'buyers') {
          const productName = selectedProductId !== 'all' ? products.find(p => p.id === selectedProductId)?.name : 'כל המוצרים';
          
          tableHtml = `
            <p style="color: #666; margin-bottom: 20px;">מוצר: <strong>${productName}</strong> | קטגוריה: ${selectedCategory !== 'all' ? categories.find(c => c.id === selectedCategory)?.name : 'הכל'} | תת-קטגוריה: ${selectedSubCategory !== 'all' ? subCategories.find(s => s.id === selectedSubCategory)?.name : 'הכל'}</p>
            <table>
              <thead>
                <tr>
                  <th>תאריך</th>
                  <th>מוצר</th>
                  <th>מק"ט</th>
                  <th>שם הלקוח</th>
                  <th>כמות</th>
                  <th>סה"כ</th>
                </tr>
              </thead>
              <tbody>
                ${detailedPurchases.map(p => `
                  <tr>
                    <td>${p.date}</td>
                    <td style="font-weight: bold;">
                      ${p.productName}
                      <div style="font-size: 10px; color: #6b7280; font-weight: normal;">
                        ${p.category} > ${p.subCategory}
                      </div>
                    </td>
                    <td>${p.sku}</td>
                    <td>${p.customerName}</td>
                    <td>${p.quantity} יח'</td>
                    <td style="font-weight: bold;">₪${p.total.toLocaleString()}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
            <div style="margin-top: 20px; text-align: left; font-weight: bold;">
              סה"כ פריטים: ${detailedPurchases.reduce((sum, p) => sum + p.quantity, 0)} | סה"כ הכנסות: ₪${detailedPurchases.reduce((sum, p) => sum + p.total, 0).toLocaleString()}
            </div>
          `;
        } else {
          tableHtml = `
            <table>
              <thead>
                <tr>
                  <th>מספר הזמנה</th>
                  <th>לקוח</th>
                  <th>פריטים</th>
                  <th>סה"כ</th>
                  <th>תאריך</th>
                </tr>
              </thead>
              <tbody>
                ${reportOrders.map((o: any) => {
                  const customerDisplay = o.customerName || o.customer?.name || '-';
                  const customerDetails = (config?.customerFormFields || [])
                    .filter((f: any) => !f.hideInReports)
                    .map((field: any) => {
                    const val = o.customer?.[field.id] || o.customer?.[field.label];
                    if (!val) return '';
                    return `<div style="font-size: 11px; color: #6b7280;">${field.label}: ${val}</div>`;
                  }).join('') + Object.entries(o.customer || {}).map(([key, val]) => {
                    const label = getFieldLabel(key);
                    const formField = config?.customerFormFields?.find((f: any) => f.id === key || f.label === label);
                    if (formField?.hideInReports || key === 'name') return '';
                    const alreadyShown = config?.customerFormFields?.some((f: any) => !f.hideInReports && (f.id === key || f.label === label));
                    if (alreadyShown) return '';
                    return `<div style="font-size: 11px; color: #6b7280;">${label}: ${val}</div>`;
                  }).join('');

                  return `
                    <tr>
                      <td>${o.orderNumber || o.id.slice(-6)}</td>
                      <td>
                        <div style="font-weight: bold;">${customerDisplay}</div>
                        ${customerDetails}
                      </td>
                      <td>
                        ${o.items?.map((i: any) => {
                          const p = products.find(prod => prod.id === i.productId);
                          let itemText = `<strong>${i.name}</strong> (${i.quantity})`;
                          if (p) {
                            const cat = getCategoryName(p.categoryId);
                            const subCat = getSubCategoryName(p.subCategoryId);
                            itemText += `<br/><span style="font-size: 10px; color: #6b7280;">${cat} > ${subCat}</span>`;
                          }
                          if (p?.sku) itemText += `<br/><span style="font-size: 11px; color: #9ca3af;">מק"ט: ${p.sku}</span>`;
                          if (p?.description) itemText += `<br/><span style="font-size: 11px; font-style: italic;">${p.description}</span>`;
                          return `<div style="margin-bottom: 8px;">${itemText}</div>`;
                        }).join('')}
                      </td>
                      <td style="font-weight: bold;">₪${o.totalAmount?.toLocaleString()}</td>
                      <td>${o.createdAt?.toDate()?.toLocaleString('he-IL')}</td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          `;
        }

        const html = `
          <html dir="rtl">
            <head>
              <title>${subject} - ${config?.orgName || config?.siteName}</title>
              <style>
                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; margin: 0; }
                table { width: 100%; border-collapse: collapse; margin-top: 30px; }
                th, td { border: 1px solid #e5e7eb; padding: 12px; text-align: right; font-size: 14px; }
                th { background-color: #f9fafb; font-weight: bold; color: #374151; }
                h1 { text-align: center; color: #111827; margin-bottom: 5px; }
                .meta { text-align: center; margin-bottom: 40px; color: #6b7280; font-size: 12px; }
                .header { border-bottom: 2px solid #111827; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
                .branding { text-align: right; }
                .logo { max-height: 60px; margin-bottom: 10px; }
                @media print {
                  body { padding: 0; }
                  @page { margin: 1cm; }
                }
              </style>
            </head>
            <body>
              <div class="header">
                <div class="branding">
                  ${config?.logoUrl ? `<img src="${config.logoUrl}" class="logo" alt="Logo" />` : ''}
                  <p style="font-size: 18px; font-weight: bold; color: #111827; margin-bottom: 4px;">${config?.orgName || config?.siteName || 'מערכת רכש'}</p>
                  <p style="font-size: 14px; color: #6b7280;">${config?.siteName}</p>
                </div>
                <div style="text-align: left;">
                  <h1>${subject}</h1>
                  <p class="meta">תאריך הפקה: ${new Date().toLocaleDateString('he-IL')} בשעה ${new Date().toLocaleTimeString('he-IL')}</p>
                </div>
              </div>
              ${tableHtml}
              <div style="margin-top: 30px; text-align: left; font-size: 18px; font-weight: bold;">
                סה"כ הזמנות: ${reportOrders.length} | סה"כ הכנסות: ₪${reportOrders.reduce((sum: number, o: any) => sum + (o.totalAmount || 0), 0).toLocaleString()}
              </div>
              <script>
                window.onload = () => {
                  ${reportOutput === 'pdf' ? `
                    setTimeout(() => {
                      window.print();
                    }, 500);
                  ` : ''}
                };
              </script>
            </body>
          </html>
        `;

        printWindow.document.write(html);
        printWindow.document.close();
        toast.success(reportOutput === 'pdf' ? 'דוח ההדפסה מוכן' : 'הדוח נפתח לצפייה', { id: toastId });
      } else if (reportOutput === 'excel') {
        const wb = XLSX.utils.book_new();
        
        // Main Sheet
        let mainData: any[] = [];
        if (reportType === 'buyers') {
          mainData = detailedPurchases.map(p => ({
            'תאריך': p.date,
            'מספר הזמנה': p.orderId,
            'מוצר': p.productName,
            'קטגוריה': p.category,
            'תת קטגוריה': p.subCategory,
            'מק"ט': p.sku,
            'לקוח': p.customerName,
            'כמות': p.quantity,
            'מחיר ליחידה': p.price,
            'סה"כ': p.total
          }));
        } else {
          mainData = reportOrders.map((o: any) => {
            const row: any = {
              'מספר הזמנה': o.orderNumber || o.id.slice(-6),
              'תאריך': o.createdAt?.toDate()?.toLocaleString('he-IL'),
              'סטטוס': o.status === 'pending' ? 'ממתין' : o.status === 'completed' ? 'הושלם' : 'בוטל',
              'סה"כ': o.totalAmount
            };

            // Add customer fields dynamically based on form config
            (config?.customerFormFields || []).filter((f: any) => !f.hideInReports).forEach((field: any) => {
              row[field.label] = o.customer?.[field.id] || o.customer?.[field.label] || '-';
            });

            // Add any other customer fields not in config
            Object.entries(o.customer || {}).forEach(([key, val]) => {
              const label = getFieldLabel(key);
              const formField = config?.customerFormFields?.find((f: any) => f.id === key || f.label === label);
              if (!formField?.hideInReports && !row[label] && key !== 'name') row[label] = val;
            });

            row['פריטים'] = o.items?.map((i: any) => {
              const p = products.find(prod => prod.id === i.productId);
              let itemText = `${i.name} (${i.quantity})`;
              if (p) {
                const cat = getCategoryName(p.categoryId);
                const subCat = getSubCategoryName(p.subCategoryId);
                itemText += ` [${cat} > ${subCat}]`;
              }
              if (p?.sku) itemText += ` {${p.sku}}`;
              if (p?.description) itemText += ` - ${p.description}`;
              return itemText;
            }).join(' | ');

            return row;
          });
        }
        
        if (mainData.length === 0) {
          mainData = [{ 'הודעה': 'אין נתונים להצגה' }];
        }
        
        const wsMain = XLSX.utils.json_to_sheet(mainData);
        XLSX.utils.book_append_sheet(wb, wsMain, 'כל הנתונים');

        // Additional Sheets per Day or Product
        if (reportType === 'buyers') {
          // Group by Product+Variant
          const itemsInReport = new Map<string, { productId: string, variantId?: string, name: string, sku: string }>();
          reportOrders.forEach((o: any) => {
            o.items?.forEach((i: any) => {
              const product = products.find(p => p.id === i.productId);
              if (product) {
                const key = i.variantId ? `${i.productId}_${i.variantId}` : i.productId;
                const itemName = i.variantName ? `${product.name} - ${i.variantName}` : product.name;
                if (!itemsInReport.has(key)) {
                  itemsInReport.set(key, { productId: i.productId, variantId: i.variantId, name: itemName, sku: product.sku });
                }
              }
            });
          });
          
          const sortedItems = Array.from(itemsInReport.values()).sort((a, b) => (a.sku || '').localeCompare(b.sku || '', undefined, { numeric: true }));

          sortedItems.forEach((itemInfo) => {
            const pData = reportOrders
              .flatMap((o: any) => {
                const matchedItems = (o.items || []).filter((i: any) => i.productId === itemInfo.productId && i.variantId === itemInfo.variantId);
                return matchedItems.map((mi: any) => ({
                  'מספר הזמנה': o.orderNumber || o.id.slice(-6),
                  'לקוח': o.customer?.name || o.customerName || '-',
                  'כמות': mi.quantity || 0,
                  'מחיר ליחידה': mi.price || 0,
                  'תאריך': o.createdAt?.toDate()?.toLocaleString('he-IL')
                }));
              });
            
            if (pData.length > 0) {
              const ws = XLSX.utils.json_to_sheet(pData);
              let safeSheetName = String(itemInfo.name).replace(/[*?:\/\\\[\]]/g, '').trim().slice(0, 31) || 'Sheet';
              
              let counter = 1;
              let finalSheetName = safeSheetName;
              while (wb.SheetNames.includes(finalSheetName)) {
                const suffix = `_${counter}`;
                finalSheetName = safeSheetName.slice(0, 31 - suffix.length) + suffix;
                counter++;
              }
              
              XLSX.utils.book_append_sheet(wb, ws, finalSheetName);
            }
          });
        } else {
          // Group by Day
          const daysInReport = Array.from(new Set(reportOrders.map((o: any) => o.createdAt?.toDate()?.toLocaleDateString('he-IL')))).filter(Boolean);
          daysInReport.forEach((day: any) => {
            const dData = reportOrders
              .filter((o: any) => o.createdAt?.toDate()?.toLocaleDateString('he-IL') === day)
              .map((o: any) => ({
                'מספר הזמנה': o.orderNumber || o.id.slice(-6),
                'לקוח': o.customer?.name || o.customerName || '-',
                'פריטים': o.items?.map((i: any) => {
                  const p = products.find(prod => prod.id === i.productId);
                  let itemText = `${i.name} (${i.quantity})`;
                  if (p?.sku) itemText = `${i.name} [${p.sku}] (${i.quantity})`;
                  if (p?.description) itemText += ` - ${p.description}`;
                  return itemText;
                }).join(', '),
                'סה"כ': o.totalAmount,
                'תאריך': o.createdAt?.toDate()?.toLocaleString('he-IL')
              }));
            if (dData.length > 0) {
              const ws = XLSX.utils.json_to_sheet(dData);
              let safeSheetName = String(day).replace(/[*?:\/\\\[\]]/g, '-').trim().slice(0, 31) || 'Sheet';
              
              let counter = 1;
              let finalSheetName = safeSheetName;
              while (wb.SheetNames.includes(finalSheetName)) {
                const suffix = `_${counter}`;
                finalSheetName = safeSheetName.slice(0, 31 - suffix.length) + suffix;
                counter++;
              }
              
              XLSX.utils.book_append_sheet(wb, ws, finalSheetName);
            }
          });
        }

        XLSX.writeFile(wb, `${safeFilename}.xlsx`);
        toast.success('דוח אקסל הופק בהצלחה', { id: toastId });
      }

      setShowReportModal(false);
    } catch (err) {
      console.error('Error generating report:', err);
      toast.error('שגיאה בהנפקת הדוח', { id: toastId });
    } finally {
      setGeneratingReport(false);
    }
  };

  const handleBulkExport = async () => {
    const toastId = toast.loading('מפיק דוח להדפסה...', { id: 'pdf-gen' });
    try {
      const printWindow = window.open('', '_blank');
      if (!printWindow) {
        toast.error('נא לאפשר חלונות קופצים בדפדפן', { id: toastId });
        return;
      }

      const ordersToPrint = [...orders]
        .map(o => ({
          ...o,
          items: [...(o.items || [])].sort((a, b) => (a.sku || '').localeCompare(b.sku || '', undefined, { numeric: true }))
        }))
        .sort((a, b) => (b.orderNumber || 0) - (a.orderNumber || 0));

      const html = `
        <html dir="rtl">
          <head>
            <title>דוח כל ההזמנות - ${config?.orgName || config?.siteName || 'מערכת רכש'}</title>
            <style>
              body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 0; margin: 0; background: #f3f4f6; }
              .order-page { 
                background: white; 
                width: 210mm; 
                min-height: 297mm; 
                padding: 20mm; 
                margin: 10mm auto; 
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
                page-break-after: always;
                box-sizing: border-box;
              }
              .header { border-bottom: 2px solid #111827; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
              .branding { text-align: right; }
              .logo { max-height: 60px; margin-bottom: 10px; }
              h1 { text-align: center; color: #111827; margin-bottom: 5px; font-size: 24px; }
              .order-meta { display: flex; justify-content: space-between; margin-bottom: 30px; }
              .customer-info { margin-bottom: 30px; }
              table { width: 100%; border-collapse: collapse; margin-top: 20px; }
              th, td { border-bottom: 1px solid #e5e7eb; padding: 12px; text-align: right; font-size: 14px; }
              th { font-weight: bold; color: #374151; border-bottom: 2px solid #111827; }
              .total-row { font-size: 18px; font-weight: bold; margin-top: 30px; text-align: left; }
              .footer { margin-top: 50px; padding-top: 20px; border-top: 1px solid #e5e7eb; text-align: center; font-size: 12px; color: #6b7280; }
              
              @media print {
                body { background: white; }
                .order-page { margin: 0; box-shadow: none; width: 100%; min-height: auto; }
                @page { margin: 0; }
              }
            </style>
          </head>
          <body>
            ${ordersToPrint.map(order => `
              <div class="order-page">
                <div class="header">
                  <div class="branding">
                    ${config?.logoUrl ? `<img src="${config.logoUrl}" class="logo" alt="Logo" />` : ''}
                    <p style="font-size: 18px; font-weight: bold; color: #111827; margin-bottom: 4px;">${config?.orgName || config?.siteName || 'מערכת רכש'}</p>
                    <p style="font-size: 14px; color: #6b7280;">${config?.siteName}</p>
                  </div>
                  <div style="text-align: left;">
                    <h1>סיכום הזמנה</h1>
                    <p style="font-size: 12px; color: #6b7280;">דוח כל ההזמנות</p>
                  </div>
                </div>

                <div class="order-meta">
                  <div>
                    <p style="font-size: 10px; font-bold; color: #9ca3af; text-transform: uppercase;">פרטי הזמנה</p>
                    <p style="font-size: 14px; font-weight: bold;">הזמנה ${order.orderNumber ? `#${order.orderNumber}` : `#${order.id.slice(0, 8)}`}</p>
                    <p style="font-size: 12px; color: #6b7280;">תאריך: ${order.createdAt?.toDate()?.toLocaleString('he-IL') || ''}</p>
                  </div>
                  <div style="text-align: left;">
                    <p style="font-size: 10px; font-bold; color: #9ca3af; text-transform: uppercase;">סטטוס</p>
                    <p style="font-size: 14px; font-weight: bold;">
                      ${order.status === 'pending' ? 'ממתין' : order.status === 'completed' ? 'הושלם' : 'בוטל'}
                    </p>
                  </div>
                </div>

                <div class="customer-info">
                  <p style="font-size: 10px; font-bold; color: #9ca3af; text-transform: uppercase; margin-bottom: 8px;">פרטי לקוח</p>
                  <div style="font-size: 14px;">
                    ${Object.entries(order.customer || {}).map(([key, val]) => `
                      <div><span style="font-weight: bold;">${getFieldLabel(key)}:</span> ${val}</div>
                    `).join('')}
                  </div>
                </div>

                <table>
                  <thead>
                    <tr>
                      <th>מוצר</th>
                      <th>מק"ט</th>
                      <th>כמות</th>
                      <th>מחיר יח'</th>
                      <th>סה"כ</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${order.items.map(item => `
                      <tr>
                        <td style="font-weight: bold;">
                          ${item.name}
                          <div style="font-size: 10px; color: #6b7280; font-weight: normal; margin-top: 2px;">
                            ${(() => {
                              const p = products.find(prod => prod.id === item.productId);
                              return p ? `${getCategoryName(p.categoryId)} > ${getSubCategoryName(p.subCategoryId)}` : '';
                            })()}
                          </div>
                        </td>
                        <td style="color: #6b7280; font-family: monospace;">${item.sku}</td>
                        <td>${item.quantity}</td>
                        <td>₪${item.price.toLocaleString()}</td>
                        <td style="font-weight: bold;">₪${(item.price * item.quantity).toLocaleString()}</td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>

                <div class="total-row">
                  סה"כ לתשלום: <span style="color: #4f46e5; font-size: 24px;">₪${order.totalAmount.toLocaleString()}</span>
                </div>

                <div class="footer">
                  <p style="font-weight: bold; margin-bottom: 4px;">תודה רבה על רכישתך!</p>
                  <p>הופק במערכת ${config?.siteName || 'ניהול הזמנות'} בתאריך ${new Date().toLocaleString('he-IL')}</p>
                </div>
              </div>
            `).join('')}
            <script>
              window.onload = () => {
                setTimeout(() => {
                  window.print();
                  window.onafterprint = () => window.close();
                }, 500);
              };
            </script>
          </body>
        </html>
      `;

      printWindow.document.write(html);
      printWindow.document.close();
      
      toast.success('דוח ההדפסה מוכן', { id: toastId });
    } catch (error) {
      console.error(error);
      toast.error('שגיאה בהפקת הדוח', { id: toastId });
    }
  };

  if (loading) return <div className="p-8 text-center">טוען נתונים...</div>;

  return (
    <div className="p-6 max-w-7xl mx-auto font-sans text-right" dir="rtl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-bold text-zinc-900 tracking-tight">מרכז דוחות</h2>
          <p className="text-zinc-500 mt-1">ניתוח נתונים, מלאי ומכירות</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="sticky top-0 z-10 bg-zinc-50 pt-2 pb-4 mb-4 border-b border-zinc-100 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex gap-2 bg-zinc-100 p-1.5 rounded-2xl w-fit overflow-x-auto max-w-full">
          <button 
            onClick={() => setActiveReport('sales')}
            className={`px-6 py-3 rounded-xl font-bold transition-all whitespace-nowrap ${activeReport === 'sales' ? 'bg-white text-indigo-600 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
          >
            דוח מכירות
          </button>
          <button 
            onClick={() => setActiveReport('inventory')}
            className={`px-6 py-3 rounded-xl font-bold transition-all whitespace-nowrap ${activeReport === 'inventory' ? 'bg-white text-indigo-600 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
          >
            דוח מלאי
          </button>
          <button 
            onClick={() => setActiveReport('purchasers')}
            className={`px-6 py-3 rounded-xl font-bold transition-all whitespace-nowrap ${activeReport === 'purchasers' ? 'bg-white text-indigo-600 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
          >
            רוכשי מוצרים
          </button>
          <button 
            onClick={() => setActiveReport('emails')}
            className={`px-6 py-3 rounded-xl font-bold transition-all whitespace-nowrap ${activeReport === 'emails' ? 'bg-white text-indigo-600 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
          >
            מיילים
          </button>
        </div>
              <div className="flex gap-2">
                <button
                  onClick={handleBulkExport}
                  className="flex items-center gap-2 bg-zinc-900 text-white px-6 py-3 rounded-xl font-bold hover:bg-black transition-all shadow-lg shadow-zinc-200 whitespace-nowrap"
                >
                  <FileDown size={20} />
                  ייצוא כל ההזמנות
                </button>
                <button
                  onClick={() => setShowReportModal(true)}
                  className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 whitespace-nowrap"
                >
                  <FileText size={20} />
                  הנפקת דוחות ידנית
                </button>
              </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl"><TrendingUp size={24} /></div>
            <span className="text-sm font-bold text-zinc-500">סה"כ הכנסות</span>
          </div>
          <p className="text-2xl font-black text-zinc-900">₪{orders.reduce((sum, o) => sum + o.totalAmount, 0).toLocaleString()}</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl"><ShoppingCart size={24} /></div>
            <span className="text-sm font-bold text-zinc-500">הזמנות שבוצעו</span>
          </div>
          <p className="text-2xl font-black text-zinc-900">{orders.length}</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl"><Package size={24} /></div>
            <span className="text-sm font-bold text-zinc-500">מוצרים במלאי</span>
          </div>
          <p className="text-2xl font-black text-zinc-900">{products.length}</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-red-50 text-red-600 rounded-2xl"><AlertTriangle size={24} /></div>
            <span className="text-sm font-bold text-zinc-500">מלאי נמוך</span>
          </div>
          <p className="text-2xl font-black text-zinc-900">{products.filter(p => p.stockQuantity < 10).length}</p>
        </div>
      </div>

      {/* Content */}
      <div className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
        {activeReport === 'emails' && config && (
          <div className="p-6 space-y-8">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-bold text-zinc-900">הגדרות מיילים והתראות</h3>
              <button 
                onClick={saveConfig}
                disabled={isSavingConfig}
                className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all disabled:opacity-50"
              >
                {isSavingConfig ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
                שמור הגדרות
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="bg-zinc-50 p-6 rounded-3xl border border-zinc-100 space-y-4">
                  <h4 className="font-bold text-zinc-900 flex items-center gap-2">
                    <Mail size={18} className="text-zinc-400" />
                    כתובת מייל למערכת
                  </h4>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-zinc-500 mb-1 mr-1">מייל לקבלת דוחות והזמנות:</label>
                      <input 
                        type="email"
                        className="w-full px-4 py-3 bg-white border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-left"
                        dir="ltr"
                        value={config.emailSettings?.reportEmail || ''}
                        onChange={(e) => setConfig({
                          ...config,
                          emailSettings: { ...(config.emailSettings || {} as EmailSettings), reportEmail: e.target.value }
                        })}
                        placeholder="reports@example.com"
                      />
                      <p className="text-xs text-zinc-500 mt-2">כתובת זו תקבל את כל ההתראות, ההזמנות והדוחות מהמערכת.</p>
                    </div>
                  </div>
                </div>

                <div className="bg-zinc-50 p-6 rounded-3xl border border-zinc-100 space-y-4">
                  <h4 className="font-bold text-zinc-900 flex items-center gap-2">
                    <SettingsIcon size={18} className="text-zinc-400" />
                    הגדרות שליחה
                  </h4>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-zinc-500 mb-2 mr-1">ממי יישלח המייל (Sender):</label>
                      <div className="flex gap-2">
                        <button 
                          onClick={async () => {
                            try {
                              const { getAccessToken, connectGmailAccount } = await import('../firebase');
                              const token = await getAccessToken();
                              if (!token) {
                                await connectGmailAccount();
                              }
                              setConfig({
                                ...config,
                                emailSettings: { ...(config.emailSettings || {} as EmailSettings), senderChoice: 'user' }
                              });
                              toast.success('הוגדר לשליחה מהמייל שלך');
                            } catch (e) {
                              toast.error('החיבור ל-Gmail בוטל או נכשל.');
                            }
                          }}
                          className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${config.emailSettings?.senderChoice === 'user' ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-zinc-500 border border-zinc-200'}`}
                        >
                          המייל שלי (דרך Gmail)
                        </button>
                        <button 
                          onClick={() => setConfig({
                            ...config,
                            emailSettings: { ...(config.emailSettings || {} as EmailSettings), senderChoice: 'system' }
                          })}
                          className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${config.emailSettings?.senderChoice === 'system' ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-zinc-500 border border-zinc-200'}`}
                        >
                          מייל המערכת
                        </button>
                      </div>
                      <p className="text-[11px] text-zinc-500 mt-2">מומלץ להשתמש ב-"המייל שלי" כדי שהלקוחות יקבלו את המייל ישירות ממך. בהתחברות הראשונית כבר התבקשת לאשר זאת.</p>
                    </div>

                    <div className="pt-4 border-t border-zinc-200">
                      <label className="block text-xs font-bold text-zinc-500 mb-2 mr-1">כתובת למענה (Reply-To):</label>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => setConfig({
                            ...config,
                            emailSettings: { ...(config.emailSettings || {} as EmailSettings), replyToType: 'sender' }
                          })}
                          className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${config.emailSettings?.replyToType === 'sender' ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-zinc-500 border border-zinc-200'}`}
                        >
                          מייל השולח
                        </button>
                        <button 
                          onClick={() => setConfig({
                            ...config,
                            emailSettings: { ...(config.emailSettings || {} as EmailSettings), replyToType: 'fixed' }
                          })}
                          className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${config.emailSettings?.replyToType === 'fixed' ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-zinc-500 border border-zinc-200'}`}
                        >
                          מייל קבוע
                        </button>
                      </div>
                    </div>
                    {config.emailSettings?.replyToType === 'fixed' && (
                      <input 
                        type="email"
                        className="w-full px-4 py-3 bg-white border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-left"
                        dir="ltr"
                        value={config.emailSettings?.fixedReplyToEmail || ''}
                        onChange={(e) => setConfig({
                          ...config,
                          emailSettings: { ...(config.emailSettings || {} as EmailSettings), fixedReplyToEmail: e.target.value }
                        })}
                        placeholder="reply@example.com"
                      />
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-zinc-50 p-6 rounded-3xl border border-zinc-100 space-y-4">
                  <h4 className="font-bold text-zinc-900 flex items-center gap-2">
                    <Bell size={18} className="text-zinc-400" />
                    התראות במייל
                  </h4>
                  <label htmlFor="disableAllEmails" className="p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center justify-between mb-4 cursor-pointer hover:bg-red-100 transition-colors">
                    <div className="flex items-center gap-3">
                      <AlertTriangle className="text-red-600" size={20} />
                      <div>
                        <p className="font-bold text-red-900 text-sm">השהיית כל מערכת המיילים</p>
                        <p className="text-[10px] text-red-700">כאשר אפשרות זו פעילה, לא יישלחו מיילים כלל מהמערכת.</p>
                      </div>
                    </div>
                    <div className="relative inline-flex items-center cursor-pointer">
                      <input 
                        id="disableAllEmails"
                        type="checkbox" 
                        className="sr-only peer"
                        checked={config.emailSettings?.disableAllEmails || false}
                        onChange={(e) => setConfig({
                          ...config,
                          emailSettings: { ...(config.emailSettings || {} as EmailSettings), disableAllEmails: e.target.checked }
                        } as SystemConfig)}
                      />
                      <div className="w-11 h-6 bg-zinc-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600 pointer-events-none"></div>
                    </div>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { id: 'notifyNewOrder', label: 'הזמנות חדשות' },
                      { id: 'notifyEditOrder', label: 'עריכת הזמנות' },
                      { id: 'notifyDeleteOrder', label: 'מחיקת הזמנות' },
                      { id: 'notifyReservation', label: 'שריוני מלאי' },
                      { id: 'notifyReservationDelete', label: 'מחיקת שריון' },
                      { id: 'notifyReservationToOrder', label: 'שריון להזמנה' },
                      { id: 'notifyLowStock', label: 'מלאי נמוך' },
                      { id: 'autoDailyReport', label: 'דוח יומי אוטומטי' },
                      { id: 'autoWeeklyReport', label: 'דוח שבועי אוטומטי' },
                      { id: 'autoMonthlyReport', label: 'דוח חודשי אוטומטי' }
                    ].map((item) => (
                      <label htmlFor={item.id} key={item.id} className="flex items-center justify-between p-3 bg-white rounded-xl border border-zinc-100 cursor-pointer hover:bg-zinc-50 transition-colors">
                        <span className="font-bold text-zinc-700 text-xs">{item.label}</span>
                        <div className="relative inline-flex items-center cursor-pointer">
                          <input 
                            id={item.id}
                            type="checkbox" 
                            className="sr-only peer"
                            checked={(config.emailSettings as any)?.[item.id] ?? (item.id.startsWith('notify') ? true : false)}
                            onChange={(e) => setConfig({
                              ...config,
                              emailSettings: { ...(config.emailSettings || {} as EmailSettings), [item.id]: e.target.checked }
                            } as SystemConfig)}
                          />
                          <div className="w-9 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600 pointer-events-none"></div>
                        </div>
                      </label>
                    ))}
                  </div>

                  <div className="pt-6 border-t border-zinc-100">
                    <h4 className="font-bold text-zinc-900 flex items-center gap-2 mb-4">
                      <FileText size={18} className="text-zinc-400" />
                      הנפקת דוחות וייצוא
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <button
                        onClick={() => setShowReportModal(true)}
                        className="flex items-center justify-center gap-3 p-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 w-full"
                      >
                        <Send size={20} />
                        <span>הנפקת דוח ידנית</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeReport === 'sales' && (
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-zinc-900">פירוט מכירות</h3>
              <button onClick={exportSalesToExcel} className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-green-700 transition-all">
                <FileDown size={18} />
                ייצוא לאקסל
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-right">
                <thead className="bg-zinc-50 border-b border-zinc-100">
                  <tr>
                    <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">תאריך</th>
                    <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">לקוח</th>
                    <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">סה"כ</th>
                    <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">סטטוס</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100">
                  {orders.slice(0, visibleOrdersCount).map(order => (
                    <tr key={order.id} className="hover:bg-zinc-50 transition-colors">
                      <td className="px-6 py-4 text-sm text-zinc-600">{order.createdAt?.toDate()?.toLocaleDateString('he-IL') || ''}</td>
                      <td className="px-6 py-4 font-bold text-zinc-900">{order.customerName || order.customer?.name || 'אורח'}</td>
                      <td className="px-6 py-4 font-bold text-indigo-600">₪{order.totalAmount.toLocaleString()}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${order.status === 'pending' ? 'bg-amber-100 text-amber-600' : 'bg-green-100 text-green-600'}`}>
                          {order.status === 'pending' ? 'ממתין' : 'הושלם'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {visibleOrdersCount < orders.length && (
              <div className="mt-6 flex justify-center">
                <button
                  onClick={() => setVisibleOrdersCount(prev => prev + 20)}
                  className="px-6 py-2 bg-white border border-zinc-200 rounded-xl text-zinc-600 font-bold hover:bg-zinc-50 transition-colors shadow-sm"
                >
                  טען עוד הזמנות
                </button>
              </div>
            )}
          </div>
        )}

        {activeReport === 'inventory' && (
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-zinc-900">פירוט מלאי</h3>
              <button onClick={exportInventoryToExcel} className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-green-700 transition-all">
                <FileDown size={18} />
                ייצוא לאקסל
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-right">
                <thead className="bg-zinc-50 border-b border-zinc-100">
                  <tr>
                    <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">מוצר</th>
                    <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">קטגוריה</th>
                    <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">תת קטגוריה</th>
                    <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">מלאי</th>
                    <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">מחיר</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100">
                  {products.slice(0, visibleProductsCount).flatMap(product => {
                    if (product.variants && product.variants.length > 0) {
                      return product.variants.map((variant: any) => (
                        <tr key={`${product.id}-${variant.id}`} className="hover:bg-zinc-50 transition-colors">
                          <td className="px-6 py-4 font-bold text-zinc-900">{product.name} <span className="text-zinc-500 font-normal text-sm">({variant.name})</span></td>
                          <td className="px-6 py-4 text-sm text-zinc-600">{getCategoryName(product.categoryId)}</td>
                          <td className="px-6 py-4 text-sm text-zinc-600">{getSubCategoryName(product.subCategoryId)}</td>
                          <td className={`px-6 py-4 font-bold ${variant.stockQuantity < 10 ? 'text-red-600' : 'text-zinc-900'}`}>{variant.stockQuantity}</td>
                          <td className="px-6 py-4 font-bold text-indigo-600">₪{(variant.price !== undefined ? variant.price : product.price).toLocaleString()}</td>
                        </tr>
                      ));
                    }
                    return [(
                      <tr key={product.id} className="hover:bg-zinc-50 transition-colors">
                        <td className="px-6 py-4 font-bold text-zinc-900">{product.name}</td>
                        <td className="px-6 py-4 text-sm text-zinc-600">{getCategoryName(product.categoryId)}</td>
                        <td className="px-6 py-4 text-sm text-zinc-600">{getSubCategoryName(product.subCategoryId)}</td>
                        <td className={`px-6 py-4 font-bold ${product.stockQuantity < 10 ? 'text-red-600' : 'text-zinc-900'}`}>{product.stockQuantity}</td>
                        <td className="px-6 py-4 font-bold text-indigo-600">₪{product.price.toLocaleString()}</td>
                      </tr>
                    )];
                  })}
                </tbody>
              </table>
            </div>
            {visibleProductsCount < products.length && (
              <div className="mt-6 flex justify-center">
                <button
                  onClick={() => setVisibleProductsCount(prev => prev + 20)}
                  className="px-6 py-2 bg-white border border-zinc-200 rounded-xl text-zinc-600 font-bold hover:bg-zinc-50 transition-colors shadow-sm"
                >
                  טען עוד מוצרים
                </button>
              </div>
            )}
          </div>
        )}

        {activeReport === 'purchasers' && (
          <div className="p-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
              <h3 className="text-xl font-bold text-zinc-900">רוכשי מוצרים</h3>
              <div className="flex gap-2">
                <button 
                  onClick={exportPurchasersToExcel} 
                  className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-green-700 transition-all"
                >
                  <FileDown size={18} />
                  אקסל (הכל)
                </button>
                <button 
                  onClick={handlePrintPurchasers} 
                  className="flex items-center gap-2 bg-zinc-900 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-zinc-800 transition-all"
                >
                  <FileText size={18} />
                  הדפסה
                </button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-bold text-zinc-700 mb-2">סינון לפי קטגוריה:</label>
                <select 
                  className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                  value={selectedCategory}
                  onChange={(e) => {
                    setSelectedCategory(e.target.value);
                    setSelectedSubCategory('all');
                    setSelectedProduct(null);
                  }}
                >
                  <option value="all">כל הקטגוריות</option>
                  {categories.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-zinc-700 mb-2">סינון לפי תת-קטגוריה:</label>
                <select 
                  className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                  value={selectedSubCategory}
                  onChange={(e) => {
                    setSelectedSubCategory(e.target.value);
                    setSelectedProduct(null);
                  }}
                  disabled={selectedCategory === 'all'}
                >
                  <option value="all">כל התת-קטגוריות</option>
                  {subCategories.filter(sub => sub.categoryId === selectedCategory).map(sub => (
                    <option key={sub.id} value={sub.id}>{sub.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-bold text-zinc-700 mb-2">בחר מוצר לצפייה ברוכשים:</label>
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                <input 
                  type="text"
                  placeholder="חפש מוצר..."
                  className="w-full pr-10 pl-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              {searchTerm && (
                <div className="mt-2 border border-zinc-100 rounded-xl overflow-hidden max-h-48 overflow-y-auto shadow-lg">
                  {products
                    .filter(p => {
                      const matchesSearch = p.name.includes(searchTerm) || p.sku.includes(searchTerm);
                      const matchesCategory = selectedCategory === 'all' || p.categoryId === selectedCategory;
                      const matchesSubCategory = selectedSubCategory === 'all' || p.subCategoryId === selectedSubCategory;
                      return matchesSearch && matchesCategory && matchesSubCategory;
                    })
                    .map(p => (
                      <button 
                        key={p.id}
                        onClick={() => { setSelectedProduct(p.id); setSearchTerm(''); }}
                        className="w-full text-right px-4 py-3 hover:bg-zinc-50 border-b border-zinc-100 last:border-0 transition-colors"
                      >
                        <div className="flex flex-col">
                          <span className="font-bold">{p.name}</span>
                          <div className="flex gap-2 text-xs text-zinc-400">
                            <span>מק"ט: {p.sku}</span>
                            {p.description && <span className="truncate max-w-[200px]">- {p.description}</span>}
                          </div>
                        </div>
                      </button>
                    ))}
                </div>
              )}
            </div>

            {selectedProduct || selectedCategory !== 'all' || selectedSubCategory !== 'all' ? (
              <div className="space-y-6">
                <div className="flex justify-between items-center bg-indigo-50 p-6 rounded-3xl border border-indigo-100">
                  <div className="flex-1">
                    {selectedProduct ? (
                      <>
                        <h4 className="text-xl font-bold text-indigo-900">{products.find(p => p.id === selectedProduct)?.name}</h4>
                        <div className="flex flex-wrap gap-4 mt-1">
                          <p className="text-sm text-indigo-600 font-bold">מק"ט: {products.find(p => p.id === selectedProduct)?.sku}</p>
                          {products.find(p => p.id === selectedProduct)?.description && (
                            <p className="text-sm text-indigo-500 italic">תיאור: {products.find(p => p.id === selectedProduct)?.description}</p>
                          )}
                        </div>
                      </>
                    ) : (
                      <>
                        <h4 className="text-xl font-bold text-indigo-900">
                          דוח עבור {selectedSubCategory !== 'all' ? subCategories.find(s => s.id === selectedSubCategory)?.name : categories.find(c => c.id === selectedCategory)?.name}
                        </h4>
                        <p className="text-sm text-indigo-600 font-bold mt-1">כל המוצרים בקטגוריה הנבחרת</p>
                      </>
                    )}
                  </div>
                  <button onClick={() => { setSelectedProduct(null); setSelectedCategory('all'); setSelectedSubCategory('all'); }} className="text-indigo-400 hover:text-indigo-600 mr-4"><ChevronLeft size={24} /></button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-right">
                    <thead className="bg-zinc-50 border-b border-zinc-100">
                      <tr>
                        <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">שם הלקוח</th>
                        <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">כמות שנרכשה</th>
                        <th className="px-6 py-4 text-sm font-bold text-zinc-400 uppercase">פעולות</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-100">
                      {currentPurchasers.map((purchaser, idx) => (
                        <tr key={idx} className="hover:bg-zinc-50 transition-colors">
                          <td className="px-6 py-4 font-bold text-zinc-900">{purchaser.name}</td>
                          <td className="px-6 py-4 font-bold text-indigo-600">{purchaser.quantity} יח'</td>
                          <td className="px-6 py-4">
                            <div className="flex gap-2">
                              {purchaser.orders.map(orderId => (
                                <button 
                                  key={orderId}
                                  onClick={() => {
                                    const order = orders.find(o => o.id === orderId);
                                    if (order) setSelectedOrderDetails(order);
                                  }}
                                  className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                  title={`צפה בהזמנה #${orderId.slice(0, 8)}`}
                                >
                                  <ExternalLink size={18} />
                                </button>
                              ))}
                            </div>
                          </td>
                        </tr>
                      ))}
                      {currentPurchasers.length === 0 && (
                        <tr>
                          <td colSpan={3} className="px-6 py-12 text-center text-zinc-400">לא נמצאו רכישות בסינון זה</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="py-20 text-center text-zinc-400 flex flex-col items-center gap-4">
                <Users size={64} strokeWidth={1} />
                <p className="text-lg">בחר מוצר, קטגוריה או תת-קטגוריה כדי לראות את רשימת הרוכשים</p>
              </div>
            )}
          </div>
        )}
      </div>
      {/* Order Details Modal */}
      <AnimatePresence>
        {selectedOrderDetails && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedOrderDetails(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-3xl shadow-2xl max-w-2xl w-full overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                <h3 className="text-xl font-bold text-zinc-900">פרטי הזמנה #{selectedOrderDetails.id.slice(0, 8)}</h3>
                <button onClick={() => setSelectedOrderDetails(null)} className="text-zinc-400 hover:text-zinc-600"><ChevronLeft size={24} /></button>
              </div>
              <div className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-zinc-400">פרטי לקוח:</p>
                    <div className="space-y-1">
                      {Object.entries(selectedOrderDetails.customer || {}).map(([key, val]) => (
                        <p key={key}><span className="font-bold">{getFieldLabel(key)}:</span> {val as string}</p>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-zinc-400">תאריך:</p>
                    <p className="font-bold">{selectedOrderDetails.createdAt?.toDate()?.toLocaleString('he-IL') || ''}</p>
                  </div>
                </div>
                <div className="border border-zinc-100 rounded-2xl overflow-hidden">
                  <table className="w-full text-right">
                    <thead className="bg-zinc-50">
                      <tr>
                        <th className="px-4 py-2 text-xs font-bold text-zinc-400">מוצר</th>
                        <th className="px-4 py-2 text-xs font-bold text-zinc-400">כמות</th>
                        <th className="px-4 py-2 text-xs font-bold text-zinc-400">סה"כ</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-100">
                      {selectedOrderDetails.items.map((item, idx) => (
                        <tr key={idx}>
                          <td className="px-4 py-2 font-bold">{item.name}</td>
                          <td className="px-4 py-2">{item.quantity}</td>
                          <td className="px-4 py-2 font-bold text-indigo-600">₪{item.price * item.quantity}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="flex justify-between items-center pt-4 border-t border-zinc-100">
                  <span className="text-lg font-bold text-zinc-900">סה"כ לתשלום:</span>
                  <span className="text-2xl font-black text-indigo-600">₪{selectedOrderDetails.totalAmount.toLocaleString()}</span>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Print View (Hidden) */}
      <div className="hidden print:block p-8 bg-white text-black" dir="rtl">
        <div className="text-center mb-8 border-b-2 border-zinc-900 pb-4">
          <h1 className="text-3xl font-black">דוח רוכשי מוצרים</h1>
          <p className="text-sm text-zinc-500 mt-2">הופק בתאריך: {new Date().toLocaleDateString('he-IL')} בשעה: {new Date().toLocaleTimeString('he-IL')}</p>
        </div>
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-zinc-100 border-b-2 border-zinc-900">
              <th className="p-3 text-right font-bold border border-zinc-200">תאריך</th>
              <th className="p-3 text-right font-bold border border-zinc-200">מוצר</th>
              <th className="p-3 text-right font-bold border border-zinc-200">מק"ט</th>
              <th className="p-3 text-right font-bold border border-zinc-200">לקוח</th>
              <th className="p-3 text-right font-bold border border-zinc-200">כמות</th>
              <th className="p-3 text-right font-bold border border-zinc-200">סה"כ</th>
            </tr>
          </thead>
          <tbody>
            {orders.flatMap(order => 
              order.items.map((item, idx) => {
                const product = products.find(p => p.id === item.productId);
                return (
                  <tr key={`${order.id}-${idx}`} className="border-b border-zinc-200">
                    <td className="p-3 border border-zinc-200">{order.createdAt?.toDate()?.toLocaleDateString('he-IL') || ''}</td>
                    <td className="p-3 border border-zinc-200 font-bold">
                      {product?.name || item.name}
                      <div className="text-[10px] text-zinc-500 font-normal mt-1">
                        {product ? `${getCategoryName(product.categoryId)} > ${getSubCategoryName(product.subCategoryId)}` : ''}
                      </div>
                    </td>
                    <td className="p-3 border border-zinc-200">{product?.sku || item.sku}</td>
                    <td className="p-3 border border-zinc-200">{order.customerName || order.customer?.name || 'אורח'}</td>
                    <td className="p-3 border border-zinc-200">{item.quantity}</td>
                    <td className="p-3 border border-zinc-200 font-bold">₪{(item.price * item.quantity).toLocaleString()}</td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
        <div className="mt-8 pt-4 border-t-2 border-zinc-900 text-left">
          <p className="text-xl font-black">סה"כ כללי: ₪{orders.reduce((acc, o) => acc + o.totalAmount, 0).toLocaleString()}</p>
        </div>
      </div>
      {/* Report Generation Modal */}
      <AnimatePresence>
        {showReportModal && config && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-indigo-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center text-indigo-600">
                    <FileText size={20} />
                  </div>
                  <h3 className="text-xl font-bold text-zinc-900">הנפקת דוח ידנית</h3>
                </div>
                <button
                  onClick={() => setShowReportModal(false)}
                  className="p-2 hover:bg-white rounded-full transition-colors text-zinc-400"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-6 space-y-6">
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { id: 'daily', label: 'דוח יומי', icon: Calendar },
                    { id: 'monthly', label: 'דוח חודשי', icon: Calendar },
                    { id: 'range', label: 'טווח תאריכים', icon: Calendar },
                    { id: 'buyers', label: 'רוכשי מוצר', icon: Users }
                  ].map((type) => (
                    <button
                      key={type.id}
                      onClick={() => setReportType(type.id as any)}
                      className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all ${reportType === type.id ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-zinc-100 bg-zinc-50 text-zinc-500 hover:border-zinc-200'}`}
                    >
                      <type.icon size={24} />
                      <span className="font-bold text-sm">{type.label}</span>
                    </button>
                  ))}
                </div>

                {(reportType === 'range' || reportType === 'buyers') && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-zinc-700 mb-1">מתאריך</label>
                      <input
                        type="date"
                        className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                        value={reportDateRange.start}
                        onChange={e => setReportDateRange({ ...reportDateRange, start: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-zinc-700 mb-1">עד תאריך</label>
                      <input
                        type="date"
                        className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                        value={reportDateRange.end}
                        onChange={e => setReportDateRange({ ...reportDateRange, end: e.target.value })}
                      />
                    </div>
                  </div>
                )}

                {reportType === 'buyers' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-bold text-zinc-700 mb-1">קטגוריה</label>
                        <select
                          className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                          value={selectedCategory}
                          onChange={e => {
                            setSelectedCategory(e.target.value);
                            setSelectedSubCategory('all');
                            setSelectedProductId('all');
                          }}
                        >
                          <option value="all">כל הקטגוריות</option>
                          {categories.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-zinc-700 mb-1">תת קטגוריה</label>
                        <select
                          className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                          value={selectedSubCategory}
                          onChange={e => {
                            setSelectedSubCategory(e.target.value);
                            setSelectedProductId('all');
                          }}
                          disabled={selectedCategory === 'all'}
                        >
                          <option value="all">כל התת-קטגוריות</option>
                          {subCategories.filter(sc => sc.categoryId === selectedCategory).map(sc => (
                            <option key={sc.id} value={sc.id}>{sc.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-zinc-700 mb-1">בחר מוצר</label>
                      <select
                        className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                        value={selectedProductId}
                        onChange={e => setSelectedProductId(e.target.value)}
                      >
                        <option value="all">כל המוצרים</option>
                        {products
                          .filter(p => (selectedCategory === 'all' || p.categoryId === selectedCategory) && (selectedSubCategory === 'all' || p.subCategoryId === selectedSubCategory))
                          .map(p => (
                            <option key={p.id} value={p.id}>
                              {p.name} {p.sku ? `[${p.sku}]` : ''}
                            </option>
                          ))}
                      </select>
                      {selectedProductId !== 'all' && (() => {
                        const product = products.find(p => p.id === selectedProductId);
                        if (!product) return null;
                        return (
                          <div className="mt-2 p-3 bg-zinc-50 rounded-xl border border-zinc-100 text-xs">
                            <p className="font-bold text-zinc-900">מק"ט: {product.sku || '-'}</p>
                            <p className="text-zinc-500 mt-1">{product.description || 'אין תיאור למוצר זה'}</p>
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-bold text-zinc-700 mb-3">בחר פורמט פלט</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[
                      { id: 'email', label: 'שלח למייל', icon: Mail },
                      { id: 'pdf', label: 'הורד PDF', icon: FileText },
                      { id: 'excel', label: 'ייצא אקסל', icon: FileDown },
                      { id: 'view', label: 'צפה בדפדפן', icon: Eye }
                    ].filter(output => !(output.id === 'email' && config?.emailSettings?.disableAllEmails)).map((output) => (
                      <button
                        key={output.id}
                        onClick={() => setReportOutput(output.id as any)}
                        className={`flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all ${reportOutput === output.id ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-zinc-100 bg-zinc-50 text-zinc-500 hover:border-zinc-200'}`}
                      >
                        <output.icon size={20} />
                        <span className="font-bold text-xs">{output.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {reportOutput === 'email' && (
                  <p className="text-sm text-zinc-500">
                    הדוח יישלח לכתובת: <span className="font-bold text-zinc-900">{config.emailSettings?.reportEmail}</span>
                  </p>
                )}
              </div>

              <div className="p-6 bg-zinc-50 border-t border-zinc-100 flex gap-3">
                <button
                  onClick={() => setShowReportModal(false)}
                  className="flex-1 px-6 py-3 bg-white text-zinc-600 rounded-xl font-bold border border-zinc-200 hover:bg-zinc-100 transition-all"
                >
                  ביטול
                </button>
                <button
                  onClick={handleGenerateReport}
                  disabled={generatingReport}
                  className="flex-1 px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {generatingReport ? <Loader2 className="animate-spin" size={20} /> : (
                    reportOutput === 'email' ? <Send size={20} /> :
                    reportOutput === 'pdf' ? <FileText size={20} /> :
                    reportOutput === 'view' ? <Eye size={20} /> : <FileDown size={20} />
                  )}
                  {reportOutput === 'email' ? 'הנפק ושלח' : 
                   reportOutput === 'pdf' ? 'הנפק והדפס' : 
                   reportOutput === 'view' ? 'צפה בדפדפן' : 'הנפק אקסל'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
