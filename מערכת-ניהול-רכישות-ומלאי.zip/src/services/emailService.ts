import { SystemConfig } from '../types';
import { getAccessToken } from '../firebase';

export interface EmailData {
  to: string;
  subject: string;
  text?: string;
  html?: string;
  userEmail?: string;
  userName?: string;
  replyTo?: string;
  replyToMessageId?: string;
  attachments?: {
    filename: string;
    content: string;
    contentType: string;
  }[];
}

export async function sendEmail(data: EmailData) {
  try {
    const accessToken = await getAccessToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (accessToken) {
      headers['Authorization'] = `Bearer ${accessToken}`;
    }

    const response = await fetch('/api/send-email', {
      method: 'POST',
      headers,
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to send email');
    }

    const result = await response.json();
    if (result.success === false) {
      if (result.reason === 'credentials_missing') {
        console.warn('Email skipped: Credentials missing in server configuration');
      } else if (result.reason === 'bad_credentials') {
        console.warn('Email skipped: Gmail credentials invalid (535 Bad Credentials). Please update App Password in Settings.');
      }
    }
    return result;
  } catch (error) {
    console.error('Error in sendEmail service:', error);
    throw error;
  }
}

export async function testEmailSettings(credentials: { emailUser: string; emailPass: string }) {
  const response = await fetch('/api/test-email', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(credentials),
  });
  return await response.json();
}

export interface EmailHealthStatus {
  healthy: boolean;
  configured: boolean;
  lastChecked: string;
  error: string | null;
  user?: string;
  pendingCount: number;
}

export async function getEmailStatus(): Promise<EmailHealthStatus> {
  try {
    const response = await fetch('/api/email-status');
    if (!response.ok) throw new Error('Failed to get email status');
    return await response.json();
  } catch (err) {
    return {
      healthy: false,
      configured: false,
      lastChecked: '',
      error: 'לא ניתן לתקשר עם שרת הדואר',
      pendingCount: 0
    };
  }
}

export async function checkEmailHealth(): Promise<EmailHealthStatus> {
  const response = await fetch('/api/check-email-health', {
    method: 'POST'
  });
  return await response.json();
}

export async function retryFailedEmails(): Promise<{ success: boolean; total: number; sent: number; remaining: number; error?: string }> {
  const response = await fetch('/api/retry-failed-emails', {
    method: 'POST'
  });
  return await response.json();
}

export async function getPendingEmailsList(): Promise<any[]> {
  try {
    const response = await fetch('/api/pending-emails');
    return await response.json();
  } catch (err) {
    return [];
  }
}

export async function clearPendingEmails(id?: string): Promise<{ success: boolean }> {
  const url = id ? `/api/pending-emails/${id}` : '/api/pending-emails/all';
  const response = await fetch(url, { method: 'DELETE' });
  return await response.json();
}

export function formatOrderEmail(order: any, config: any, customer: any) {
  const date = new Date().toLocaleString('he-IL');
  const itemsHtml = order.items.map((item: any) => `
    <tr>
      <td style="padding: 8px; border-bottom: 1px solid #eee;">${item.name}${item.variantName ? ` - ${item.variantName}` : ''}</td>
      <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: center;">${item.quantity}</td>
      <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: left;">₪${item.price.toLocaleString()}</td>
    </tr>
  `).join('');

  // Helper to get field label
  const getFieldLabel = (fieldId: string) => {
    const field = config?.customerFormFields?.find((f: any) => f.id === fieldId);
    return field?.label || fieldId;
  };

  // Generate customer info HTML dynamically
  const customerInfoHtml = (config?.customerFormFields || []).map((field: any) => {
    const val = customer[field.id] || customer[field.label];
    if (!val) return '';
    return `<p style="margin: 4px 0 0; font-size: 14px;"><strong>${field.label}:</strong> ${val}</p>`;
  }).join('');

  // Add any extra fields not in config
  const extraFieldsHtml = Object.entries(customer).map(([key, val]) => {
    if (['id', 'createdAt', 'lastPurchase', 'uid'].includes(key)) return '';
    const label = getFieldLabel(key);
    const alreadyIncluded = config?.customerFormFields?.some((f: any) => f.label === label || f.id === key);
    if (alreadyIncluded) return '';
    return `<p style="margin: 4px 0 0; font-size: 14px;"><strong>${label}:</strong> ${val}</p>`;
  }).join('');

  const html = `
    <div dir="rtl" style="font-family: sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #eee; border-radius: 12px; overflow: hidden; background: #ffffff;">
      ${config?.logoUrl ? `<div style="padding: 20px; text-align: center; background: #ffffff;"><img src="${config.logoUrl}" alt="Logo" style="max-height: 80px; max-width: 250px; object-fit: contain;" /></div>` : ''}
      <div style="background: #4f46e5; color: white; padding: 24px; text-align: center;">
        <h1 style="margin: 0; font-size: 24px;">אישור הזמנה - ${config.siteName}</h1>
        <p style="margin: 8px 0 0; opacity: 0.8;">הזמנה מספר #${order.orderNumber}</p>
      </div>
      <div style="padding: 24px; line-height: 1.6; color: #374151;">
        <p style="margin: 0 0 16px;">תאריך ושעה: ${date}</p>
        <p style="margin: 0 0 16px;">שלום וברכה,</p>
        <p style="margin: 0 0 24px;">מצו"ב פירוט ההזמנה שביצעתם במערכת עבור <strong>${config.orgName}</strong>:</p>
        
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px;">
          <thead>
            <tr style="background: #f9fafb;">
              <th style="padding: 8px; text-align: right; border-bottom: 2px solid #eee;">מוצר</th>
              <th style="padding: 8px; text-align: center; border-bottom: 2px solid #eee;">כמות</th>
              <th style="padding: 8px; text-align: left; border-bottom: 2px solid #eee;">מחיר</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHtml}
          </tbody>
          <tfoot>
            <tr>
              <td colspan="2" style="padding: 16px 8px; font-weight: bold; text-align: right;">סה"כ לתשלום:</td>
              <td style="padding: 16px 8px; font-weight: bold; text-align: left; color: #4f46e5; font-size: 18px;">₪${order.totalAmount.toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>
        
        <div style="background: #f3f4f6; padding: 16px; border-radius: 8px; margin-bottom: 24px;">
          <p style="margin: 0; font-size: 14px;"><strong>פרטי לקוח:</strong></p>
          ${customerInfoHtml}
          ${extraFieldsHtml}
        </div>
        
        <p style="margin: 0 0 8px;">לפניות ושאלות ניתן לפנות במייל חוזר.</p>
        <p style="margin: 0;">בהצלחה,</p>
        <p style="margin: 4px 0 0; font-weight: bold;">צוות ${config.siteName}</p>
      </div>
      <div style="background: #f9fafb; padding: 16px; text-align: center; font-size: 12px; color: #9ca3af; border-top: 1px solid #eee;">
        <p style="margin: 0;">הודעה זו נשלחה באופן אוטומטי ממערכת הרכש.</p>
      </div>
    </div>
  `;

  return {
    subject: `אישור הזמנה #${order.orderNumber} - ${config.siteName}`,
    html
  };
}

export function formatReservationEmail(reservation: any, config: any, type: 'new' | 'delete' | 'convert') {
  const date = new Date().toLocaleString('he-IL');
  const title = type === 'new' ? 'שריון מלאי חדש' : type === 'delete' ? 'ביטול שריון מלאי' : 'המרת שריון להזמנה';
  const color = type === 'delete' ? '#ef4444' : '#f59e0b';
  
  const html = `
    <div dir="rtl" style="font-family: sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #eee; border-radius: 12px; overflow: hidden; background: #ffffff;">
      ${config?.logoUrl ? `<div style="padding: 20px; text-align: center; background: #ffffff;"><img src="${config.logoUrl}" alt="Logo" style="max-height: 80px; max-width: 250px; object-fit: contain;" /></div>` : ''}
      <div style="background: ${color}; color: white; padding: 24px; text-align: center;">
        <h1 style="margin: 0; font-size: 24px;">${title} - ${config.siteName}</h1>
      </div>
      <div style="padding: 24px; line-height: 1.6; color: #374151;">
        <p style="margin: 0 0 16px;">תאריך ושעה: ${date}</p>
        <p style="margin: 0 0 16px;">שלום,</p>
        <p style="margin: 0 0 16px;">בוצעה פעולה במערכת השריונים עבור <strong>${config.orgName}</strong>:</p>
        
        <div style="background: #f9fafb; padding: 20px; border-radius: 12px; border: 1px solid #eee; margin-bottom: 24px;">
          <p style="margin: 0 0 8px;"><strong>מוצר:</strong> ${reservation.productName}</p>
          ${reservation.variantName ? `<p style="margin: 0 0 8px;"><strong>תת-מוצר:</strong> ${reservation.variantName}</p>` : ''}
          <p style="margin: 0 0 8px;"><strong>כמות:</strong> ${reservation.quantity}</p>
          <p style="margin: 0 0 8px;"><strong>הערה/לקוח:</strong> ${reservation.note || '-'}</p>
          <p style="margin: 0;"><strong>בוצע ע"י:</strong> ${reservation.createdBy?.name || 'מנהל'}</p>
        </div>
        
        <p style="margin: 0;">בברכה,</p>
        <p style="margin: 4px 0 0; font-weight: bold;">מערכת ${config.siteName}</p>
      </div>
    </div>
  `;

  return {
    subject: `${title} - ${reservation.productName} - ${config.siteName}`,
    html
  };
}
