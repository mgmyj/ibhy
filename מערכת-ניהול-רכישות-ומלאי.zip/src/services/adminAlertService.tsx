import React from 'react';
import toast from 'react-hot-toast';
import { AlertTriangle, BellRing, RefreshCw, X, ArrowLeft, Mail } from 'lucide-react';

export interface AdminEmailFailureParams {
  orderId?: string;
  orderNumber?: number | string;
  customerName?: string;
  error?: string;
  recipient?: string;
  totalAmount?: number;
  onRetry?: () => Promise<void> | void;
}

// Play an urgent, attention-grabbing chime for the admin
export function playUrgentAlertSound() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    
    // First tone (higher urgency)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    gain1.gain.setValueAtTime(0.2, ctx.currentTime);
    gain1.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start();
    osc1.stop(ctx.currentTime + 0.35);

    // Second tone (attention ping)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(880.0, ctx.currentTime + 0.2); // A5
    gain2.gain.setValueAtTime(0.25, ctx.currentTime + 0.2);
    gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.6);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(ctx.currentTime + 0.2);
    osc2.stop(ctx.currentTime + 0.6);
  } catch (e) {
    // Audio autoplay restrictions or unsupported context
  }
}

// Send urgent in-app Toast notification to the admin
export function notifyAdminEmailFailure(params: AdminEmailFailureParams) {
  const { orderId, orderNumber, customerName, error, recipient, totalAmount, onRetry } = params;
  
  // Trigger sound alert
  playUrgentAlertSound();

  const formattedNum = orderNumber ? `#${orderNumber}` : orderId ? `#${orderId.slice(0, 8)}` : '';
  const toastKey = `admin-email-failure-${orderId || Date.now()}`;

  toast.custom(
    (t) => (
      <div
        className={`${
          t.visible ? 'animate-enter' : 'animate-leave'
        } max-w-md w-full bg-white dark:bg-zinc-900 border-2 border-red-500 rounded-2xl shadow-2xl p-4 sm:p-5 pointer-events-auto text-zinc-900 dark:text-zinc-100 relative overflow-hidden`}
        style={{ direction: 'rtl' }}
      >
        {/* Urgent indicator bar */}
        <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-red-600 via-rose-500 to-amber-500 animate-pulse" />

        <div className="flex items-start gap-3 mt-1">
          <div className="p-2.5 bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 rounded-xl shrink-0 mt-0.5 animate-bounce">
            <BellRing size={24} />
          </div>

          <div className="flex-1 min-w-0">
            {/* Header Badge */}
            <div className="flex items-center justify-between gap-2 mb-1">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-black bg-red-600 text-white tracking-wide shadow-sm">
                <AlertTriangle size={13} className="text-amber-300 animate-pulse" />
                התראה דחופה למנהל
              </span>
              <button
                onClick={() => toast.dismiss(t.id)}
                className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 p-1 rounded-lg transition-colors"
                title="סגור התראה"
              >
                <X size={16} />
              </button>
            </div>

            {/* Title */}
            <h4 className="font-extrabold text-base text-zinc-900 dark:text-zinc-50 leading-snug">
              שליחת מייל להזמנה {formattedNum} נכשלה!
            </h4>

            {/* Details */}
            <div className="mt-2 text-xs space-y-1 text-zinc-600 dark:text-zinc-300">
              {customerName && (
                <p className="truncate">
                  <span className="font-semibold text-zinc-700 dark:text-zinc-200">לקוח:</span> {customerName}
                </p>
              )}
              {totalAmount !== undefined && (
                <p>
                  <span className="font-semibold text-zinc-700 dark:text-zinc-200">סכום:</span> ₪{totalAmount}
                </p>
              )}
              {recipient && (
                <p className="truncate">
                  <span className="font-semibold text-zinc-700 dark:text-zinc-200">נמען יעד:</span> {recipient}
                </p>
              )}
              {error && (
                <div className="mt-1.5 p-2 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 rounded-lg text-red-800 dark:text-red-300 font-mono text-[11px] break-words">
                  {error}
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="mt-3.5 pt-3 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between gap-2">
              <button
                onClick={() => {
                  toast.dismiss(t.id);
                  window.dispatchEvent(new CustomEvent('change-tab', { detail: 'orders' }));
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 rounded-xl text-xs font-bold transition-all"
              >
                <span>עבור לניהול הזמנות</span>
                <ArrowLeft size={13} />
              </button>

              {onRetry && (
                <button
                  onClick={async () => {
                    toast.dismiss(t.id);
                    try {
                      await onRetry();
                    } catch (e) {}
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-red-600/20"
                >
                  <RefreshCw size={13} />
                  <span>נסה שוב כעת</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    ),
    {
      id: toastKey,
      duration: 15000,
      position: 'top-center',
    }
  );
}
