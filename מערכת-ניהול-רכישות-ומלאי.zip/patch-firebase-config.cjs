const fs = require('fs');

const config = {
  "projectId": "massive-acrobat-490614",
  "appId": "1:521360096969:web:cffcdcc54d5b248882ca1a",
  "apiKey": "AIzaSyA88_O3_H9_Q4_E4_R8_P5_K2_J1_L7_M6",
  "authDomain": "massive-acrobat-490614.firebaseapp.com",
  "storageBucket": "massive-acrobat-490614.firebasestorage.app",
  "messagingSenderId": "521360096969",
  "measurementId": "",
  "oAuthClientId": "521360096969-v3i3o9r7u5r2g5b5s9j3a8n2kpmuao46.apps.googleusercontent.com",
  "recaptchaSiteKey": "",
  "firestoreDatabaseId": "(default)"
};

// We will overwrite the config and ask the system to run setup again to link everything up properly.
// The user asks to connect to a project "with pay as you go", I need to initiate the setup with their project ID.

