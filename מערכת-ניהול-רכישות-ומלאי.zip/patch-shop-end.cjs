const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const target = `                </button>
              </form>
            </motion.div>`;

const replacement = `                </button>
              </form>
              </div>
            </motion.div>`;

content = content.replace(target, replacement);

fs.writeFileSync('src/components/Shop.tsx', content);
