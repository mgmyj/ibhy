const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

// 1. Fix listener
const listenerTarget = `  useEffect(() => {
    if (!isAdmin) return;
    
    const q = query(collection(db, 'active_carts'), limit(100));`;
const listenerNew = `  useEffect(() => {
    // Removed isAdmin check so all users listen to active_carts
    const q = query(collection(db, 'active_carts'), limit(100));`;
content = content.replace(listenerTarget, listenerNew);

// 2. Change AddToCart to support multiple variants
const addToCartTarget = `  const addToCart = (product: Product) => {
    const variantId = selectedVariants[product.id];
    const selectedVariant = product.variants?.find(v => v.id === variantId);
    
    if (product.variants?.length > 0 && !selectedVariant) {
      toast.error('יש לבחור תת-מוצר לפני ההוספה לסל');
      return;
    }
    
    const cartItemId = selectedVariant ? \`\${product.id}-\${selectedVariant.id}\` : product.id;
    const originalStock = selectedVariant ? selectedVariant.stockQuantity : product.stockQuantity;
    const lookupId = selectedVariant ? \`\${product.id}-\${selectedVariant.id}\` : product.id;
    const qtyInOtherCarts = activeCarts[lookupId] || 0;
    const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
    
    const qtyToAdd = productQuantities[product.id] || 1;
    const existingInCart = cart.find(item => item.cartItemId === cartItemId)?.quantity || 0;
    
    if (actualStock <= 0 || (existingInCart + qtyToAdd) > actualStock) {
      toast.error('הכמות המבוקשת חסרה במלאי הפנוי (יתכן ומוצרים תפוסים בסלים אחרים)');
      return;
    }
    
    // Category restriction
    if (cart.length > 0) {
      const firstItem = cart[0];
      if (firstItem.categoryId !== product.categoryId) {
        toast.error('לא ניתן להזמין מוצרים מקטגוריות שונות באותה הזמנה');
        return;
      }
    }

    setCart(prev => {
      const existing = prev.find(item => item.cartItemId === cartItemId);
      if (existing) {
        const newQty = Math.min(existing.quantity + qtyToAdd, actualStock);
        return prev.map(item => item.cartItemId === cartItemId ? { ...item, quantity: newQty } : item);
      }
      return [...prev, { 
        ...product, 
        quantity: Math.min(qtyToAdd, actualStock),
        variantId: selectedVariant?.id,
        variantName: selectedVariant?.name,
        variantPrice: selectedVariant?.price,
        cartItemId
      }];
    });
    // Reset local quantity after adding
    setProductQuantities(prev => ({ ...prev, [product.id]: 1 }));
    toast.success('המוצר נוסף לסל!');
  };`;

const addToCartNew = `  const addToCart = (product: Product, specificVariantId?: string) => {
    // If specificVariantId is provided, we add just that variant (or standard product if none)
    // If not, and product has variants, we add ALL variants that have a quantity > 0 in productQuantities
    
    const variantsToAdd = [];
    if (product.variants?.length > 0 && !specificVariantId) {
       for (const v of product.variants) {
          const qtyKey = \`\${product.id}-\${v.id}\`;
          const qty = productQuantities[qtyKey] || 0;
          if (qty > 0) {
             variantsToAdd.push({ variant: v, qtyToAdd: qty });
          }
       }
       if (variantsToAdd.length === 0) {
          toast.error('יש לבחור כמות לאחד מתתי-המוצרים לפחות');
          return;
       }
    } else {
       // Single item addition
       const selectedVariant = product.variants?.find(v => v.id === specificVariantId);
       if (product.variants?.length > 0 && !selectedVariant) {
         toast.error('יש לבחור תת-מוצר לפני ההוספה לסל');
         return;
       }
       const qtyKey = specificVariantId ? \`\${product.id}-\${specificVariantId}\` : product.id;
       const qtyToAdd = productQuantities[qtyKey] || 1;
       variantsToAdd.push({ variant: selectedVariant, qtyToAdd });
    }
    
    // Validate categories for all items
    if (cart.length > 0) {
      const firstItem = cart[0];
      if (firstItem.categoryId !== product.categoryId) {
        toast.error('לא ניתן להזמין מוצרים מקטגוריות שונות באותה הזמנה');
        return;
      }
    }
    
    let hasError = false;
    
    setCart(prev => {
      let newCart = [...prev];
      for (const { variant, qtyToAdd } of variantsToAdd) {
        const cartItemId = variant ? \`\${product.id}-\${variant.id}\` : product.id;
        const originalStock = variant ? variant.stockQuantity : product.stockQuantity;
        const lookupId = variant ? \`\${product.id}-\${variant.id}\` : product.id;
        const qtyInOtherCarts = activeCarts[lookupId] || 0;
        const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
        
        const existingItemIndex = newCart.findIndex(item => item.cartItemId === cartItemId);
        const existingInCart = existingItemIndex >= 0 ? newCart[existingItemIndex].quantity : 0;
        
        if (actualStock <= 0 || (existingInCart + qtyToAdd) > actualStock) {
          toast.error(\`הכמות המבוקשת חסרה במלאי הפנוי עבור \${variant?.name || product.name}\`);
          hasError = true;
          continue; // skip this item
        }
        
        if (existingItemIndex >= 0) {
          const newQty = Math.min(newCart[existingItemIndex].quantity + qtyToAdd, actualStock);
          newCart[existingItemIndex] = { ...newCart[existingItemIndex], quantity: newQty };
        } else {
          newCart.push({ 
            ...product, 
            quantity: Math.min(qtyToAdd, actualStock),
            variantId: variant?.id,
            variantName: variant?.name,
            variantPrice: variant?.price,
            cartItemId
          });
        }
      }
      return newCart;
    });

    if (!hasError) {
       toast.success('נוסף לסל!');
       // Reset local quantities
       setProductQuantities(prev => {
          const next = { ...prev };
          if (product.variants?.length > 0) {
             product.variants.forEach(v => {
                delete next[\`\${product.id}-\${v.id}\`];
             });
          } else {
             next[product.id] = 1;
          }
          return next;
       });
    }
  };`;
content = content.replace(addToCartTarget, addToCartNew);

fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched addToCart');
