const { formatOrderEmail } = require('./dist/services/emailService.js');
console.log('Exists:', !!formatOrderEmail);
