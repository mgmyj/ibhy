const fs = require('fs');
let shopContent = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const target = `          productUpdates[id] = {
             hasVariantsUpdate: items.some(i => i.variantId),
             hasStockUpdate: items.some(i => !i.variantId),`;
             
const newStr = `          productUpdates[id] = {
             hasVariantsUpdate: items.some(i => i.variantId),
             hasStockUpdate: true,`;
             
shopContent = shopContent.replace(target, newStr);
fs.writeFileSync('src/components/Shop.tsx', shopContent);
console.log('Fixed hasStockUpdate');
