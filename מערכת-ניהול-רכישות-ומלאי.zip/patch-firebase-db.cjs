const fs = require('fs');
let content = fs.readFileSync('src/firebase.ts', 'utf8');

const targetDb = `const savedDbId = typeof window !== 'undefined' ? localStorage.getItem('firestore_db_id') : null;
export const currentDbId = savedDbId || firebaseConfig.firestoreDatabaseId || '(default)';`;

const replacementDb = `// Prioritize config file over localStorage, but allow localStorage as fallback if config is missing
const savedDbId = typeof window !== 'undefined' ? localStorage.getItem('firestore_db_id') : null;
export const currentDbId = firebaseConfig.firestoreDatabaseId || savedDbId || '(default)';`;

content = content.replace(targetDb, replacementDb);
fs.writeFileSync('src/firebase.ts', content);
