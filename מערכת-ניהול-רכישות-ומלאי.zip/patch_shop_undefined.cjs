const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const targetStr = `    setCart(prev => {
      const existing = prev.find(item => item.cartItemId === cartItemId);
      if (existing) {
        const newQty = Math.min(existing.quantity + qtyToAdd, stockQuantity);
        return prev.map(item => item.cartItemId === cartItemId ? { ...item, quantity: newQty } : item);
      }
      return [...prev, { 
        ...product, 
        quantity: Math.min(qtyToAdd, stockQuantity),`;

const newStr = `    setCart(prev => {
      const existing = prev.find(item => item.cartItemId === cartItemId);
      if (existing) {
        const newQty = Math.min(existing.quantity + qtyToAdd, actualStock);
        return prev.map(item => item.cartItemId === cartItemId ? { ...item, quantity: newQty } : item);
      }
      return [...prev, { 
        ...product, 
        quantity: Math.min(qtyToAdd, actualStock),`;

content = content.replace(targetStr, newStr);

fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched undefined stockQuantity in Shop.tsx');
