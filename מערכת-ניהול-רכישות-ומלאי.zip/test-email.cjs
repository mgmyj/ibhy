const nodemailer = require('nodemailer');
const secrets = require('./email-secrets.json');
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: { user: secrets.emailUser, pass: secrets.emailPass }
});
transporter.sendMail({
  from: secrets.emailUser,
  to: secrets.emailUser,
  subject: 'Test',
  text: 'Test'
}).then(info => console.log('Success:', info.messageId))
  .catch(err => console.error('Error:', err));
