const fs = require('fs');
let content = fs.readFileSync('src/firebase.ts', 'utf8');

const targetTest = `// Test connection
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if(error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration. ");
    }
  }
}
testConnection();`;

const replacementTest = `// Test connection check removed to prevent offline warnings in restricted iframe environments.`;

content = content.replace(targetTest, replacementTest);
fs.writeFileSync('src/firebase.ts', content);
