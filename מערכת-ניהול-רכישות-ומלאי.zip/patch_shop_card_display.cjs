const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

// Replace the stock display in the card (around line 1129)
const stockDisplayTarget = `                          <span className={\`text-xs font-bold block mt-1 \${getStockColor((selectedVariants[product.id] ? product.variants?.find(v=>v.id===selectedVariants[product.id])?.stockQuantity : product.stockQuantity) || 0)}\`}>
                            מלאי זמין: {(selectedVariants[product.id] ? product.variants?.find(v=>v.id===selectedVariants[product.id])?.stockQuantity : product.stockQuantity) || 0}
                            {product.reservedQuantity > 0 && !selectedVariants[product.id] && (
                              <span className="text-amber-600 mr-1">({product.reservedQuantity} משוריין)</span>
                            )}
                            {(() => {
                              const variantId = selectedVariants[product.id];
                              const lookupId = variantId ? \`\${product.id}-\${variantId}\` : product.id;
                              const qtyInOtherCarts = activeCarts[lookupId] || (variantId ? 0 : activeCarts[product.id]);
                              
                              if (qtyInOtherCarts > 0) {
                                return (
                                  <span className="text-zinc-400 mr-1 text-[10px]">({qtyInOtherCarts} בסלים אחרים)</span>
                                );
                              }
                              return null;
                            })()}
                          </span>`;

const stockDisplayNew = `                          {(() => {
                              const variantId = selectedVariants[product.id];
                              const originalStock = variantId ? product.variants?.find(v=>v.id===variantId)?.stockQuantity : product.stockQuantity;
                              const lookupId = variantId ? \`\${product.id}-\${variantId}\` : product.id;
                              const qtyInOtherCarts = activeCarts[lookupId] || (variantId ? 0 : activeCarts[product.id]) || 0;
                              const actualStock = Math.max(0, (originalStock || 0) - qtyInOtherCarts);
                              
                              return (
                                <span className={\`text-xs font-bold block mt-1 \${getStockColor(actualStock)}\`}>
                                  מלאי זמין: {actualStock}
                                  {product.reservedQuantity > 0 && !variantId && (
                                    <span className="text-amber-600 mr-1">({product.reservedQuantity} משוריין)</span>
                                  )}
                                  {qtyInOtherCarts > 0 && (
                                    <span className="text-zinc-400 mr-1 text-[10px]">({qtyInOtherCarts} בסלים אחרים)</span>
                                  )}
                                </span>
                              );
                          })()}`;

content = content.replace(stockDisplayTarget, stockDisplayNew);

// Fix quantity inputs in card (around line 1238)
const qtyInputTarget = `                            onChange={(e) => {
                              const val = parseInt(e.target.value);
                              if (!isNaN(val)) {
                                if (val > product.stockQuantity) {
                                  toast.error('שים לב למלאי הנותר במוצר');
                                }
                                setProductQuantities(prev => ({ ...prev, [product.id]: Math.max(1, Math.min(val, (product.variants?.find(v=>v.id===selectedVariants[product.id])?.stockQuantity ?? product.stockQuantity))) }));
                              }
                            }}
                          />
                          <button 
                            onClick={() => {
                              const maxStock = product.variants?.find(v=>v.id===selectedVariants[product.id])?.stockQuantity ?? product.stockQuantity;
                              if ((productQuantities[product.id] || 1) >= maxStock) {
                                toast.error('שים לב למלאי הנותר במוצר');
                              }
                              setProductQuantities(prev => ({ ...prev, [product.id]: Math.min(maxStock, (prev[product.id] || 1) + 1) }));
                            }}`;
                            
const qtyInputNew = `                            onChange={(e) => {
                              const val = parseInt(e.target.value);
                              if (!isNaN(val)) {
                                const variantId = selectedVariants[product.id];
                                const originalStock = variantId ? product.variants?.find(v=>v.id===variantId)?.stockQuantity : product.stockQuantity;
                                const lookupId = variantId ? \`\${product.id}-\${variantId}\` : product.id;
                                const qtyInOtherCarts = activeCarts[lookupId] || (variantId ? 0 : activeCarts[product.id]) || 0;
                                const actualStock = Math.max(0, (originalStock || 0) - qtyInOtherCarts);
                                
                                if (val > actualStock) {
                                  toast.error('הכמות המבוקשת חסרה במלאי הפנוי (יתכן ומוצרים תפוסים בסלים אחרים)');
                                }
                                setProductQuantities(prev => ({ ...prev, [product.id]: Math.max(1, Math.min(val, actualStock)) }));
                              }
                            }}
                          />
                          <button 
                            onClick={() => {
                                const variantId = selectedVariants[product.id];
                                const originalStock = variantId ? product.variants?.find(v=>v.id===variantId)?.stockQuantity : product.stockQuantity;
                                const lookupId = variantId ? \`\${product.id}-\${variantId}\` : product.id;
                                const qtyInOtherCarts = activeCarts[lookupId] || (variantId ? 0 : activeCarts[product.id]) || 0;
                                const actualStock = Math.max(0, (originalStock || 0) - qtyInOtherCarts);
                                
                              if ((productQuantities[product.id] || 1) >= actualStock) {
                                toast.error('הכמות המבוקשת חסרה במלאי הפנוי (יתכן ומוצרים תפוסים בסלים אחרים)');
                              }
                              setProductQuantities(prev => ({ ...prev, [product.id]: Math.min(actualStock, (prev[product.id] || 1) + 1) }));
                            }}`;
                            
content = content.replace(qtyInputTarget, qtyInputNew);

fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched card display and inputs for active carts');
