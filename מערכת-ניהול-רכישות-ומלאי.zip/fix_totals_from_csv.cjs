const { initializeApp } = require('firebase/app');
const { getFirestore, collection, getDocs, doc, writeBatch } = require('firebase/firestore');
const fs = require('fs');

const firebaseConfig = {
  projectId: "gen-lang-client-0919962470",
  apiKey: "AIzaSyCKid5DkMZcGNd2H7FeIXActhhZBstgsK8",
  authDomain: "gen-lang-client-0919962470.firebaseapp.com"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app, "ai-studio-2fc34a17-3097-4a41-8bac-1dbe75f27594");

async function run() {
  const csvStr = fs.readFileSync('data.csv', 'utf8');
  const lines = csvStr.split('\n').filter(l => l.trim().length > 0 && !l.startsWith(',,,,'));
  
  const expectedTotals = {};
  
  for (let i = 1; i < lines.length; i++) { // skip header
    const cols = lines[i].split(',').map(s => s.trim().replace(/^"|"$/g, ''));
    if (cols.length < 5 || !cols[0]) continue;
    
    const sku = cols[0];
    const totalStock = parseInt(cols[5]) || 0; 
    
    const variants = {};
    for (let v = 11; v < cols.length; v += 3) {
       const vName = cols[v];
       if (!vName) continue;
       const vTotal = parseInt(cols[v+2]) || 0;
       variants[vName] = vTotal;
    }
    expectedTotals[sku] = { main: totalStock, variants };
  }
  
  const snap = await getDocs(collection(db, 'products'));
  const batch = writeBatch(db);
  let count = 0;
  
  snap.forEach(document => {
    const p = document.data();
    const sku = p.sku;
    if (!sku) return;
    
    const expected = expectedTotals[sku];
    if (!expected) return;
    
    let needsUpdate = false;
    let newVariants = [...(p.variants || [])];
    
    if (p.totalStock !== expected.main) {
        needsUpdate = true;
    }
    
    if (p.variants) {
        p.variants.forEach((v, index) => {
           const ev = expected.variants[v.name];
           if (ev !== undefined && v.totalStock !== ev) {
               needsUpdate = true;
               newVariants[index] = { ...v, totalStock: ev };
           }
        });
    }
    
    if (needsUpdate) {
        batch.update(doc(db, 'products', document.id), {
            totalStock: expected.main,
            variants: newVariants
        });
        count++;
    }
  });
  
  if (count > 0) {
      await batch.commit();
      console.log(`Successfully fixed totalStock for ${count} products to match the CSV exactly.`);
  } else {
      console.log("No updates needed.");
  }
  process.exit(0);
}
// DO NOT RUN YET
run();
