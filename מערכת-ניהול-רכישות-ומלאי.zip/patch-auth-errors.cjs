const fs = require('fs');
let content = fs.readFileSync('src/components/Auth.tsx', 'utf8');

const targetAuth = `    } catch (err: any) {
      setError('אירעה שגיאה בעת ההתחברות. אנא נסה שוב מאוחר יותר.');
      console.error('Auth error:', err);
    }`;

const replacementAuth = `    } catch (err: any) {
      if (err.code === 'auth/cancelled-popup-request' || err.code === 'auth/popup-closed-by-user') {
        // User intentionally closed the popup, no need to show an error
        console.log('Login cancelled by user.');
        return;
      }
      setError('אירעה שגיאה בעת ההתחברות. אנא נסה שוב מאוחר יותר.');
      console.error('Auth error:', err);
    }`;

content = content.replace(targetAuth, replacementAuth);
fs.writeFileSync('src/components/Auth.tsx', content);
