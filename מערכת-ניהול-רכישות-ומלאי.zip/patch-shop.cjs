const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const target = `              className="relative bg-white rounded-3xl shadow-2xl max-w-2xl w-full overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50">
                <h3 className="text-xl font-bold text-zinc-900">{config.customerFormTitle}</h3>
                <button onClick={() => setIsCheckoutOpen(false)} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
              </div>
              <form onSubmit={handleCheckout} className="p-8">`;

const replacement = `              className="relative bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50 shrink-0">
                <h3 className="text-xl font-bold text-zinc-900">{config.customerFormTitle}</h3>
                <button onClick={() => setIsCheckoutOpen(false)} className="text-zinc-400 hover:text-zinc-600"><X size={24} /></button>
              </div>
              <div className="overflow-y-auto overflow-x-hidden flex-1">
                <form onSubmit={handleCheckout} className="p-8">`;

content = content.replace(target, replacement);

const targetEnd = `                </form>
            </motion.div>`;
            
const replacementEnd = `                </form>
              </div>
            </motion.div>`;

content = content.replace(targetEnd, replacementEnd);

fs.writeFileSync('src/components/Shop.tsx', content);
