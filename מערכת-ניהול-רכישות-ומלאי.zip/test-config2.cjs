const admin = require('firebase-admin');
const fs = require('fs');

async function test() {
  const secretsPath = '/app/applet/firebase-applet-config.json';
  const firebaseConfig = JSON.parse(fs.readFileSync(secretsPath, 'utf8'));

  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.applicationDefault(), // won't work in this container without SA.
      projectId: firebaseConfig.projectId
    });
  }
}
test();
