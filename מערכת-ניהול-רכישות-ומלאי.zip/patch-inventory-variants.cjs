const fs = require('fs');
let content = fs.readFileSync('src/components/Inventory.tsx', 'utf8');

const targetState = `  const [productForm, setProductForm] = useState<Partial<Product>>({
    sku: '', name: '', description: '', image: '', price: 0, categoryId: '', subCategoryId: '', stockQuantity: 0, totalStock: 0,
    startTime: '', endTime: '', duration: '', hideLowStockAlert: false
  });`;

const replacementState = `  const [productForm, setProductForm] = useState<Partial<Product>>({
    sku: '', name: '', description: '', image: '', price: 0, categoryId: '', subCategoryId: '', stockQuantity: 0, totalStock: 0,
    startTime: '', endTime: '', duration: '', hideLowStockAlert: false, variants: []
  });
  
  const addVariant = () => {
    setProductForm({
      ...productForm,
      variants: [...(productForm.variants || []), { id: Date.now().toString(), name: '', stockQuantity: 0, price: 0 }]
    });
  };
  
  const updateVariant = (index: number, field: string, value: any) => {
    const newVariants = [...(productForm.variants || [])];
    newVariants[index] = { ...newVariants[index], [field]: value };
    setProductForm({ ...productForm, variants: newVariants });
  };
  
  const removeVariant = (index: number) => {
    const newVariants = [...(productForm.variants || [])];
    newVariants.splice(index, 1);
    setProductForm({ ...productForm, variants: newVariants });
  };`;

content = content.replace(targetState, replacementState);

const targetUI = `                        <input 
                          required 
                          type="number" 
                          placeholder="כללי"
                          className="w-full px-4 py-3 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" 
                          value={productForm.totalStock || 0} 
                          onChange={e => setProductForm({...productForm, totalStock: Number(e.target.value)})} 
                        />
                      </div>
                    </div>
                  </div>`;

const replacementUI = targetUI + `
                  
                  {/* Variants Section */}
                  <div className="mt-6 border-t border-zinc-100 pt-6">
                    <div className="flex justify-between items-center mb-4">
                      <label className="block text-sm font-bold text-zinc-800">תת-פריטים (וריאציות)</label>
                      <button type="button" onClick={addVariant} className="text-xs bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full font-bold hover:bg-indigo-100 transition-colors flex items-center gap-1">
                        <Plus size={14} /> הוסף תת-פריט
                      </button>
                    </div>
                    
                    {productForm.variants && productForm.variants.length > 0 ? (
                      <div className="space-y-3">
                        {productForm.variants.map((variant, idx) => (
                          <div key={variant.id} className="flex items-center gap-3 bg-zinc-50 p-3 rounded-xl border border-zinc-200">
                            <input 
                              type="text" 
                              placeholder="שם (למשל: מידה לארג', צבע כחול)"
                              className="flex-1 px-3 py-2 border border-zinc-200 rounded-lg outline-none text-sm"
                              value={variant.name}
                              onChange={e => updateVariant(idx, 'name', e.target.value)}
                              required
                            />
                            <div className="w-24">
                              <label className="text-[10px] text-zinc-500 block mb-1">מחיר (₪)</label>
                              <input 
                                type="number" 
                                placeholder="מחיר"
                                className="w-full px-3 py-2 border border-zinc-200 rounded-lg outline-none text-sm"
                                value={variant.price || 0}
                                onChange={e => updateVariant(idx, 'price', Number(e.target.value))}
                              />
                            </div>
                            <div className="w-24">
                              <label className="text-[10px] text-zinc-500 block mb-1">מלאי</label>
                              <input 
                                type="number" 
                                placeholder="מלאי"
                                className="w-full px-3 py-2 border border-zinc-200 rounded-lg outline-none text-sm"
                                value={variant.stockQuantity || 0}
                                onChange={e => updateVariant(idx, 'stockQuantity', Number(e.target.value))}
                                required
                              />
                            </div>
                            <button type="button" onClick={() => removeVariant(idx)} className="mt-5 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                              <Trash2 size={16} />
                            </button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-zinc-500 bg-zinc-50 p-3 rounded-lg text-center">אין תת-פריטים. לחץ על "הוסף תת-פריט" כדי להוסיף מידות, צבעים או סוגים שונים לאותו מוצר.</p>
                    )}
                  </div>
`;

content = content.replace(targetUI, replacementUI);
fs.writeFileSync('src/components/Inventory.tsx', content);
