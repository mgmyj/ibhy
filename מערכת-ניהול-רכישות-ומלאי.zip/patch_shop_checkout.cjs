const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

// 1. Validation logic during checkout
const validateTarget = `        // Validate stock for all items
        for (const { item, doc } of productSnapshots) {
          const currentStock = doc.data().stockQuantity;
          if (currentStock < item.quantity) throw new Error(\`Not enough stock for \${item.name}\`);
        }`;

const validateNew = `        // Validate stock for all items
        for (const { item, doc } of productSnapshots) {
          const productData = doc.data();
          if (item.variantId) {
             const variant = productData.variants?.find((v: any) => v.id === item.variantId);
             if (!variant || variant.stockQuantity < item.quantity) {
               throw new Error(\`Not enough stock for \${item.name} - \${item.variantName}\`);
             }
          } else {
             const currentStock = productData.stockQuantity;
             if (currentStock < item.quantity) throw new Error(\`Not enough stock for \${item.name}\`);
          }
        }`;

content = content.replace(validateTarget, validateNew);

// 2. Update logic during checkout
const updateTarget = `        // Update Stock
        for (const { item, doc } of productSnapshots) {
          const currentStock = doc.data().stockQuantity;
          transaction.update(doc.ref, {
            stockQuantity: currentStock - item.quantity
          });
        }`;

const updateNew = `        // Update Stock
        for (const { item, doc } of productSnapshots) {
          const productData = doc.data();
          if (item.variantId && productData.variants) {
            const updatedVariants = productData.variants.map((v: any) => {
              if (v.id === item.variantId) {
                return { ...v, stockQuantity: v.stockQuantity - item.quantity };
              }
              return v;
            });
            transaction.update(doc.ref, {
              variants: updatedVariants
            });
          } else {
            const currentStock = productData.stockQuantity;
            transaction.update(doc.ref, {
              stockQuantity: currentStock - item.quantity
            });
          }
        }`;

content = content.replace(updateTarget, updateNew);

fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched handleCheckout for variants');
