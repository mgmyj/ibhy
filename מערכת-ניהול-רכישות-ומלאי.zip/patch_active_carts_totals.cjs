const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const targetActiveCartsCalc = `      snapshot.docs.forEach(doc => {
        const data = doc.data();
        if (doc.id !== userId) {
          const items = data.items || {};
          Object.entries(items).forEach(([productId, qty]) => {
            totals[productId] = (totals[productId] || 0) + qty;
          });
        }
        allCarts.push({ id: doc.id, ...data });
      });`;

const newActiveCartsCalc = `      snapshot.docs.forEach(doc => {
        const data = doc.data();
        if (doc.id !== userId) {
          if (data.detailedItems && Array.isArray(data.detailedItems)) {
            data.detailedItems.forEach(item => {
              const key = item.variantId ? \`\${item.id}-\${item.variantId}\` : item.id;
              totals[key] = (totals[key] || 0) + item.quantity;
              
              // Also keep the parent product total for general availability checks if needed,
              // but we prefix it or just keep it. We'll just add it to the parent id as well so we can show total per product,
              // but we need a way to distinguish. Let's just track the exact ID (with variant).
              // We'll also track the parent total.
              if (item.variantId) {
                totals[item.id] = (totals[item.id] || 0) + item.quantity;
              }
            });
          } else {
            const items = data.items || {};
            Object.entries(items).forEach(([productId, qty]) => {
              totals[productId] = (totals[productId] || 0) + qty;
            });
          }
        }
        allCarts.push({ id: doc.id, ...data });
      });`;

content = content.replace(targetActiveCartsCalc, newActiveCartsCalc);

const targetUi = `{activeCarts[product.id] > 0 && !selectedVariants[product.id] && (
                              <span className="text-zinc-400 mr-1 text-[10px]">({activeCarts[product.id]} בסלים אחרים)</span>
                            )}`;
                            
const newUi = `{(() => {
                              const variantId = selectedVariants[product.id];
                              const lookupId = variantId ? \`\${product.id}-\${variantId}\` : product.id;
                              const qtyInOtherCarts = activeCarts[lookupId] || (variantId ? 0 : activeCarts[product.id]);
                              
                              if (qtyInOtherCarts > 0) {
                                return (
                                  <span className="text-zinc-400 mr-1 text-[10px]">({qtyInOtherCarts} בסלים אחרים)</span>
                                );
                              }
                              return null;
                            })()}`;

content = content.replace(targetUi, newUi);

fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched active_carts UI and state to support variants');
