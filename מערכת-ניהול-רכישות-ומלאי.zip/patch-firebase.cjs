const fs = require('fs');
let content = fs.readFileSync('src/firebase.ts', 'utf8');

const providerTarget = `export const googleProvider = new GoogleAuthProvider();`;
const providerReplacement = `export const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('https://www.googleapis.com/auth/gmail.send');`;

content = content.replace(providerTarget, providerReplacement);
fs.writeFileSync('src/firebase.ts', content);
