const fs = require('fs');
let content = fs.readFileSync('src/components/Reports.tsx', 'utf8');

const targetButtons = `                        <button 
                          onClick={() => setConfig({
                            ...config,
                            emailSettings: { ...(config.emailSettings || {} as EmailSettings), senderChoice: 'user' }
                          })}
                          className={\`flex-1 py-3 rounded-xl font-bold text-sm transition-all \${config.emailSettings?.senderChoice === 'user' ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-zinc-500 border border-zinc-200'}\`}
                        >
                          מייל המשתמש
                        </button>
                        <button 
                          onClick={() => setConfig({
                            ...config,
                            emailSettings: { ...(config.emailSettings || {} as EmailSettings), senderChoice: 'system' }
                          })}
                          className={\`flex-1 py-3 rounded-xl font-bold text-sm transition-all \${config.emailSettings?.senderChoice === 'system' ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-zinc-500 border border-zinc-200'}\`}
                        >
                          מייל המערכת
                        </button>`;

const replacementButtons = `                        <button 
                          onClick={async () => {
                            try {
                              const { connectGmailAccount } = await import('../firebase');
                              await connectGmailAccount();
                              setConfig({
                                ...config,
                                emailSettings: { ...(config.emailSettings || {} as EmailSettings), senderChoice: 'user' }
                              });
                              toast.success('חשבון ה-Gmail חובר בהצלחה!');
                            } catch (e) {
                              toast.error('החיבור ל-Gmail בוטל או נכשל. נווטו למצב מערכת.');
                            }
                          }}
                          className={\`flex-1 py-3 rounded-xl font-bold text-sm transition-all \${config.emailSettings?.senderChoice === 'user' ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-zinc-500 border border-zinc-200'}\`}
                        >
                          מייל המשתמש (חבר Gmail)
                        </button>
                        <button 
                          onClick={() => setConfig({
                            ...config,
                            emailSettings: { ...(config.emailSettings || {} as EmailSettings), senderChoice: 'system' }
                          })}
                          className={\`flex-1 py-3 rounded-xl font-bold text-sm transition-all \${config.emailSettings?.senderChoice === 'system' ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-zinc-500 border border-zinc-200'}\`}
                        >
                          מייל המערכת
                        </button>`;

content = content.replace(targetButtons, replacementButtons);

content = content.replace(
  `import { Save, FileSpreadsheet, Calculator, Plus, Trash2, Mail, Users, Check, Phone, FileText, Send, Settings as SettingsIcon } from 'lucide-react';`,
  `import { Save, FileSpreadsheet, Calculator, Plus, Trash2, Mail, Users, Check, Phone, FileText, Send, Settings as SettingsIcon } from 'lucide-react';\nimport toast from 'react-hot-toast';`
);

fs.writeFileSync('src/components/Reports.tsx', content);
