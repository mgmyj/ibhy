const fs = require('fs');
let content = fs.readFileSync('src/types.ts', 'utf8');

const newInterface = `
export interface ProductVariant {
  id: string;
  name: string;
  price?: number;
  stockQuantity: number;
}
`;

content = content.replace('export interface Product {', newInterface + '\nexport interface Product {');
content = content.replace('categoryId?: string;', 'categoryId?: string;\n  variants?: ProductVariant[];');

fs.writeFileSync('src/types.ts', content);
