import { Buffer } from 'buffer';

const subject = "Test Subject";
const fromHeaderName = "איחוד בני הישיבות";
const userEmail = "test@example.com";
const to = "test2@example.com";

const mimeEmail = `From: =?utf-8?B?${Buffer.from(fromHeaderName).toString('base64')}?= <${userEmail}>\r\n` +
`To: ${to}\r\n` +
`Subject: =?utf-8?B?${Buffer.from(subject).toString('base64')}?=\r\n` +
"MIME-Version: 1.0\r\n"

console.log(mimeEmail);
