import nodemailer from 'nodemailer';
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    type: 'OAuth2',
    user: 'test@example.com',
    accessToken: 'ya29.fake'
  }
});
console.log(transporter.options);
