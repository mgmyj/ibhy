const fs = require('fs');

// Patch Shop.tsx
let shopContent = fs.readFileSync('src/components/Shop.tsx', 'utf8');
shopContent = shopContent.replace(
  /if \(config\.emailSettings\?\.reportEmail && config\.emailSettings\?\.notifyNewOrder\) \{/g,
  "if (config.emailSettings?.reportEmail && config.emailSettings?.notifyNewOrder !== false) {"
);
fs.writeFileSync('src/components/Shop.tsx', shopContent);

// Patch Settings.tsx
let settingsContent = fs.readFileSync('src/components/Settings.tsx', 'utf8');
settingsContent = settingsContent.replace(
  /if \(!config\.emailSettings\?\.disableAllEmails && config\.emailSettings\?\.notifyReservation\) \{/g,
  "if (!config.emailSettings?.disableAllEmails && config.emailSettings?.notifyReservation !== false) {"
);
settingsContent = settingsContent.replace(
  /if \(!config\.emailSettings\?\.disableAllEmails && config\.emailSettings\?\.notifyReservationDelete\) \{/g,
  "if (!config.emailSettings?.disableAllEmails && config.emailSettings?.notifyReservationDelete !== false) {"
);
settingsContent = settingsContent.replace(
  /if \(!config\.emailSettings\?\.disableAllEmails && config\.emailSettings\?\.notifyReservationToOrder\) \{/g,
  "if (!config.emailSettings?.disableAllEmails && config.emailSettings?.notifyReservationToOrder !== false) {"
);
fs.writeFileSync('src/components/Settings.tsx', settingsContent);

// Patch Reports.tsx
let reportsContent = fs.readFileSync('src/components/Reports.tsx', 'utf8');
reportsContent = reportsContent.replace(
  /checked=\{\(config\.emailSettings as any\)\?\.\[item\.id\] \|\| false\}/g,
  "checked={(config.emailSettings as any)?.[item.id] ?? (item.id.startsWith('notify') ? true : false)}"
);
fs.writeFileSync('src/components/Reports.tsx', reportsContent);
