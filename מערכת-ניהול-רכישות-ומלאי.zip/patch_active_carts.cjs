const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

// 1. setDoc
const oldSetDoc = `    if (cart.length > 0 && cartLoaded.current) {
      const cartData = cart.reduce((acc, item) => ({ ...acc, [item.id]: item.quantity }), {});
      setDoc(doc(db, 'active_carts', userId), {
        items: cartData,
        updatedAt: serverTimestamp(),
        userEmail,
        userName,
        totalItems: cart.reduce((sum, item) => sum + item.quantity, 0),
        totalAmount: cart.reduce((sum, item) => sum + ((item.variantPrice !== undefined ? item.variantPrice : item.price) * item.quantity), 0)
      }).then(() => {`;

const newSetDoc = `    if (cart.length > 0 && cartLoaded.current) {
      const cartData = cart.reduce((acc, item) => {
        acc[item.id] = (acc[item.id] || 0) + item.quantity;
        return acc;
      }, {});
      const detailedItems = cart.map(item => ({
        id: item.id,
        cartItemId: item.cartItemId || item.id,
        quantity: item.quantity,
        variantId: item.variantId || null,
        variantName: item.variantName || null,
        variantPrice: item.variantPrice !== undefined ? item.variantPrice : null
      }));
      setDoc(doc(db, 'active_carts', userId), {
        items: cartData,
        detailedItems: detailedItems,
        updatedAt: serverTimestamp(),
        userEmail,
        userName,
        totalItems: cart.reduce((sum, item) => sum + item.quantity, 0),
        totalAmount: cart.reduce((sum, item) => sum + ((item.variantPrice !== undefined ? item.variantPrice : item.price) * item.quantity), 0)
      }).then(() => {`;
      
content = content.replace(oldSetDoc, newSetDoc);

// 2. getInitialCart
const oldGetInitialCart = `        if (docSnap.exists()) {
          const data = docSnap.data();
          const items = data.items || {};
          const newCart: CartItem[] = [];
          
          Object.entries(items).forEach(([prodId, qty]) => {
            const product = products.find(p => p.id === prodId);
            if (product) {
              newCart.push({ ...product, quantity: qty as number });
            }
          });
          
          if (newCart.length > 0) {
            setCart(newCart);
          }`;

const newGetInitialCart = `        if (docSnap.exists()) {
          const data = docSnap.data();
          const newCart: CartItem[] = [];
          
          if (data.detailedItems && Array.isArray(data.detailedItems)) {
            data.detailedItems.forEach(item => {
              const product = products.find(p => p.id === item.id);
              if (product) {
                newCart.push({
                   ...product,
                   quantity: item.quantity,
                   cartItemId: item.cartItemId,
                   variantId: item.variantId,
                   variantName: item.variantName,
                   variantPrice: item.variantPrice !== null ? item.variantPrice : undefined
                });
              }
            });
          } else {
            const items = data.items || {};
            Object.entries(items).forEach(([prodId, qty]) => {
              const product = products.find(p => p.id === prodId);
              if (product) {
                newCart.push({ ...product, quantity: qty as number });
              }
            });
          }
          
          if (newCart.length > 0) {
            setCart(newCart);
          }`;

content = content.replace(oldGetInitialCart, newGetInitialCart);

// 3. active carts modal display
const oldModalDisplay = `                            {Object.entries(cart.items || {}).map(([prodId, qty]) => {
                              const product = products.find(p => p.id === prodId);
                              return (
                                <span key={prodId} className="px-2 py-1 bg-white border border-zinc-200 rounded-lg text-[10px] text-zinc-600">
                                  {product?.name || 'מוצר לא ידוע'} x{qty as number}
                                </span>
                              );
                            })}`;

const newModalDisplay = `                            {cart.detailedItems ? cart.detailedItems.map(item => {
                              const product = products.find(p => p.id === item.id);
                              return (
                                <span key={item.cartItemId || item.id} className="px-2 py-1 bg-white border border-zinc-200 rounded-lg text-[10px] text-zinc-600">
                                  {product?.name || 'מוצר לא ידוע'} {item.variantName ? \`- \${item.variantName}\` : ''} x{item.quantity}
                                </span>
                              );
                            }) : Object.entries(cart.items || {}).map(([prodId, qty]) => {
                              const product = products.find(p => p.id === prodId);
                              return (
                                <span key={prodId} className="px-2 py-1 bg-white border border-zinc-200 rounded-lg text-[10px] text-zinc-600">
                                  {product?.name || 'מוצר לא ידוע'} x{qty as number}
                                </span>
                              );
                            })}`;

content = content.replace(oldModalDisplay, newModalDisplay);

fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched active_carts in Shop.tsx');
