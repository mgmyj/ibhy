const { initializeApp } = require('firebase/app');
const { getFirestore, collection, getDocs } = require('firebase/firestore');
const fs = require('fs');

const firebaseConfig = {
  projectId: "gen-lang-client-0919962470",
  apiKey: "AIzaSyCKid5DkMZcGNd2H7FeIXActhhZBstgsK8",
  authDomain: "gen-lang-client-0919962470.firebaseapp.com"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app, "ai-studio-2fc34a17-3097-4a41-8bac-1dbe75f27594");

async function run() {
  const csvStr = fs.readFileSync('data.csv', 'utf8');
  const lines = csvStr.split('\n').filter(l => l.trim().length > 0 && !l.startsWith(',,,,'));
  
  const expectedTotals = {};
  
  for (let i = 1; i < lines.length; i++) { // skip header
    const cols = lines[i].split(',').map(s => s.trim().replace(/^"|"$/g, ''));
    if (cols.length < 5 || !cols[0]) continue;
    
    const sku = cols[0];
    const totalStock = parseInt(cols[5]) || 0; // "מלאי כללי" is column 5 (0-indexed: מק"ט, שם, תיאור, מחיר, מלאי, מלאי כללי -> wait. מק"ט=0, שם=1, תיאור=2, מחיר=3, מלאי נוכחי=4, מלאי כללי=5)
    
    const variants = {};
    // Variants start at index 11 (תת מוצר 1 - שם)
    for (let v = 11; v < cols.length; v += 3) {
       const vName = cols[v];
       if (!vName) continue;
       const vTotal = parseInt(cols[v+2]) || 0;
       variants[vName] = vTotal;
    }
    expectedTotals[sku] = { main: totalStock, variants };
  }
  
  const snap = await getDocs(collection(db, 'products'));
  let discrepancies = [];
  
  snap.forEach(doc => {
    const p = doc.data();
    const sku = p.sku;
    if (!sku) return;
    
    const expected = expectedTotals[sku];
    if (!expected) {
        // console.log(`SKU ${sku} not in CSV.`);
        return;
    }
    
    if (p.totalStock !== expected.main) {
        discrepancies.push(`מוצר [${sku}] ${p.name}: מלאי כללי במערכת (${p.totalStock}) שונה מהקובץ המקורי (${expected.main})`);
    }
    
    if (p.variants) {
        p.variants.forEach(v => {
           const ev = expected.variants[v.name];
           if (ev !== undefined && v.totalStock !== ev) {
               discrepancies.push(`תת-מוצר [${sku}] ${p.name} - ${v.name}: מלאי כללי במערכת (${v.totalStock}) שונה מהקובץ המקורי (${ev})`);
           }
        });
    }
  });
  
  if (discrepancies.length === 0) {
      console.log("SUCCESS: All products and variants match the original total stock perfectly!");
  } else {
      console.log("DISCREPANCIES FOUND:");
      discrepancies.forEach(d => console.log(d));
  }
  process.exit(0);
}
run();
