const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

content = content.replace(/let secrets = \{\};/, `let secrets: any = {};`);

fs.writeFileSync('server.ts', content);
