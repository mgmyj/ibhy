const fs = require('fs');

// 1. Fix Shop.tsx Checkout (decrement parent stock even for variants)
let shopContent = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const checkoutTarget = `            if (item.variantId) {
               const vIndex = newVariants.findIndex((v: any) => v.id === item.variantId);
               if (vIndex === -1 || newVariants[vIndex].stockQuantity < item.quantity) {
                 throw new Error(\`Not enough stock for \${item.name} - \${item.variantName}\`);
               }
               newVariants[vIndex] = { ...newVariants[vIndex], stockQuantity: newVariants[vIndex].stockQuantity - item.quantity };
            } else {
               if (newStockQuantity < item.quantity) throw new Error(\`Not enough stock for \${item.name}\`);
               newStockQuantity -= item.quantity;
            }`;

const checkoutNew = `            if (item.variantId) {
               const vIndex = newVariants.findIndex((v: any) => v.id === item.variantId);
               if (vIndex === -1 || newVariants[vIndex].stockQuantity < item.quantity) {
                 throw new Error(\`Not enough stock for \${item.name} - \${item.variantName}\`);
               }
               newVariants[vIndex] = { ...newVariants[vIndex], stockQuantity: newVariants[vIndex].stockQuantity - item.quantity };
               // Deduct from parent as well, since parent stock represents the total physical items or is used as a fallback counter
               newStockQuantity -= item.quantity;
            } else {
               if (newStockQuantity < item.quantity) throw new Error(\`Not enough stock for \${item.name}\`);
               newStockQuantity -= item.quantity;
            }`;
            
shopContent = shopContent.replace(checkoutTarget, checkoutNew);

// 2. Fix activeCarts tracking in Shop.tsx so we don't double count if we don't need to,
// ACTUALLY, if parent stock is decremented, then parent stock DOES represent the total.
// So when someone puts a variant in their cart, it SHOULD reserve the parent stock too!
// That means the activeCarts listener `totals[item.id] += item.quantity` is CORRECT and NECESSARY.
// We just keep it as is.

fs.writeFileSync('src/components/Shop.tsx', shopContent);
console.log('Fixed Shop checkout logic');

// 3. Fix Inventory.tsx to display variant stocks clearly
let invContent = fs.readFileSync('src/components/Inventory.tsx', 'utf8');

const invDisplayTarget = `                  <span className={\`text-sm font-bold \${getStockColor(product.stockQuantity)}\`}>
                    {product.stockQuantity}/{product.totalStock || product.stockQuantity} יח'
                    {product.reservedQuantity > 0 && (
                      <span className="text-amber-600 mr-1 text-[10px]">({product.reservedQuantity} משוריין)</span>
                    )}
                  </span>`;
                  
const invDisplayNew = `                  <span className={\`text-sm font-bold \${getStockColor(product.stockQuantity)}\`}>
                    {product.stockQuantity}/{product.totalStock || product.stockQuantity} יח' כללי
                    {product.reservedQuantity > 0 && (
                      <span className="text-amber-600 mr-1 text-[10px]">({product.reservedQuantity} משוריין)</span>
                    )}
                    {product.variants && product.variants.length > 0 && (
                      <div className="text-zinc-500 text-[10px] font-normal mt-1 flex flex-wrap gap-1">
                        {product.variants.map((v: any) => (
                           <span key={v.id} className="bg-zinc-100 px-1.5 py-0.5 rounded-md">
                             {v.name}: <span className={v.stockQuantity <= 0 ? 'text-red-500 font-bold' : ''}>{v.stockQuantity}</span>
                           </span>
                        ))}
                      </div>
                    )}
                  </span>`;

invContent = invContent.replace(invDisplayTarget, invDisplayNew);
fs.writeFileSync('src/components/Inventory.tsx', invContent);
console.log('Fixed Inventory UI to show variants');
