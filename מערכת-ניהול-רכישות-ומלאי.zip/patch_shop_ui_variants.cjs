const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const targetUI = `                                            {product.variants && product.variants.length > 0 && (
                        <div className="mb-4">
                          <label className="block text-xs font-bold text-zinc-700 mb-2">בחר אפשרות:</label>
                          <select 
                            className="w-full px-3 py-2 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                            value={selectedVariants[product.id] || ''}
                            onChange={(e) => {
                               setSelectedVariants(prev => ({ ...prev, [product.id]: e.target.value }));
                            }}
                          >
                            <option value="">-- בחר --</option>
                            {product.variants.map(v => {
                               const lookupId = \`\${product.id}-\${v.id}\`;
                               const qtyInOtherCarts = activeCarts[lookupId] || 0;
                               const actualStock = Math.max(0, v.stockQuantity - qtyInOtherCarts);
                               const isOutOfStock = actualStock <= 0;
                               return (
                                 <option key={v.id} value={v.id} disabled={isOutOfStock}>
                                    {v.name} - ₪{v.price} {isOutOfStock ? '(אזל מהמלאי הפנוי)' : \`(מלאי זמין: \${actualStock})\`} {qtyInOtherCarts > 0 ? \`(\${qtyInOtherCarts} תפוסים בסלים אחרים)\` : ''}
                                 </option>
                               );
                            })}
                          </select>
                        </div>
                      )}`;

const newUI = `                                            {product.variants && product.variants.length > 0 && (
                        <div className="mb-4 space-y-2">
                          <label className="block text-xs font-bold text-zinc-700 mb-2">בחר כמויות לתתי-מוצרים (אפשר לבחור כמה ביחד):</label>
                          {product.variants.map(v => {
                             const lookupId = \`\${product.id}-\${v.id}\`;
                             const qtyInOtherCarts = activeCarts[lookupId] || 0;
                             const actualStock = Math.max(0, v.stockQuantity - qtyInOtherCarts);
                             const isOutOfStock = actualStock <= 0;
                             const qtyKey = \`\${product.id}-\${v.id}\`;
                             const currentQty = productQuantities[qtyKey] || 0;
                             
                             return (
                               <div key={v.id} className={\`flex items-center justify-between p-2 rounded-lg border \${currentQty > 0 ? 'border-indigo-500 bg-indigo-50' : 'border-zinc-200 bg-zinc-50'}\`}>
                                 <div className="flex-1">
                                    <div className="text-sm font-bold text-zinc-900">{v.name} - ₪{v.price}</div>
                                    <div className="text-[10px] text-zinc-500">
                                       {isOutOfStock ? <span className="text-red-500">אזל מהמלאי הפנוי</span> : \`מלאי זמין: \${actualStock}\`}
                                       {qtyInOtherCarts > 0 && <span className="mr-1">(\${qtyInOtherCarts} בסלים אחרים)</span>}
                                    </div>
                                 </div>
                                 <div className="flex items-center gap-2 bg-white rounded-lg border border-zinc-200 p-1">
                                    <button 
                                      disabled={currentQty <= 0}
                                      onClick={() => setProductQuantities(prev => ({ ...prev, [qtyKey]: Math.max(0, currentQty - 1) }))}
                                      className="p-1 text-zinc-400 hover:text-indigo-600 disabled:opacity-50"
                                    >
                                      <Minus size={14} />
                                    </button>
                                    <input 
                                      type="number"
                                      className="w-8 text-center bg-transparent font-bold text-zinc-900 outline-none text-sm"
                                      value={currentQty}
                                      min="0"
                                      onChange={(e) => {
                                        const val = parseInt(e.target.value);
                                        if (!isNaN(val)) {
                                          if (val > actualStock) {
                                            toast.error('הכמות המבוקשת חסרה במלאי הפנוי');
                                          }
                                          setProductQuantities(prev => ({ ...prev, [qtyKey]: Math.max(0, Math.min(val, actualStock)) }));
                                        }
                                      }}
                                    />
                                    <button 
                                      disabled={currentQty >= actualStock || isOutOfStock}
                                      onClick={() => {
                                        if (currentQty >= actualStock) {
                                          toast.error('הכמות המבוקשת חסרה במלאי הפנוי');
                                        } else {
                                          setProductQuantities(prev => ({ ...prev, [qtyKey]: Math.min(actualStock, currentQty + 1) }));
                                        }
                                      }}
                                      className="p-1 text-zinc-400 hover:text-indigo-600 disabled:opacity-50"
                                    >
                                      <Plus size={14} />
                                    </button>
                                 </div>
                               </div>
                             );
                          })}
                        </div>
                      )}`;

content = content.replace(targetUI, newUI);
fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched variants UI');
