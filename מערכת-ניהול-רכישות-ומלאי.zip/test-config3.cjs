const fs = require('fs');
fetch('http://localhost:3000/api/get-secrets').then(r => r.json()).then(console.log);
