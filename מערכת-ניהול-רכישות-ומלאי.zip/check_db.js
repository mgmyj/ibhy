import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs, limit, query } from 'firebase/firestore';

// Need to read firebase config from somewhere...
// Ah, the firebase config is in src/firebase.ts, but that's client side.
// Is there a service account or can I just use curl?
