console.log("No way to test directly. Just read about the Gmail API behavior.");
