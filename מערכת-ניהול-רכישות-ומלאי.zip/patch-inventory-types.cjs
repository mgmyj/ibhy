const fs = require('fs');
let content = fs.readFileSync('src/components/Inventory.tsx', 'utf8');

const target = `interface Product {
  id: string;
  sku: string;
  name: string;
  price: number;
  stockQuantity: number;
  totalStock: number;
  reservedQuantity?: number;
  description?: string;
  imageUrl?: string;
  categoryId?: string;
  subCategoryId?: string;
  lastUpdated?: any;
}`;

const replacement = `export interface ProductVariant {
  id: string;
  name: string;
  price?: number;
  stockQuantity: number;
}

interface Product {
  id: string;
  sku: string;
  name: string;
  price: number;
  stockQuantity: number;
  totalStock: number;
  reservedQuantity?: number;
  description?: string;
  imageUrl?: string;
  categoryId?: string;
  subCategoryId?: string;
  lastUpdated?: any;
  variants?: ProductVariant[];
}`;

content = content.replace(target, replacement);
fs.writeFileSync('src/components/Inventory.tsx', content);
