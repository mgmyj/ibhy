const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const singleQtyTarget = `                      <div className="space-y-3">
                        {cart.some(item => item.id === product.id) && (
                          <div className="flex items-center gap-1 text-emerald-600 text-[10px] font-bold mb-1">
                            <Check size={12} />
                            כבר בסל שלך
                          </div>
                        )}
                        <div className="flex items-center justify-between bg-zinc-50 p-2 rounded-xl border border-zinc-100">
                          <button 
                            onClick={() => setProductQuantities(prev => ({ ...prev, [product.id]: Math.max(1, (prev[product.id] || 1) - 1) }))}
                            className="p-1 text-zinc-400 hover:text-indigo-600"
                          >
                            <Minus size={16} />
                          </button>
                          <input 
                            type="number"
                            className="w-12 text-center bg-transparent font-bold text-zinc-900 outline-none"
                            value={productQuantities[product.id] || 1}
                            min="1"
                            onChange={(e) => {
                              const val = parseInt(e.target.value);
                              if (!isNaN(val)) {
                                const variantId = selectedVariants[product.id];
                                const originalStock = variantId ? product.variants?.find(v=>v.id===variantId)?.stockQuantity : product.stockQuantity;
                                const lookupId = variantId ? \`\${product.id}-\${variantId}\` : product.id;
                                const qtyInOtherCarts = activeCarts[lookupId] || (variantId ? 0 : activeCarts[product.id]) || 0;
                                const actualStock = Math.max(0, (originalStock || 0) - qtyInOtherCarts);
                                
                                if (val > actualStock) {
                                  toast.error('הכמות המבוקשת חסרה במלאי הפנוי (יתכן ומוצרים תפוסים בסלים אחרים)');
                                }
                                setProductQuantities(prev => ({ ...prev, [product.id]: Math.max(1, Math.min(val, actualStock)) }));
                              }
                            }}
                          />
                          <button 
                            onClick={() => {
                                const variantId = selectedVariants[product.id];
                                const originalStock = variantId ? product.variants?.find(v=>v.id===variantId)?.stockQuantity : product.stockQuantity;
                                const lookupId = variantId ? \`\${product.id}-\${variantId}\` : product.id;
                                const qtyInOtherCarts = activeCarts[lookupId] || (variantId ? 0 : activeCarts[product.id]) || 0;
                                const actualStock = Math.max(0, (originalStock || 0) - qtyInOtherCarts);
                                
                              if ((productQuantities[product.id] || 1) >= actualStock) {
                                toast.error('הכמות המבוקשת חסרה במלאי הפנוי (יתכן ומוצרים תפוסים בסלים אחרים)');
                              }
                              setProductQuantities(prev => ({ ...prev, [product.id]: Math.min(actualStock, (prev[product.id] || 1) + 1) }));
                            }}
                            className="p-1 text-zinc-400 hover:text-indigo-600"
                          >
                            <Plus size={16} />
                          </button>
                        </div>

                        {(() => {
                          const variantId = selectedVariants[product.id];
                          const selectedVariant = product.variants?.find(v => v.id === variantId);
                          const lookupId = selectedVariant ? \`\${product.id}-\${selectedVariant.id}\` : product.id;
                          const qtyInOtherCarts = activeCarts[lookupId] || 0;
                          const originalStock = selectedVariant?.stockQuantity ?? product.stockQuantity;
                          const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
                          const isOutOfStock = actualStock <= 0;
                          return (
                            <button
                              disabled={isOutOfStock || (product.variants?.length > 0 && !variantId)}
                              onClick={() => addToCart(product)}
                              className={\`w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 \${!isOutOfStock && (!product.variants?.length || variantId) ? 'bg-zinc-900 text-white hover:bg-black shadow-lg shadow-black/10' : 'bg-zinc-100 text-zinc-400 cursor-not-allowed'}\`}
                            >
                              <ShoppingBag size={20} />
                              {isOutOfStock ? 'אזל מהמלאי' : 'הוסף לסל'}
                            </button>
                          );
                        })()}
                      </div>`;

const singleQtyNew = `                      <div className="space-y-3">
                        {cart.some(item => item.id === product.id) && (
                          <div className="flex items-center gap-1 text-emerald-600 text-[10px] font-bold mb-1">
                            <Check size={12} />
                            כבר בסל שלך
                          </div>
                        )}
                        
                        {/* Only show single quantity selector if NO variants */}
                        {(!product.variants || product.variants.length === 0) && (
                          <div className="flex items-center justify-between bg-zinc-50 p-2 rounded-xl border border-zinc-100">
                            <button 
                              onClick={() => setProductQuantities(prev => ({ ...prev, [product.id]: Math.max(1, (prev[product.id] || 1) - 1) }))}
                              className="p-1 text-zinc-400 hover:text-indigo-600"
                            >
                              <Minus size={16} />
                            </button>
                            <input 
                              type="number"
                              className="w-12 text-center bg-transparent font-bold text-zinc-900 outline-none"
                              value={productQuantities[product.id] || 1}
                              min="1"
                              onChange={(e) => {
                                const val = parseInt(e.target.value);
                                if (!isNaN(val)) {
                                  const actualStock = Math.max(0, product.stockQuantity - (activeCarts[product.id] || 0));
                                  if (val > actualStock) toast.error('הכמות המבוקשת חסרה במלאי הפנוי');
                                  setProductQuantities(prev => ({ ...prev, [product.id]: Math.max(1, Math.min(val, actualStock)) }));
                                }
                              }}
                            />
                            <button 
                              onClick={() => {
                                const actualStock = Math.max(0, product.stockQuantity - (activeCarts[product.id] || 0));
                                if ((productQuantities[product.id] || 1) >= actualStock) toast.error('הכמות המבוקשת חסרה במלאי הפנוי');
                                setProductQuantities(prev => ({ ...prev, [product.id]: Math.min(actualStock, (prev[product.id] || 1) + 1) }));
                              }}
                              className="p-1 text-zinc-400 hover:text-indigo-600"
                            >
                              <Plus size={16} />
                            </button>
                          </div>
                        )}

                        {(() => {
                          if (product.variants?.length > 0) {
                             const totalSelected = product.variants.reduce((sum, v) => sum + (productQuantities[\`\${product.id}-\${v.id}\`] || 0), 0);
                             // To check if all variants are out of stock
                             const allOutOfStock = product.variants.every(v => Math.max(0, v.stockQuantity - (activeCarts[\`\${product.id}-\${v.id}\`] || 0)) <= 0);
                             return (
                                <button
                                  disabled={allOutOfStock || totalSelected === 0}
                                  onClick={() => addToCart(product)}
                                  className={\`w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 \${!allOutOfStock && totalSelected > 0 ? 'bg-zinc-900 text-white hover:bg-black shadow-lg shadow-black/10' : 'bg-zinc-100 text-zinc-400 cursor-not-allowed'}\`}
                                >
                                  <ShoppingBag size={20} />
                                  {allOutOfStock ? 'אזל מהמלאי' : totalSelected > 0 ? \`הוסף (\${totalSelected}) לסל\` : 'בחר כמויות להוספה'}
                                </button>
                             );
                          } else {
                             const actualStock = Math.max(0, product.stockQuantity - (activeCarts[product.id] || 0));
                             const isOutOfStock = actualStock <= 0;
                             return (
                                <button
                                  disabled={isOutOfStock}
                                  onClick={() => addToCart(product)}
                                  className={\`w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 \${!isOutOfStock ? 'bg-zinc-900 text-white hover:bg-black shadow-lg shadow-black/10' : 'bg-zinc-100 text-zinc-400 cursor-not-allowed'}\`}
                                >
                                  <ShoppingBag size={20} />
                                  {isOutOfStock ? 'אזל מהמלאי' : 'הוסף לסל'}
                                </button>
                             );
                          }
                        })()}
                      </div>`;

content = content.replace(singleQtyTarget, singleQtyNew);
fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched single qty UI to switch modes');
