const fs = require('fs');
let content = fs.readFileSync('src/firebase.ts', 'utf8');

const targetProvider = `export const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('https://www.googleapis.com/auth/gmail.send');`;

const replacementProvider = `export const googleProvider = new GoogleAuthProvider();

export const gmailProvider = new GoogleAuthProvider();
gmailProvider.addScope('https://www.googleapis.com/auth/gmail.send');

export const connectGmailAccount = async () => {
  try {
    const result = await signInWithPopup(auth, gmailProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (credential?.accessToken) {
      cachedAccessToken = credential.accessToken;
    }
    return result;
  } catch (error) {
    console.error('Gmail connect error:', error);
    throw error;
  }
};`;

content = content.replace(targetProvider, replacementProvider);
fs.writeFileSync('src/firebase.ts', content);
