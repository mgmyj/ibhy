const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

// 1. Update CartItem interface
content = content.replace(
  'interface CartItem extends Product { quantity: number; }',
  'interface CartItem extends Product { quantity: number; variantId?: string; variantName?: string; variantPrice?: number; cartItemId?: string; }'
);

// 2. Add state for selected variants
const stateTarget = `const [productQuantities, setProductQuantities] = useState<Record<string, number>>({});`;
const stateReplacement = stateTarget + `\n  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>({});`;
content = content.replace(stateTarget, stateReplacement);

// 3. Update addToCart function
const addToCartTarget = `  const addToCart = (product: Product) => {
    const qtyToAdd = productQuantities[product.id] || 1;
    const existingInCart = cart.find(item => item.id === product.id)?.quantity || 0;
    
    if (product.stockQuantity <= 0 || (existingInCart + qtyToAdd) > product.stockQuantity) {
      toast.error('שים לב למלאי הנותר במוצר');
      return;
    }
    
    // Category restriction
    if (cart.length > 0) {
      const firstItem = cart[0];
      if (firstItem.categoryId !== product.categoryId) {
        toast.error('לא ניתן להזמין מוצרים מקטגוריות שונות באותה הזמנה');
        return;
      }
    }
    
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + qtyToAdd } : item);
      }
      return [...prev, { ...product, quantity: qtyToAdd }];
    });
    setProductQuantities(prev => ({ ...prev, [product.id]: 1 }));
    toast.success('המוצר נוסף לסל');
  };`;

const addToCartReplacement = `  const addToCart = (product: Product) => {
    const qtyToAdd = productQuantities[product.id] || 1;
    const variantId = selectedVariants[product.id];
    let selectedVariant = null;
    let stockToCheck = product.stockQuantity;
    
    if (product.variants && product.variants.length > 0) {
      if (!variantId) {
        toast.error('נא לבחור תת-פריט');
        return;
      }
      selectedVariant = product.variants.find(v => v.id === variantId);
      if (selectedVariant) {
        stockToCheck = selectedVariant.stockQuantity;
      }
    }

    const cartItemId = variantId ? \`\${product.id}_\${variantId}\` : product.id;
    const existingInCart = cart.find(item => item.cartItemId === cartItemId || item.id === cartItemId)?.quantity || 0;
    
    if (stockToCheck <= 0 || (existingInCart + qtyToAdd) > stockToCheck) {
      toast.error('שים לב למלאי הנותר במוצר / תת-הפריט');
      return;
    }
    
    // Category restriction
    if (cart.length > 0) {
      const firstItem = cart[0];
      if (firstItem.categoryId !== product.categoryId) {
        toast.error('לא ניתן להזמין מוצרים מקטגוריות שונות באותה הזמנה');
        return;
      }
    }
    
    setCart(prev => {
      const existing = prev.find(item => item.cartItemId === cartItemId || (!item.cartItemId && item.id === product.id));
      if (existing) {
        return prev.map(item => (item.cartItemId === cartItemId || (!item.cartItemId && item.id === product.id)) ? { ...item, quantity: item.quantity + qtyToAdd } : item);
      }
      
      const newItem: CartItem = { ...product, quantity: qtyToAdd, cartItemId };
      if (selectedVariant) {
        newItem.variantId = selectedVariant.id;
        newItem.variantName = selectedVariant.name;
        if (selectedVariant.price !== undefined) {
          newItem.variantPrice = selectedVariant.price;
        }
      }
      return [...prev, newItem];
    });
    setProductQuantities(prev => ({ ...prev, [product.id]: 1 }));
    toast.success('המוצר נוסף לסל');
  };`;

content = content.replace(addToCartTarget, addToCartReplacement);

fs.writeFileSync('src/components/Shop.tsx', content);
