const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const targetStr = `onChange={(e) => {
                                const val = parseInt(e.target.value);
                                if (!isNaN(val)) {
                                  if (val > item.stockQuantity) {
                                    toast.error('שים לב למלאי הנותר במוצר');
                                  }
                                  const newQty = Math.max(1, Math.min(val, item.stockQuantity));
                                  setCart(prev => prev.map(p => p.id === item.id ? { ...p, quantity: newQty } : p));
                                }
                              }}`;
                              
const newStr = `onChange={(e) => {
                                const val = parseInt(e.target.value);
                                if (!isNaN(val)) {
                                  const maxStock = item.variantId ? (item.variants?.find(v => v.id === item.variantId)?.stockQuantity || 0) : item.stockQuantity;
                                  if (val > maxStock) {
                                    toast.error('שים לב למלאי הנותר במוצר');
                                  }
                                  const newQty = Math.max(1, Math.min(val, maxStock));
                                  setCart(prev => prev.map(p => (p.cartItemId || p.id) === (item.cartItemId || item.id) ? { ...p, quantity: newQty } : p));
                                }
                              }}`;
                              
content = content.replace(targetStr, newStr);

fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched Shop cart qty input');
