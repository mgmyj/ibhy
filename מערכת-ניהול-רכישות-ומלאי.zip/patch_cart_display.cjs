const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const cartDisplayTarget = `<p className={\`text-xs font-bold mb-2 \${getStockColor((item.variantId ? item.variants?.find(v=>v.id===item.variantId)?.stockQuantity : item.stockQuantity) || 0)}\`}>מלאי זמין: {(item.variantId ? item.variants?.find(v=>v.id===item.variantId)?.stockQuantity : item.stockQuantity) || 0}</p>`;

const cartDisplayNew = `{(() => {
  const originalStock = item.variantId ? (item.variants?.find(v=>v.id===item.variantId)?.stockQuantity || 0) : item.stockQuantity;
  const lookupId = item.variantId ? \`\${item.id}-\${item.variantId}\` : item.id;
  const qtyInOtherCarts = activeCarts[lookupId] || 0;
  const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
  return (
    <p className={\`text-xs font-bold mb-2 \${getStockColor(actualStock)}\`}>
      מלאי פנוי: {actualStock} 
      {qtyInOtherCarts > 0 && <span className="text-zinc-400 font-normal mr-1 text-[10px]">({qtyInOtherCarts} בסלים אחרים)</span>}
    </p>
  );
})()}`;

content = content.replace(cartDisplayTarget, cartDisplayNew);
fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched cart item stock display');
