const fs = require('fs');
let content = fs.readFileSync('src/firebase.ts', 'utf8');

const targetAuth = `  } catch (error) {
    console.error('Sign in error:', error);
    throw error;
  }`;

const replacementAuth = `  } catch (error: any) {
    if (error?.code !== 'auth/cancelled-popup-request' && error?.code !== 'auth/popup-closed-by-user') {
      console.error('Sign in error:', error);
    }
    throw error;
  }`;

content = content.replace(targetAuth, replacementAuth);
fs.writeFileSync('src/firebase.ts', content);
