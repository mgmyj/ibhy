import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import { fileURLToPath } from "url";
import nodemailer from "nodemailer";
import dotenv from "dotenv";
import cron from "node-cron";
import { initializeApp } from "firebase/app";
import { getFirestore, collection, getDocs, query, orderBy, doc, getDoc, setDoc } from "firebase/firestore";

dotenv.config();

// Resolve paths correctly whether in ESM (dev) or CJS (prod build)
const isESM = typeof import.meta !== 'undefined' && typeof import.meta.url === 'string';
const resolveFilename = () => {
  if (typeof __filename !== "undefined") return __filename;
  if (isESM) return fileURLToPath(import.meta.url);
  return '';
};
const resolveDirname = () => {
  if (typeof __dirname !== "undefined") return __dirname;
  if (isESM) return path.dirname(resolveFilename());
  return process.cwd();
};

const _filename = resolveFilename();
const _dirname = resolveDirname();

// Firebase Config for Server-side (using same config as client)
const firebaseConfigPath = path.join(process.cwd(), 'firebase-applet-config.json');
let firebaseConfig = {};
if (fs.existsSync(firebaseConfigPath)) {
  firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, 'utf8'));
} else {
  console.warn("firebase-applet-config.json not found!");
}

const firebaseApp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseApp, (firebaseConfig as any).firestoreDatabaseId || '(default)');

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  app.use(express.json());

  // Lazy-loaded Email Transporter
  let transporterInstance: nodemailer.Transporter | null = null;
  let lastTransporterConfig = '';

  // Pending failed emails queue storage
  const pendingEmailsPath = path.join(process.cwd(), 'pending-emails.json');

  interface QueuedEmail {
    id: string;
    to: string;
    subject: string;
    text?: string;
    html?: string;
    userEmail?: string;
    userName?: string;
    replyTo?: string;
    attachments?: any[];
    createdAt: string;
    attempts: number;
    lastError?: string;
  }

  const getPendingEmails = (): QueuedEmail[] => {
    try {
      if (fs.existsSync(pendingEmailsPath)) {
        return JSON.parse(fs.readFileSync(pendingEmailsPath, 'utf8'));
      }
    } catch (e) {
      console.error("Error reading pending emails:", e);
    }
    return [];
  };

  const savePendingEmails = (emails: QueuedEmail[]) => {
    try {
      fs.writeFileSync(pendingEmailsPath, JSON.stringify(emails, null, 2));
    } catch (e) {
      console.error("Error saving pending emails:", e);
    }
  };

  const enqueueEmail = (data: any, errorMsg: string) => {
    try {
      const list = getPendingEmails();
      // Avoid duplicate enqueueing if same recipient and subject within 5 minutes
      const isDuplicate = list.some(item => 
        item.to === data.to && 
        item.subject === data.subject && 
        (Date.now() - new Date(item.createdAt).getTime() < 300000)
      );

      if (!isDuplicate) {
        list.push({
          id: 'mail_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
          to: data.to,
          subject: data.subject,
          text: data.text,
          html: data.html,
          userEmail: data.userEmail,
          userName: data.userName,
          replyTo: data.replyTo,
          attachments: data.attachments,
          createdAt: new Date().toISOString(),
          attempts: 1,
          lastError: errorMsg
        });
        // Keep queue from exploding (max 150 emails)
        if (list.length > 150) list.shift();
        savePendingEmails(list);
        console.log(`[Queue] Email enqueued for retry: "${data.subject}" to ${data.to}. Total queued: ${list.length}`);
      }
    } catch (e) {
      console.error("Error enqueueing email:", e);
    }
  };

  // Helper to sync credentials to process.env in memory
  const updateEnvFile = (user: string, pass: string, fromName: string) => {
    process.env.EMAIL_USER = user;
    process.env.EMAIL_PASS = pass;
    process.env.EMAIL_FROM_NAME = fromName;
  };

  // Encryption helpers for persistent mail credentials in Firestore
  const ENCRYPTION_SALT = (firebaseConfig as any)?.projectId || "email_vault_salt_2026";
  const ENCRYPTION_KEY = crypto.createHash("sha256").update(ENCRYPTION_SALT).digest();

  const encryptSecret = (text: string): string => {
    if (!text) return "";
    try {
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv("aes-256-cbc", ENCRYPTION_KEY, iv);
      let encrypted = cipher.update(text, "utf8", "hex");
      encrypted += cipher.final("hex");
      return `enc:${iv.toString("hex")}:${encrypted}`;
    } catch (err) {
      console.error("[Crypto] Encryption error:", err);
      return text;
    }
  };

  const decryptSecret = (payload: string): string => {
    if (!payload) return "";
    if (!payload.startsWith("enc:")) {
      return payload;
    }
    try {
      const parts = payload.split(":");
      if (parts.length !== 3) return payload;
      const iv = Buffer.from(parts[1], "hex");
      const encryptedText = parts[2];
      const decipher = crypto.createDecipheriv("aes-256-cbc", ENCRYPTION_KEY, iv);
      let decrypted = decipher.update(encryptedText, "hex", "utf8");
      decrypted += decipher.final("utf8");
      return decrypted;
    } catch (err) {
      console.error("[Crypto] Decryption error:", err);
      return "";
    }
  };

  const getEmailCredentials = async (): Promise<{ user: string; pass: string; fromName: string }> => {
    // 1. Try to read from Firestore (persistent cloud database surviving container restarts)
    try {
      const mailDoc = await getDoc(doc(db, "config", "mail_settings"));
      if (mailDoc.exists()) {
        const data = mailDoc.data();
        const user = data.emailUser ? String(data.emailUser).trim().toLowerCase() : "";
        const rawPass = data.emailPass ? decryptSecret(String(data.emailPass)) : "";
        const pass = rawPass.replace(/\s+/g, "").trim();
        const fromName = data.emailFromName ? String(data.emailFromName).trim() : "מערכת רכש";
        if (user && pass && pass !== "vooksursntyroudf") {
          return { user, pass, fromName };
        }
      }
    } catch (err: any) {
      console.warn("[Email] Failed to read mail_settings from Firestore:", err.message);
    }

    // 2. Fallback to local email-secrets.json
    const secretsPath = path.join(process.cwd(), "email-secrets.json");
    if (fs.existsSync(secretsPath)) {
      try {
        const secrets = JSON.parse(fs.readFileSync(secretsPath, "utf8"));
        const user = secrets.emailUser ? String(secrets.emailUser).trim().toLowerCase() : "";
        const pass = secrets.emailPass ? String(secrets.emailPass).replace(/\s+/g, "").trim() : "";
        const fromName = secrets.emailFromName ? String(secrets.emailFromName).trim() : "מערכת רכש";
        if (user && pass && pass !== "vooksursntyroudf") {
          return { user, pass, fromName };
        }
      } catch (e) {}
    }

    // 3. Fallback to process.env
    const envUser = process.env.EMAIL_USER ? String(process.env.EMAIL_USER).trim().toLowerCase() : "";
    const envPass = process.env.EMAIL_PASS ? String(process.env.EMAIL_PASS).replace(/\s+/g, "").trim() : "";
    const envFromName = process.env.EMAIL_FROM_NAME ? String(process.env.EMAIL_FROM_NAME).trim() : "מערכת רכש";
    if (envUser && envPass && envPass !== "vooksursntyroudf") {
      return { user: envUser, pass: envPass, fromName: envFromName };
    }

    return { user: "", pass: "", fromName: "" };
  };
  
  const getTransporter = async () => {
    try {
      const { user, pass, fromName } = await getEmailCredentials();
      
      if (!user || !pass) {
        throw new Error("Email credentials are not configured in settings or environment variables.");
      }

      const currentConfig = `${user}:${pass}`;
      
      if (!transporterInstance || lastTransporterConfig !== currentConfig) {
        transporterInstance = nodemailer.createTransport({
          host: "smtp.gmail.com",
          port: 465,
          secure: true,
          auth: { user, pass },
          connectionTimeout: 10000,
          greetingTimeout: 10000,
          socketTimeout: 15000,
        });
        lastTransporterConfig = currentConfig;
      }
      return { transporter: transporterInstance, user, fromName };
    } catch (e: any) {
      if (e.message !== "Email credentials are not configured in settings or environment variables.") {
        console.error("Error getting transporter:", e);
      }
      throw e;
    }
  };

  // Health state tracking
  let emailHealth = {
    healthy: true,
    configured: false,
    lastChecked: '',
    error: null as string | null,
    user: ''
  };

  const retryPendingEmails = async () => {
    const list = getPendingEmails();
    if (list.length === 0) return { success: true, total: 0, sent: 0, remaining: 0 };

    console.log(`[Queue] Retrying ${list.length} pending emails...`);
    let transporterData;
    try {
      transporterData = await getTransporter();
    } catch (e: any) {
      return { success: false, total: list.length, sent: 0, remaining: list.length, error: e.message };
    }

    const { transporter, user, fromName } = transporterData;
    const remaining: QueuedEmail[] = [];
    let sentCount = 0;

    for (const item of list) {
      try {
        const displayName = fromName || item.userName || 'מערכת';
        await transporter.sendMail({
          from: {
            name: displayName,
            address: user
          },
          to: item.to,
          subject: item.subject,
          text: item.text,
          html: item.html,
          replyTo: item.replyTo,
          attachments: item.attachments?.map((att: any) => ({
            filename: att.filename,
            content: att.content,
            encoding: att.encoding || 'base64',
            contentType: att.contentType
          }))
        });
        sentCount++;
        console.log(`[Queue] Successfully resent email "${item.subject}" to ${item.to}`);
      } catch (err: any) {
        console.error(`[Queue] Failed to send queued email "${item.subject}":`, err.message);
        item.attempts = (item.attempts || 1) + 1;
        item.lastError = err.message;
        remaining.push(item);
      }
    }

    savePendingEmails(remaining);
    return { success: true, total: list.length, sent: sentCount, remaining: remaining.length };
  };

  const checkHealthNow = async () => {
    try {
      const creds = await getEmailCredentials();
      if (!creds.user || !creds.pass) {
        emailHealth = {
          healthy: false,
          configured: false,
          lastChecked: new Date().toISOString(),
          error: "פרטי התחברות ל-Gmail טרם הוגדרו במערכת (נא להזין סיסמת אפליקציה בהגדרות)",
          user: creds.user || ""
        };
        return emailHealth;
      }

      const { transporter, user } = await getTransporter();
      await transporter.verify();
      emailHealth = {
        healthy: true,
        configured: true,
        lastChecked: new Date().toISOString(),
        error: null,
        user
      };
      console.log(`[Health] Gmail SMTP verified successfully for ${user}`);

      // Auto-flush pending emails if any exist
      const pending = getPendingEmails();
      if (pending.length > 0) {
        console.log(`[Health] Gmail connection active, flushing ${pending.length} queued emails...`);
        retryPendingEmails().catch(e => console.error("Error auto-retrying pending emails:", e));
      }

      return emailHealth;
    } catch (err: any) {
      let friendlyError = err.message || "Unknown error";
      const isMissing = friendlyError.includes("not configured") || friendlyError.includes("טרם הוגדרו");
      if (
        friendlyError.includes("535") || 
        friendlyError.includes("BadCredentials") || 
        friendlyError.includes("Username and Password not accepted")
      ) {
        friendlyError = "סיסמת האפליקציה אינה תקפה או פגת תוקף (Google 535 Bad Credentials). יש להפיק סיסמת אפליקציה חדשה ב-Google (16 אותיות) ולהזינה בהגדרות.";
      }
      emailHealth = {
        healthy: false,
        configured: !isMissing,
        lastChecked: new Date().toISOString(),
        error: friendlyError,
        user: emailHealth.user || ''
      };
      
      if (isMissing) {
        console.log(`[Health] Email not configured yet, skipping SMTP check.`);
      } else {
        console.warn(`[Health] Gmail SMTP health check failed: ${friendlyError}`);
      }
      return emailHealth;
    }
  };

  // Helper to generate and send report
  const generateAndSendReport = async (type: 'daily' | 'weekly' | 'monthly') => {
    try {
      const configDoc = await getDoc(doc(db, "config", "system"));
      if (!configDoc.exists()) return;
      
      const config = configDoc.data();
      const emailSettings = config.emailSettings;
      
      if (!emailSettings?.reportEmail) return;
      
      const isEnabled = 
        (type === 'daily' && emailSettings.autoDailyReport) ||
        (type === 'weekly' && emailSettings.autoWeeklyReport) ||
        (type === 'monthly' && emailSettings.autoMonthlyReport);
        
      if (!isEnabled) return;

      const ordersSnap = await getDocs(query(collection(db, "orders"), orderBy("createdAt", "desc")));
      let orders = ordersSnap.docs.map(d => ({ id: d.id, ...d.data() } as any));

      const now = new Date();
      let subject = "";
      
      if (type === 'daily') {
        const yesterday = new Date(now);
        yesterday.setDate(now.getDate() - 1);
        yesterday.setHours(0,0,0,0);
        orders = orders.filter((o: any) => o.createdAt?.toDate() >= yesterday);
        subject = `דוח יומי אוטומטי - ${yesterday.toLocaleDateString('he-IL')}`;
      } else if (type === 'weekly') {
        const lastWeek = new Date(now);
        lastWeek.setDate(now.getDate() - 7);
        orders = orders.filter((o: any) => o.createdAt?.toDate() >= lastWeek);
        subject = `דוח שבועי אוטומטי - ${lastWeek.toLocaleDateString('he-IL')} עד ${now.toLocaleDateString('he-IL')}`;
      } else if (type === 'monthly') {
        const lastMonth = new Date(now);
        lastMonth.setMonth(now.getMonth() - 1);
        orders = orders.filter((o: any) => o.createdAt?.toDate() >= lastMonth);
        subject = `דוח חודשי אוטומטי - ${lastMonth.toLocaleString('he-IL', { month: 'long', year: 'numeric' })}`;
      }

      const html = `
        <div dir="rtl" style="font-family: Arial, sans-serif; color: #333; text-align: right;">
          <h2 style="color: #4f46e5;">${subject} - ${config.orgName || config.siteName}</h2>
          <p>הופק באופן אוטומטי בתאריך: ${now.toLocaleString('he-IL')}</p>
          <hr />
          <table style="width: 100%; border-collapse: collapse; margin-top: 20px; direction: rtl;">
            <thead>
              <tr style="background-color: #f3f4f6;">
                <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">מספר הזמנה</th>
                <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">לקוח</th>
                <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">סה"כ</th>
                <th style="border: 1px solid #ddd; padding: 12px; text-align: right;">תאריך</th>
              </tr>
            </thead>
            <tbody>
              ${orders.map((o: any) => `
                <tr>
                  <td style="border: 1px solid #ddd; padding: 10px;">${o.orderNumber || o.id.slice(-6)}</td>
                  <td style="border: 1px solid #ddd; padding: 10px;">${o.customer?.name || '-'}</td>
                  <td style="border: 1px solid #ddd; padding: 10px;">${o.totalAmount?.toLocaleString()} ₪</td>
                  <td style="border: 1px solid #ddd; padding: 10px;">${o.createdAt?.toDate()?.toLocaleString('he-IL')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div style="margin-top: 20px; font-weight: bold;">
            סה"כ הזמנות: ${orders.length} | סה"כ הכנסות: ${orders.reduce((sum: number, o: any) => sum + (o.totalAmount || 0), 0).toLocaleString()} ₪
          </div>
        </div>
      `;

      const { transporter, user, fromName } = await getTransporter();
      await transporter.sendMail({
        from: `"${fromName}" <${user}>`,
        to: emailSettings.reportEmail,
        subject: `${subject} - ${config.orgName || config.siteName}`,
        html
      });

      console.log(`Automated ${type} report sent to ${emailSettings.reportEmail}`);
    } catch (error) {
      console.error(`Error in automated ${type} report:`, error);
    }
  };

  // Schedule Cron Jobs
  // Daily at 00:01
  cron.schedule("1 0 * * *", () => generateAndSendReport('daily'));
  // Weekly on Sunday at 00:05
  cron.schedule("5 0 * * 0", () => generateAndSendReport('weekly'));
  // Monthly on 1st at 00:10
  cron.schedule("10 0 1 * *", () => generateAndSendReport('monthly'));
  // Health check every 4 hours
  cron.schedule("0 */4 * * *", () => checkHealthNow());

  // Startup verification after 3 seconds
  setTimeout(() => {
    checkHealthNow().catch(e => console.error("Startup health check error:", e));
  }, 3000);

  // API routes can go here
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.get("/api/email-status", (req, res) => {
    const pending = getPendingEmails();
    res.json({
      ...emailHealth,
      pendingCount: pending.length
    });
  });

  app.post("/api/check-email-health", async (req, res) => {
    const health = await checkHealthNow();
    const pending = getPendingEmails();
    res.json({
      ...health,
      pendingCount: pending.length
    });
  });

  app.post("/api/retry-failed-emails", async (req, res) => {
    const result = await retryPendingEmails();
    res.json(result);
  });

  app.get("/api/pending-emails", (req, res) => {
    const list = getPendingEmails().map(e => ({
      id: e.id,
      to: e.to,
      subject: e.subject,
      createdAt: e.createdAt,
      attempts: e.attempts,
      lastError: e.lastError
    }));
    res.json(list);
  });

  app.delete("/api/pending-emails/:id", (req, res) => {
    const { id } = req.params;
    if (id === 'all') {
      savePendingEmails([]);
      return res.json({ success: true, count: 0 });
    }
    const list = getPendingEmails().filter(e => e.id !== id);
    savePendingEmails(list);
    res.json({ success: true, count: list.length });
  });

  app.get("/api/get-secrets", async (req, res) => {
    try {
      const creds = await getEmailCredentials();
      res.json({ 
        emailUser: creds.user, 
        emailPass: creds.pass, 
        emailFromName: creds.fromName 
      });
    } catch(e) {
      console.error("Error getting secrets:", e);
      res.status(500).json({ error: "Failed to get secrets" });
    }
  });

  app.post("/api/save-secrets", async (req, res) => {
    try {
      const user = req.body.emailUser ? String(req.body.emailUser).trim().toLowerCase() : '';
      const pass = req.body.emailPass ? String(req.body.emailPass).replace(/\s+/g, '').trim() : '';
      const fromName = req.body.emailFromName ? String(req.body.emailFromName).trim() : '';

      if (!user || !pass) {
        return res.status(400).json({ error: "Missing emailUser or emailPass" });
      }

      // 1. Save persistently to Firestore (encrypted)
      try {
        const encryptedPass = encryptSecret(pass);
        await setDoc(doc(db, "config", "mail_settings"), {
          emailUser: user,
          emailPass: encryptedPass,
          emailFromName: fromName,
          updatedAt: new Date().toISOString()
        }, { merge: true });
        console.log(`[Email] Saved persistent mail credentials to Firestore config/mail_settings for ${user}`);
      } catch (dbErr: any) {
        console.error("[Email] Failed to persist credentials to Firestore:", dbErr.message);
      }

      // 2. Save locally as fast fallback
      const secretsPath = path.join(process.cwd(), 'email-secrets.json');
      fs.writeFileSync(secretsPath, JSON.stringify({ emailUser: user, emailPass: pass, emailFromName: fromName }, null, 2));
      updateEnvFile(user, pass, fromName);

      // 3. Invalidate transporter cache
      transporterInstance = null;
      lastTransporterConfig = '';

      // 4. Immediately check health and auto-flush queue if healthy
      const health = await checkHealthNow();

      res.json({ success: true, health });
    } catch(e) {
      console.error("Error saving secrets:", e);
      res.status(500).json({ error: "Failed to save secrets" });
    }
  });

  app.post("/api/test-email", async (req, res) => {
    try {
      const rawUser = req.body.emailUser || '';
      const rawPass = req.body.emailPass || '';
      const user = String(rawUser).trim().toLowerCase();
      const pass = String(rawPass).replace(/\s+/g, '').trim();

      if (!user || !pass) {
        return res.status(400).json({ 
          success: false, 
          error: "נא להזין כתובת Gmail וסיסמת אפליקציה בת 16 אותיות." 
        });
      }

      const testTransporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth: { user, pass },
        connectionTimeout: 8000,
        greetingTimeout: 8000,
        socketTimeout: 12000,
      });

      await testTransporter.verify();

      // If test succeeds, trigger a check health on the main transporter as well
      checkHealthNow().catch(() => {});

      return res.json({ 
        success: true, 
        message: "החיבור לשרת הדואר של Google (Gmail SMTP) אומת בהצלחה!" 
      });
    } catch (err: any) {
      console.error("Test email connection failed:", err.message);
      let userFriendlyError = err.message || "שגיאה בחיבור לשרת הדואר";
      if (
        err.message?.includes("535") || 
        err.message?.includes("BadCredentials") || 
        err.message?.includes("Username and Password not accepted")
      ) {
        userFriendlyError = "שגיאת אימות מול Google (קוד 535): סיסמת האפליקציה או כתובת המייל אינן תואמות. ודאו שאימות דו-שלבי פעיל בחשבון Google, והפיקו 'סיסמה לאפליקציות' (16 אותיות) בחשבון בכתובת myaccount.google.com/apppasswords";
      }
      return res.status(400).json({ 
        success: false, 
        error: userFriendlyError,
        rawError: err.message 
      });
    }
  });

  app.post("/api/send-email", async (req, res) => {
    const { to, subject, text, html, userEmail, userName, replyTo, replyToMessageId, attachments } = req.body;

    if (!to || !subject || (!text && !html)) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    try {
      // Get system config
      const configDoc = await getDoc(doc(db, "config", "system"));
      const config = configDoc.exists() ? configDoc.data() : {};
      const emailSettings = config.emailSettings || {};
      const systemName = config.orgName || config.siteName || "מערכת";

      if (emailSettings.disableAllEmails) {
        console.log("All emails are disabled in system settings. Skipping send.");
        return res.json({ success: false, reason: "emails_disabled" });
      }

      let transporterData;
      try {
        transporterData = await getTransporter();
      } catch (transporterErr: any) {
        if (transporterErr.message && transporterErr.message.includes("Email credentials are not configured")) {
          console.warn("Skipping email send: Email credentials not configured. Enqueueing for auto-retry.");
          enqueueEmail(req.body, "Email credentials not configured");
          emailHealth.healthy = false;
          emailHealth.configured = false;
          emailHealth.error = "פרטי התחברות ל-Gmail אינם מוגדרים";
          return res.json({ 
            success: false, 
            queued: true,
            reason: "credentials_missing",
            message: "המייל נשמר בתור לשליחה חוזרת ברגע שיוזנו פרטי הדואר."
          });
        }
        throw transporterErr;
      }

      const { transporter, user, fromName } = transporterData;
      const displayName = fromName || userName || systemName;

      try {
        const mailOptions: any = {
          from: {
            name: displayName,
            address: user
          },
          to,
          subject,
          text,
          html,
          replyTo: replyTo || (userEmail ? `"${userName || userEmail}" <${userEmail}>` : undefined),
          attachments: attachments?.map((att: any) => ({
            filename: att.filename,
            content: att.content,
            encoding: att.encoding || 'base64',
            contentType: att.contentType
          }))
        };

        if (replyToMessageId) {
          mailOptions.inReplyTo = replyToMessageId;
          mailOptions.references = [replyToMessageId];
        }

        const info = await transporter.sendMail(mailOptions);

        console.log("Email sent successfully: %s", info.messageId);
        emailHealth.healthy = true;
        emailHealth.error = null;
        return res.json({ success: true, messageId: info.messageId });
      } catch (smtpError: any) {
        console.error("Gmail SMTP Send Error:", smtpError.message);
        // Automatically enqueue into pending-emails.json so NO email is ever lost!
        enqueueEmail(req.body, smtpError.message);
        emailHealth.healthy = false;
        emailHealth.lastChecked = new Date().toISOString();

        if (
          smtpError.message?.includes("535") || 
          smtpError.message?.includes("BadCredentials") || 
          smtpError.message?.includes("Username and Password not accepted")
        ) {
          emailHealth.error = "סיסמת האפליקציה אינה תקפה או פגת תוקף (Google 535 Bad Credentials)";
          console.warn("Gmail rejected credentials with 535 Bad Credentials. Enqueued email for retry.");
          return res.json({ 
            success: false, 
            queued: true,
            reason: "bad_credentials", 
            error: "שגיאת אימות מול Google (535 Bad Credentials). המייל נשמר בתור וישלח אוטומטית כשתעודכן הסיסמה." 
          });
        }

        emailHealth.error = smtpError.message;
        return res.json({ 
          success: false, 
          queued: true,
          error: smtpError.message || "Failed to send email",
          message: "שגיאה בשליחת המייל, אך המייל נשמר בתור לשליחה חוזרת."
        });
      }
    } catch (error: any) {
      console.error("Error sending email:", error);
      enqueueEmail(req.body, error.message);
      res.json({ 
        success: false, 
        queued: true, 
        error: error.message || "Failed to send email",
        message: "המייל נשמר בתור לשליחה חוזרת."
      });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
