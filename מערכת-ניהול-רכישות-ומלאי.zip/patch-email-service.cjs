const fs = require('fs');
let content = fs.readFileSync('src/services/emailService.ts', 'utf8');

const importReplacement = `import { SystemConfig } from '../types';
import { getAccessToken } from '../firebase';`;

content = content.replace(`import { SystemConfig } from '../types';`, importReplacement);

const fetchReplacement = `    const accessToken = await getAccessToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (accessToken) {
      headers['Authorization'] = \`Bearer \${accessToken}\`;
    }

    const response = await fetch('/api/send-email', {
      method: 'POST',
      headers,
      body: JSON.stringify(data),
    });`;

content = content.replace(`    const response = await fetch('/api/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });`, fetchReplacement);

fs.writeFileSync('src/services/emailService.ts', content);
