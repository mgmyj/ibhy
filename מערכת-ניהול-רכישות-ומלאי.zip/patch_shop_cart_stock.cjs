const fs = require('fs');
let content = fs.readFileSync('src/components/Shop.tsx', 'utf8');

const updateTarget = `  const updateQuantity = (cartItemId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if ((item.cartItemId || item.id) === cartItemId) {
        const maxStock = item.variantId ? (item.variants?.find(v => v.id === item.variantId)?.stockQuantity || 0) : item.stockQuantity;
        if (delta > 0 && item.quantity >= maxStock) {
          toast.error('שים לב למלאי הנותר במוצר');
        }
        const newQty = Math.max(1, Math.min(item.quantity + delta, maxStock));
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };`;
  
const updateNew = `  const updateQuantity = (cartItemId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if ((item.cartItemId || item.id) === cartItemId) {
        const originalStock = item.variantId ? (item.variants?.find(v => v.id === item.variantId)?.stockQuantity || 0) : item.stockQuantity;
        const lookupId = item.variantId ? \`\${item.id}-\${item.variantId}\` : item.id;
        // The activeCarts logic for delta includes our own current cart items, but activeCarts ONLY tracks OTHER users' carts (if id !== userId).
        const qtyInOtherCarts = activeCarts[lookupId] || 0;
        const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
        
        if (delta > 0 && item.quantity >= actualStock) {
          toast.error('הכמות המבוקשת חסרה במלאי הפנוי (יתכן ומוצרים תפוסים בסלים אחרים)');
        }
        const newQty = Math.max(1, Math.min(item.quantity + delta, actualStock));
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };`;

content = content.replace(updateTarget, updateNew);

const inputTarget = `                              onChange={(e) => {
                                const val = parseInt(e.target.value);
                                if (!isNaN(val)) {
                                  const maxStock = item.variantId ? (item.variants?.find(v => v.id === item.variantId)?.stockQuantity || 0) : item.stockQuantity;
                                  if (val > maxStock) {
                                    toast.error('שים לב למלאי הנותר במוצר');
                                  }
                                  const newQty = Math.max(1, Math.min(val, maxStock));
                                  setCart(prev => prev.map(p => (p.cartItemId || p.id) === (item.cartItemId || item.id) ? { ...p, quantity: newQty } : p));
                                }
                              }}`;

const inputNew = `                              onChange={(e) => {
                                const val = parseInt(e.target.value);
                                if (!isNaN(val)) {
                                  const originalStock = item.variantId ? (item.variants?.find(v => v.id === item.variantId)?.stockQuantity || 0) : item.stockQuantity;
                                  const lookupId = item.variantId ? \`\${item.id}-\${item.variantId}\` : item.id;
                                  const qtyInOtherCarts = activeCarts[lookupId] || 0;
                                  const actualStock = Math.max(0, originalStock - qtyInOtherCarts);
                                  
                                  if (val > actualStock) {
                                    toast.error('הכמות המבוקשת חסרה במלאי הפנוי (יתכן ומוצרים תפוסים בסלים אחרים)');
                                  }
                                  const newQty = Math.max(1, Math.min(val, actualStock));
                                  setCart(prev => prev.map(p => (p.cartItemId || p.id) === (item.cartItemId || item.id) ? { ...p, quantity: newQty } : p));
                                }
                              }}`;

content = content.replace(inputTarget, inputNew);

fs.writeFileSync('src/components/Shop.tsx', content);
console.log('Patched update quantity logic');
