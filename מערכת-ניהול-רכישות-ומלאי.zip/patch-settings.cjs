const fs = require('fs');
let content = fs.readFileSync('src/components/Settings.tsx', 'utf8');

const target = `                      <div>
                        <p className="font-bold text-zinc-900">{field.label}</p>
                        <p className="text-xs text-zinc-400">`;

const replacement = `                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-bold text-zinc-900">{field.label}</p>
                          {field.required && <span className="text-[10px] bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-bold">חובה</span>}
                          {!field.hideInReports && <span className="text-[10px] bg-indigo-100 text-indigo-600 px-2 py-0.5 rounded-full font-bold">מופיע בדוחות</span>}
                          {field.hideInReports && <span className="text-[10px] bg-zinc-100 text-zinc-500 px-2 py-0.5 rounded-full font-bold">מוסתר בדוחות</span>}
                        </div>
                        <p className="text-xs text-zinc-400">`;

content = content.replace(target, replacement);
fs.writeFileSync('src/components/Settings.tsx', content);
